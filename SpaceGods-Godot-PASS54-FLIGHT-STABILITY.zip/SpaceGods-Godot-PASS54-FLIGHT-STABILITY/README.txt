SPACE GODS / PASS 27 — THREE DREADNOUGHT GRAPHICS PASSES

Open PASS27_THREE_VISUAL_PASSES.txt for changes and how to view the new model.

SPACE GODS — PASS 22 FORWARD+ CINEMATIC
See PASS22_START_HERE.txt for graphics settings and compatibility notes.

SPACE GODS - PASS 19B (SECOND INTEGRATION OVERHAUL)

Windows / Godot 4.2+:
1. Unzip everything to a normal folder.
2. Place the official Godot 4 Windows editor executable in this folder (or add it to PATH).
3. Run TEST_SPACE_GODS_WINDOWS.bat. Inspect TEST_RESULTS.txt and ERRORS_ONLY.txt.
4. Run RUN_SPACE_GODS_WINDOWS.bat to play, or import project.godot and press F5.
5. Godot Project > Export > Windows Desktop can create an EXE after you install export templates.

This ZIP includes source code, not a compiled Windows executable. Tests require a local Godot engine.
The existing user://space_gods_native_v10.json save path is unchanged.
