SPACE GODS — PASS 37 TACTICAL FLIGHT COMPUTER

CTRL+4: pursue selected hostile. Automatically steers toward target and adjusts throttle.
CTRL+5: hold a 650 m combat distance; aims and adjusts throttle.
CTRL+6: disengage assistance; full manual controls.
TAB: select hostile. F: fire manually. T: cycle target subsystem.
1–0: throttle presets in manual mode. ~: engine shutdown and cancel tactical assist.

The assistant never fires weapons. It disengages if the target is lost, the engine is
shut down, or cruise begins. The original save format and mission systems remain.

Extract to a fresh folder and open project.godot with Godot 4.
Godot engine runtime verification was not available in this build environment.
