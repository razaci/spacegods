SPACE GODS PASS 46 — ONE BUTTON AUTO MISSIONS

Shift+F8 or the top-left AUTO MISSIONS button starts/stops.
Shift+F1 > AUTO MISSIONS also offers Start and Stop.
Automates existing 40 missions: accept, launch, sector jumps, navigation, mission interactions, combat, docking and reward collection.
Does NOT teleport or award free credits. Pauses for low fuel, engine shutdown, failed escorts and critical damage.
Keep Shift+F8 handy to stop at any time. Full Godot runtime testing is still needed.
