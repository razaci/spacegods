extends CanvasLayer
# PASS 49 cockpit. Etched bezels, glare shield, sensor scope. Same flight commands.
const GLASS := Color(0.012, 0.028, 0.04, 0.78)
const ETCH := Color(0.55, 0.82, 0.9, 0.62)
const CYAN := Color(0.62, 0.93, 0.98)
const TEXT := Color(0.86, 0.95, 0.96)
const MUTED := Color(0.52, 0.68, 0.72)
const AMBER := Color(0.95, 0.72, 0.32)
const RED := Color(0.92, 0.38, 0.34)
const GREEN := Color(0.46, 0.9, 0.62)

var game
var root: Control
var top_bar: PanelContainer
var flight_panel: PanelContainer
var engine_panel: PanelContainer
var objective_panel: PanelContainer
var tactical_panel: PanelContainer
var radar_panel: PanelContainer
var quick_panel: PanelContainer
var alert_panel: PanelContainer
var top_text: Label
var flight_text: Label
var system_text: Label
var target_text: Label
var tactical_text: Label
var objective_text: Label
var objective_hint: Label
var speed_text: Label
var throttle_text: Label
var nav_text: Label
var alert_text: Label
var radar: Control
var hull_bar: ProgressBar
var shield_bar: ProgressBar
var energy_bar: ProgressBar
var heat_bar: ProgressBar
var boost_bar: ProgressBar
var reticle: Control
var compass: Control
var canopy: Control
var refresh_clock := 0.0
var last_size := Vector2.ZERO
var compact := false
var menu_styled := false
var menu_child_count := -1

func initialize(host: Node3D) -> void:
	game = host
	layer = 5
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	canopy = Control.new()
	canopy.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canopy.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(canopy)
	canopy.draw.connect(_draw_canopy)
	_build_top()
	_build_flight()
	_build_engine()
	_build_radar()
	_build_objective()
	_build_tactics()
	_build_quickbar()
	_build_alert()
	_build_reticle()
	_build_compass()
	_layout()
	_update_data()
	_relocate_side_panels()

func _draw_canopy() -> void:
	var s := canopy.size
	if s.x < 8.0:
		return
	canopy.draw_rect(Rect2(0, 0, s.x, 18), Color(0, 0, 0, 0.35))
	canopy.draw_rect(Rect2(0, s.y - 22, s.x, 22), Color(0, 0, 0, 0.28))
	canopy.draw_line(Vector2(18, 18), Vector2(18, s.y - 22), Color(0.4, 0.7, 0.8, 0.18), 1.0)
	canopy.draw_line(Vector2(s.x - 18, 18), Vector2(s.x - 18, s.y - 22), Color(0.4, 0.7, 0.8, 0.18), 1.0)

func _bezel() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = GLASS
	style.border_color = ETCH
	style.set_border_width_all(1)
	style.border_width_top = 2
	style.set_corner_radius_all(2)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	style.shadow_color = Color(0, 0, 0, 0.45)
	style.shadow_size = 8
	return style

func _panel() -> PanelContainer:
	var panel := PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_theme_stylebox_override("panel", _bezel())
	root.add_child(panel)
	return panel

func _label(txt: String, size_px: int = 13, color: Color = TEXT) -> Label:
	var label := Label.new()
	label.text = txt
	label.add_theme_font_size_override("font_size", size_px)
	label.add_theme_color_override("font_color", color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label

func _kicker(txt: String) -> Label:
	return _label(txt, 10, MUTED)

func _bar(color: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(120, 7)
	bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.45)
	bg.set_border_width_all(1)
	bg.border_color = Color(1, 1, 1, 0.08)
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	bar.add_theme_stylebox_override("background", bg)
	bar.add_theme_stylebox_override("fill", fill)
	return bar

func _metric(parent: VBoxContainer, name: String, color: Color) -> ProgressBar:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	parent.add_child(row)
	var tag := _label(name, 11, MUTED)
	tag.custom_minimum_size = Vector2(54, 0)
	row.add_child(tag)
	var bar := _bar(color)
	row.add_child(bar)
	return bar

func _build_top() -> void:
	top_bar = _panel()
	top_text = _label("SPACE GODS", 13, CYAN)
	top_bar.add_child(top_text)

func _build_flight() -> void:
	flight_panel = _panel()
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	flight_panel.add_child(col)
	col.add_child(_kicker("PRESSURE  /  POWER"))
	flight_text = _label("ONLINE", 16, TEXT)
	col.add_child(flight_text)
	hull_bar = _metric(col, "HULL", GREEN)
	shield_bar = _metric(col, "SHIELD", CYAN)
	energy_bar = _metric(col, "BUS", AMBER)
	system_text = _label("", 12, MUTED)
	system_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(system_text)

func _build_engine() -> void:
	engine_panel = _panel()
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 2)
	engine_panel.add_child(col)
	col.add_child(_kicker("AIRSPEED"))
	speed_text = _label("0", 34, Color(0.7, 1.0, 0.78))
	col.add_child(speed_text)
	throttle_text = _label("THROTTLE 0%", 12, AMBER)
	col.add_child(throttle_text)
	boost_bar = _metric(col, "BOOST", GREEN)
	nav_text = _label("", 11, MUTED)
	nav_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(nav_text)

func _build_radar() -> void:
	radar_panel = _panel()
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 2)
	radar_panel.add_child(col)
	col.add_child(_kicker("SCOPE  3.6 KM"))
	radar = preload("res://scripts/hud_radar.gd").new()
	radar.game = game
	radar.custom_minimum_size = Vector2(180, 168)
	radar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	radar.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(radar)

func _build_objective() -> void:
	objective_panel = _panel()
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 4)
	objective_panel.add_child(col)
	col.add_child(_kicker("NAV COMPUTER"))
	objective_text = _label("STANDBY", 14, TEXT)
	objective_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	objective_text.custom_minimum_size.x = 230
	col.add_child(objective_text)
	objective_hint = _label("", 12, AMBER)
	objective_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(objective_hint)

func _build_tactics() -> void:
	tactical_panel = _panel()
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 4)
	tactical_panel.add_child(col)
	col.add_child(_kicker("WEAPONS"))
	target_text = _label("NO CONTACTS", 13, TEXT)
	target_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(target_text)
	heat_bar = _metric(col, "HEAT", RED)
	tactical_text = _label("", 11, MUTED)
	tactical_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(tactical_text)

func _chip(hot: bool) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.12, 0.2, 0.18, 0.95) if hot else Color(0.03, 0.06, 0.07, 0.92)
	style.border_color = AMBER if hot else ETCH
	style.set_border_width_all(1)
	style.border_width_bottom = 3
	style.set_content_margin_all(5)
	style.set_corner_radius_all(1)
	return style

func _button(label: String, action: Callable) -> Button:
	var button := Button.new()
	button.text = label
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_font_size_override("font_size", 11)
	button.add_theme_color_override("font_color", CYAN)
	button.add_theme_color_override("font_hover_color", AMBER)
	button.custom_minimum_size = Vector2(0, 32)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_stylebox_override("normal", _chip(false))
	button.add_theme_stylebox_override("hover", _chip(true))
	button.add_theme_stylebox_override("pressed", _chip(true))
	button.add_theme_stylebox_override("focus", _chip(false))
	button.pressed.connect(action)
	return button

func _build_quickbar() -> void:
	quick_panel = _panel()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	quick_panel.add_child(row)
	row.add_child(_button("MISSIONS", func(): game.show_menu("missions")))
	row.add_child(_button("GALAXY", func(): game.show_menu("galaxy")))
	row.add_child(_button("NEXT LEG", func(): game.mission_plot_next_leg()))
	row.add_child(_button("DOCK", func(): game.attempt_dock()))
	row.add_child(_button("SHIPWORKS", func(): game.show_menu("shipyard")))
	row.add_child(_button("NEXUS", func(): game.living_galaxy.show("hub")))
	row.add_child(_button("SAVE", _save_pressed))
	row.add_child(_button("AUTO", func():
		if is_instance_valid(game.pass46_auto):
			game.pass46_auto.toggle()
	))

func _save_pressed() -> void:
	game.save_game()
	game.announce("LOG WRITTEN" if game.last_save_ok else "SAVE FAILED")

func _build_alert() -> void:
	alert_panel = _panel()
	alert_text = _label("", 13, AMBER)
	alert_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	alert_panel.add_child(alert_text)
	alert_panel.visible = false

func _build_reticle() -> void:
	reticle = Control.new()
	reticle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	reticle.size = Vector2(78, 78)
	root.add_child(reticle)
	reticle.draw.connect(_draw_reticle)

func _draw_reticle() -> void:
	var c := reticle.size * 0.5
	var locked: bool = is_instance_valid(game) and not game.enemies.is_empty()
	var col: Color = AMBER if locked else CYAN
	reticle.draw_circle(c, 2.0, col)
	reticle.draw_arc(c, 11.0, 0.4, TAU - 0.4, 32, col, 1.1, true)
	for dir in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		reticle.draw_line(c + dir * 16.0, c + dir * 26.0, col, 1.3)

func _build_compass() -> void:
	compass = Control.new()
	compass.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(compass)
	compass.draw.connect(_draw_compass)

func _draw_compass() -> void:
	if not is_instance_valid(game):
		return
	var w := compass.size.x
	var heading: float = fposmod(rad_to_deg(float(game.yaw)), 360.0)
	compass.draw_rect(Rect2(0, 4, w, 20), Color(0.01, 0.03, 0.04, 0.55))
	compass.draw_rect(Rect2(0, 4, w, 20), Color(0.45, 0.75, 0.82, 0.4), false, 1.0)
	for mark in range(-60, 61):
		var deg := int(round(heading)) + mark
		var wrapped := posmod(deg, 360)
		if wrapped % 10 != 0:
			continue
		var x := w * 0.5 + float(mark) * 2.6
		if x < 10.0 or x > w - 10.0:
			continue
		var major := wrapped % 30 == 0
		compass.draw_line(Vector2(x, 16 if major else 18), Vector2(x, 23), CYAN if major else MUTED, 1.0)
		if major:
			var name: String = "N" if wrapped == 0 else ("E" if wrapped == 90 else ("S" if wrapped == 180 else ("W" if wrapped == 270 else str(wrapped))))
			compass.draw_string(ThemeDB.fallback_font, Vector2(x - 6, 15), name, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, TEXT)
	compass.draw_colored_polygon(PackedVector2Array([Vector2(w * 0.5 - 4, 2), Vector2(w * 0.5 + 4, 2), Vector2(w * 0.5, 8)]), AMBER)

func _place(panel: Control, pos: Vector2, dimensions: Vector2) -> void:
	panel.position = pos
	panel.size = dimensions

func _layout() -> void:
	var view := root.size
	if view.x < 40.0:
		view = get_viewport().get_visible_rect().size
	var m := 16.0
	var wide := view.x >= 1100.0
	_place(top_bar, Vector2(m, 10), Vector2(view.x - m * 2.0, 30))
	_place(flight_panel, Vector2(m, 50), Vector2(276, 178))
	_place(engine_panel, Vector2(m, view.y - 176), Vector2(276, 156))
	_place(radar_panel, Vector2(view.x - 236 - m, 50), Vector2(236, 214))
	_place(objective_panel, Vector2(view.x - 286 - m, 274), Vector2(286, 126))
	_place(tactical_panel, Vector2(view.x - 286 - m, 410), Vector2(286, 116))
	var bar_w := minf(820.0, view.x - 70.0)
	_place(quick_panel, Vector2((view.x - bar_w) * 0.5, view.y - 62), Vector2(bar_w, 48))
	_place(alert_panel, Vector2(view.x * 0.5 - 210, 50), Vector2(420, 32))
	reticle.position = view * 0.5 - reticle.size * 0.5
	compass.position = Vector2(view.x * 0.5 - 180, view.y - 104)
	compass.size = Vector2(360, 26)
	tactical_panel.visible = wide
	if not wide:
		objective_panel.position = Vector2(view.x - 250 - m, 50)
		radar_panel.position.y = view.y * 0.4
	last_size = view
	canopy.queue_redraw()

func set_compact(value: bool) -> void:
	compact = value
	_apply_visibility()

func _apply_visibility() -> void:
	var menus: bool = is_instance_valid(game) and bool(game.menu_open)
	var full: bool = not compact and not menus
	flight_panel.visible = full
	engine_panel.visible = not menus
	radar_panel.visible = not compact and not menus
	objective_panel.visible = full
	tactical_panel.visible = full and root.size.x >= 1100.0
	quick_panel.visible = full
	compass.visible = full
	reticle.visible = not menus
	top_bar.visible = not menus

func _process(dt: float) -> void:
	if not is_instance_valid(game):
		return
	if root.size != last_size:
		_layout()
	refresh_clock -= dt
	if refresh_clock <= 0.0:
		refresh_clock = 0.12
		_update_data()
		_apply_visibility()
		_polish_menu()
	reticle.queue_redraw()
	compass.queue_redraw()

func _update_data() -> void:
	var ship_name: String = game.SHIP_NAMES[game.ship_class]
	var sector: String = game.SYSTEM_NAMES[game.current_system]
	var state: String = "DOCKED" if game.docked else ("SURFACE" if game.on_surface else "FLIGHT")
	flight_text.text = ship_name
	top_text.text = "GODS COMMAND      %s      %s      %s CR      %s" % [ship_name, sector, _comma(game.credits), state]
	hull_bar.value = clampf(game.hull_hp / maxf(game.max_hull(), 1.0) * 100.0, 0.0, 100.0)
	shield_bar.value = clampf(game.shield_hp / maxf(game.max_shield(), 1.0) * 100.0, 0.0, 100.0)
	energy_bar.value = clampf(game.energy, 0.0, 100.0)
	heat_bar.value = clampf(game.weapon_heat, 0.0, 100.0)
	boost_bar.value = clampf(game.boost_reserve, 0.0, 100.0)
	system_text.text = "%s\nPIPS E%d W%d S%d     FUEL %d" % ["CUTOFF" if game.engine_cutoff else "DRIVE LIVE", game.p36_power_engines, game.p36_power_weapons, game.p36_power_shields, int(game.fuel)]
	speed_text.text = "%04d" % int(game.velocity)
	throttle_text.text = "M/S     THR %d" % int(game.throttle * 100.0)
	nav_text.text = "ASSIST %s     BRAKE %s" % ["ON" if game.flight_assist else "OFF", "ON" if game.nav_assist else "OFF"]
	tactical_text.text = "%s    MS %d    CM %s\n%s" % [game.WEAPON_NAMES[game.weapon_mode], game.missile_ammo, "RDY" if game.countermeasure_cooldown <= 0.0 else "WAIT", "AUTO" if is_instance_valid(game.pass46_auto) and game.pass46_auto.enabled else "MANUAL"]
	if game.enemies.is_empty():
		target_text.text = "SCOPE CLEAR"
	else:
		var target: Node3D = game.enemies[clampi(game.target_index, 0, game.enemies.size() - 1)]
		if is_instance_valid(target):
			target_text.text = "%s\n%d M    %s" % [target.name, int(game.flight_pos.distance_to(target.global_position)), game.subsystem_names[game.target_subsystem]]
	if game.mission_stage >= 6:
		objective_text.text = "%d / 40 CLEARED" % game.mission_completed.size()
		objective_hint.text = "Select next contract"
	else:
		var contract: Dictionary = game.MISSIONS[game.active_mission]
		var distance: int = int(game.flight_pos.distance_to(game.mission_objective_position()))
		var mission_sector: int = game.mission_current_sector()
		var progress: String = "%s M" % _comma(distance) if game.current_system == mission_sector else "JUMP"
		objective_text.text = "%s\n%s  ·  %s" % [contract["name"], game.SYSTEM_NAMES[mission_sector], progress]
		objective_hint.text = game.mission_phase_label()
	if is_instance_valid(game.living_galaxy) and game.nav_target == 9:
		objective_text.text = game.living_galaxy.objective_summary()
		objective_hint.text = "Ctrl+F4 field action"
	if game.docked:
		objective_hint.text = "E  terminal"
	elif game.clearance_granted and game.dock_range() < 1600.0:
		objective_hint.text = "E  land"
	var alert: String = ""
	if game.p41_emergency_hold:
		alert = "SAFETY HOLD"
	elif game.engine_cutoff:
		alert = "DRIVE CUT  ·  ~ RESTART"
	elif game.alert_timer > 0.0 and str(game.status_message) != "":
		alert = str(game.status_message)
	alert_text.text = alert
	alert_panel.visible = alert != "" and not game.menu_open

func _comma(value: int) -> String:
	var raw := str(absi(value))
	var out := ""
	var count := 0
	for i in range(raw.length() - 1, -1, -1):
		if count == 3:
			out = "," + out
			count = 0
		out = raw[i] + out
		count += 1
	return out

func _relocate_side_panels() -> void:
	if is_instance_valid(game.pass45_help) and is_instance_valid(game.pass45_help.panel):
		game.pass45_help.panel.visible = false
	if is_instance_valid(game.pass46_auto) and is_instance_valid(game.pass46_auto.panel):
		game.pass46_auto.panel.visible = false

func _polish_menu() -> void:
	if not is_instance_valid(game.menu):
		return
	if not menu_styled:
		game.menu.set_anchors_preset(Control.PRESET_CENTER)
		game.menu.offset_left = -390
		game.menu.offset_top = -300
		game.menu.offset_right = 390
		game.menu.offset_bottom = 300
		var shell := _bezel()
		shell.bg_color = Color(0.015, 0.035, 0.04, 0.96)
		shell.content_margin_left = 22
		shell.content_margin_right = 22
		shell.content_margin_top = 16
		shell.content_margin_bottom = 14
		game.menu.add_theme_stylebox_override("panel", shell)
		if is_instance_valid(game.menu_title):
			game.menu_title.add_theme_font_size_override("font_size", 18)
			game.menu_title.add_theme_color_override("font_color", Color(0.7, 1.0, 0.78))
		if is_instance_valid(game.menu_text):
			game.menu_text.add_theme_color_override("default_color", TEXT)
			game.menu_text.add_theme_font_size_override("normal_font_size", 14)
		var sc: Node = game.menu_actions.get_parent()
		if sc is ScrollContainer:
			sc.custom_minimum_size = Vector2(720, 320)
			sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		menu_styled = true
	if not is_instance_valid(game.menu_actions) or game.menu_actions.get_child_count() == menu_child_count:
		return
	menu_child_count = game.menu_actions.get_child_count()
	game.menu_actions.add_theme_constant_override("separation", 4)
	for node in game.menu_actions.get_children():
		if node is Button:
			node.alignment = HORIZONTAL_ALIGNMENT_LEFT
			node.add_theme_font_size_override("font_size", 13)
			node.add_theme_color_override("font_color", TEXT)
			node.custom_minimum_size = Vector2(700, 32)
			node.add_theme_stylebox_override("normal", _chip(false))
			node.add_theme_stylebox_override("hover", _chip(true))
			node.add_theme_stylebox_override("pressed", _chip(true))
			node.add_theme_stylebox_override("focus", _chip(false))
