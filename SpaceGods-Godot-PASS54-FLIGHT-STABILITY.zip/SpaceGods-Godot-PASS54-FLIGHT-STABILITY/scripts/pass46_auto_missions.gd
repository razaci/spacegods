extends Node
# PASS46: mission automation uses existing mission director, flight computer and reward logic.
# No instant teleportation, invented mission completion or free credits.
var game
var enabled: bool = false
var launch_requested_by_auto: bool = false
var paused_reason: String = ""
var station_menu_grace: float = 0.0
var status: String = "STANDBY"
var escort_override: bool = false
var escort_destination: Vector3 = Vector3.ZERO
var pulse: float = 0.0
var fire_timer: float = 0.0
var last_stage: int = -1
var last_sector: int = -1
var last_distance: float = -1.0
var stuck_seconds: float = 0.0
var last_objective: Vector3 = Vector3.ZERO
var panel: PanelContainer
var toggle_button: Button
var status_label: Label

func initialize(host) -> void:
 game = host
 var layer := CanvasLayer.new()
 layer.layer = 18
 add_child(layer)
 panel = PanelContainer.new()
 panel.set_anchors_preset(Control.PRESET_TOP_LEFT)
 panel.offset_left = 12.0
 panel.offset_top = 164.0
 panel.offset_right = 247.0
 panel.offset_bottom = 234.0
 layer.add_child(panel)
 var stack := VBoxContainer.new()
 panel.add_child(stack)
 toggle_button = Button.new()
 toggle_button.text = "AUTO MISSIONS  /  START"
 toggle_button.custom_minimum_size = Vector2(218.0,32.0)
 toggle_button.pressed.connect(toggle)
 stack.add_child(toggle_button)
 status_label = Label.new()
 status_label.text = "Ready  |  Shift+F8"
 status_label.custom_minimum_size = Vector2(218.0,20.0)
 status_label.add_theme_font_size_override("font_size",12)
 status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 stack.add_child(status_label)
 panel.mouse_filter = Control.MOUSE_FILTER_STOP

func show_status(message: String) -> void:
 if status == message: return
 status = message
 if is_instance_valid(status_label): status_label.text = message

func start() -> void:
 if game.engine_cutoff:
  show_status("ENGINES OFF / PRESS ~")
  game.announce("RESTART ENGINES WITH ~ BEFORE AUTO MISSIONS")
  return
 enabled = true
 paused_reason = ""
 station_menu_grace = 0.0
 pulse = 1.0
 last_stage = -1
 last_distance = -1.0
 stuck_seconds = 0.0
 game.p43_auto_evading = false
 game.p42_evasion_active = false
 show_status("AUTO MISSION DIRECTOR ACTIVE")
 game.close_menu()
 game.announce("AUTO MISSIONS ON / SHIFT+F8 TO STOP")
 refresh_button()

func stop() -> void:
 enabled = false
 launch_requested_by_auto = false
 escort_override = false
 game.p38_nav_mode = 0
 game.p37_flight_mode = 0
 game.p43_auto_evading = false
 game.throttle = 0.0
 show_status("MANUAL CONTROL / IDLE")
 game.announce("AUTO MISSIONS OFF / MANUAL CONTROL")
 refresh_button()

func toggle() -> void:
 if enabled: stop()
 else: start()

func refresh_button() -> void:
 if is_instance_valid(toggle_button):
  toggle_button.text = "AUTO MISSIONS  /  STOP" if enabled else "AUTO MISSIONS  /  START"

func pause(message: String) -> void:
 paused_reason = message
 enabled = false
 escort_override = false
 game.p38_nav_mode = 0
 game.p37_flight_mode = 0
 game.throttle = 0.0
 show_status("PAUSED: " + message)
 game.announce("AUTO MISSIONS PAUSED — " + message)
 refresh_button()

func tick(dt: float) -> void:
 if not enabled: return
 if game.menu_open:
  # Do not steal an open terminal from the player. The landing terminal is
  # the one exception: the automated director must be able to hand in a job.
  if game.docked and game.mission_stage == 5:
   game.close_menu()
  else:
   pause("TERMINAL OPEN / CLOSE MENU THEN RESTART")
   return
 if game.engine_cutoff:
  pause("ENGINES OFF / PRESS ~")
  return
 if game.fuel <= game.p44_fuel_reserve and not game.docked:
  pause("LOW FUEL / RESCUE OR REFUEL")
  return
 if game.p41_emergency_hold or game.hull_hp <= 20.0:
  pause("HULL CRITICAL / REPAIR FIRST")
  return
 if game.on_surface or game.unknown_pocket:
  pause("RETURN TO ORBIT FIRST")
  return
 if game.mission_escort_failed:
  pause("ESCORT FAILED / MISSION RETRY")
  return
 if game.jump_timer > 0.0 or game.landing_timer > 0.0 or game.launch_timer > 0.0 or game.world_transition > 0.0:
  show_status("TRANSIT / WAITING FOR ARRIVAL")
  return
 pulse -= dt
 fire_timer -= dt
 if game.mission_stage >= 6:
  if game.mission_completed.size() >= game.MISSIONS.size():
   pause("ALL 40 CONTRACTS COMPLETED")
   return
  var next_index: int = -1
  for i in range(game.MISSIONS.size()):
   if not game.mission_completed.has(i):
    next_index = i
    break
  if next_index < 0:
   pause("NO AVAILABLE CONTRACTS")
   return
  if not game.docked and game.current_system != 0:
   travel_to_sector(0)
   return
  if not game.docked and game.current_system == 0:
   dock_at_station()
   return
  game.accept_mission(next_index)
  if game.mission_stage >= 6:
   pause("MISSION BOARD BLOCKED / CHECK WARRANTS")
  else:
   show_status("ACCEPTED / " + str(game.MISSIONS[next_index]["name"]))
  return
 if game.docked:
  if game.mission_stage == 5 and game.current_system == 0:
   game.hand_in_mission()
   show_status("REWARD CLAIMED / NEXT CONTRACT")
   return
  show_status("LAUNCHING / MISSION IN PROGRESS")
  launch_requested_by_auto = true
  game.launch_from_station()
  launch_requested_by_auto = false
  return
 if game.mission_stage >= 4:
  if game.current_system != 0:
   travel_to_sector(0)
  elif game.mission_stage == 5:
   dock_at_station()
  elif game.dock_range() < 1550.0:
   show_status("RETURN / APPROACH COMMAND CENTER")
   dock_at_station()
  else:
   dock_at_station()
  return
 var required: int = game.mission_current_sector()
 if required != game.current_system:
  travel_to_sector(required)
  return
 if game.mission_stage != last_stage or game.current_system != last_sector:
  last_stage = game.mission_stage
  last_sector = game.current_system
  game.p38_nav_mode = 0
  game.p37_flight_mode = 0
  last_distance = -1.0
  stuck_seconds = 0.0
 var destination: Vector3 = game.mission_objective_position()
 var kind: String = game.mission_objective_kind()
 escort_override = false
 if game.mission_stage == 3 and kind == "escort":
  escort_override = true
  escort_destination = destination + Vector3(0.0,0.0,-1100.0 * game.escort_progress)
  destination = escort_destination
 var distance: float = game.flight_pos.distance_to(destination)
 # Every stage is a real target; keep the objective locked instead of reusing a stale manual waypoint.
 if last_objective.distance_to(destination) > 1.0:
  last_objective = destination
  last_distance = -1.0
  stuck_seconds = 0.0
 if game.p43_auto_evading or game.p42_evasion_active:
  game.p43_auto_evading = false
  game.p42_evasion_active = false
 # Report navigation stalls rather than silently showing a stationary AUTO button.
 if game.mission_stage in [0,2] or (game.mission_stage in [1,3] and game.mission_objective_kind() not in ["combat","defense","escort"]):
  if last_distance >= 0.0 and distance >= last_distance - 2.0 and game.p38_nav_mode == 1 and not game.docked:
   stuck_seconds += dt
  else:
   stuck_seconds = maxf(0.0,stuck_seconds-dt*2.0)
  last_distance = distance
  if stuck_seconds > 18.0:
   game.p38_nav_mode = 0
   game.p37_flight_mode = 0
   game.linear_velocity = Vector3.ZERO
   game.velocity = 0.0
   stuck_seconds = 0.0
   show_status("RECALCULATING MISSION APPROACH")
 if game.mission_stage == 1 or game.mission_stage == 3:
  if kind == "combat" or kind == "defense":
   combat_step(distance,kind)
   return
  if kind == "escort":
   if not game.enemies.is_empty():
    combat_step(distance,kind)
   else:
    approach(distance,"ESCORT / PROTECT CONVOY")
   return
  if kind == "scan" or kind == "gate":
   if distance < 420.0:
    game.p38_nav_mode = 0
    game.throttle = 0.0
    if not game.mission_scan_active and pulse <= 0.0:
     game.interact_mission()
     pulse = 1.0
    show_status("SCANNING / HOLD POSITION")
   else: approach(distance,"APPROACH SCAN SITE")
   return
  if kind in ["delivery","rescue","salvage"] and distance < 470.0:
   game.p38_nav_mode = 0
   game.throttle = 0.0
   if pulse <= 0.0:
    game.interact_mission()
    pulse = 1.0
   show_status("INTERACT / " + kind.to_upper())
   return
  if kind == "explore" and distance < 330.0:
   game.p38_nav_mode = 0
   game.throttle = 0.0
   show_status("SURVEY / HOLD POSITION")
   return
 approach(distance,"OBJECTIVE / " + kind.to_upper())

func travel_to_sector(destination: int) -> void:
 escort_override = false
 game.p38_nav_mode = 0
 if game.route_destination != destination or game.route_legs.is_empty():
  game.plot_route(destination,false)
 if game.route_legs.is_empty():
  pause("NO CONNECTED ROUTE")
  return
 var cost: int = game.jump_fuel_cost(game.current_system,int(game.route_legs[0]))
 if game.fuel < float(cost) + 1.0:
  pause("NEED %d FUEL / SHIFT+F1 DISTRESS" % cost)
  return
 show_status("HYPERSPACE / " + game.SYSTEM_NAMES[int(game.route_legs[0])])
 if pulse <= 0.0:
  game.begin_jump()
  pulse = 1.0

func dock_at_station() -> void:
 escort_override = false
 if game.docked: return
 if game.p38_nav_mode != 3:
  game.p38_set_nav_mode(3)
 show_status("AUTO DOCK / GODS COMMAND")

func approach(distance: float, label: String) -> void:
 if game.p38_nav_mode != 1:
  game.nav_target = 0
  game.p38_set_nav_mode(1)
 else:
  game.nav_target = 0
 show_status(label + " / %d M / AUTO PILOT" % int(distance))

func combat_step(distance: float, kind: String) -> void:
 var target: Node3D = null
 var nearest: float = 999999999.0
 for i in range(game.enemies.size()):
  var e: Node3D = game.enemies[i]
  if not is_instance_valid(e): continue
  var d: float = game.flight_pos.distance_to(e.global_position)
  if d < nearest:
   nearest = d
   target = e
   game.target_index = i
 if target == null:
  approach(distance,"SEARCHING COMBAT ZONE / " + kind.to_upper())
  return
 escort_override = false
 game.p38_nav_mode = 0
 if game.p37_flight_mode != 1:
  game.p37_set_flight_mode(1)
 var direction: Vector3 = (target.global_position - game.flight_pos).normalized()
 var forward: Vector3 = -game.player.global_transform.basis.z
 var alignment: float = forward.dot(direction)
 if nearest < 2600.0 and alignment > 0.965 and game.shot_cooldown <= 0.0 and fire_timer <= 0.0:
  game.fire()
  fire_timer = 0.18
 show_status("ENGAGING / %s / %d M" % [target.name,int(nearest)])
