extends Node
# Persistent single-player galaxy: all transactions use the existing ship/save.
const TEMPERAMENTS = preload("res://scripts/temperaments.gd")
const LEGENDARY = {3:{"ship":"Riftglass Sovereign","kind":"frigate","ability":"overdrive","drop":"rift_core"},5:{"ship":"Ashcrown Revenant","kind":"dreadnought","ability":"reactor_shields","drop":"warden_seal"},6:{"ship":"Silent Cartographer","kind":"frigate","ability":"signal_echo","drop":"echo_drive"}}
const FACTIONS = ["Command Wardens", "Free Traders Guild", "Ash Syndicate", "Veil Concord"]
const GOODS = ["provisions","medicines","alloys","circuits","cores","cells","crystals","relics","contraband","sensor_kit","cargo_pod","shield_cell","rift_core","warden_seal","echo_drive","legendary_drive"]
const BASE = [42,115,75,185,420,68,270,680,390,720,850,590,2400,2800,3200,7000]
const SPECIALTIES = ["alloys","cells","crystals","relics","cores","circuits","medicines"]
const CAREERS = ["hunter","merchant","salvager","explorer","artisan"]
const CAPTAINS = ["Vesper Coil","Harrow Flint","Nyx Meridian","Kestrel Vane","Orin Blackwake","Sable Rook","Morrow Ash"]
const RECIPES = {
 "sensor_kit":{"alloys":2,"circuits":2,"crystals":1},
 "cargo_pod":{"alloys":4,"circuits":1,"cores":1},
 "shield_cell":{"alloys":1,"cells":3,"cores":1},
 "legendary_drive":{"rift_core":1,"warden_seal":1,"echo_drive":1,"circuits":4,"cores":2}
}
var game
var state: Dictionary = {}
var clock = 0.0
var last_sector = -1
var goal_marker: Node3D
var captain: Node3D
var timer_label: Label
var journal: Array = []

func initialize(host) -> void:
 game = host
 reset_state()

func reset_state() -> void:
 state = {"version":1,"tick":0,"markets":[],"rep":[0,0,0,0],"control":[],"events":[],"cargo":{},"xp":{},"hunt":{},"arc":{},"contracts":[],"orders":[],"consignments":[],"facilities":[],"history":[],"completed":{},"installed":{},"goal":{},"notice":"Welcome to the Living Galaxy.","next_id":1,"tone":{"humor":false,"soft":true},"player_profile":0,"relief_jobs":[],"customs_checks":{},"relief_completed":0}
 for career in CAREERS: state.xp[career] = 0
 for sector in range(7):
  var market = {}
  for i in range(GOODS.size()):
   market[GOODS[i]] = {"stock":0 if i>=12 else 80 if GOODS[i]==SPECIALTIES[sector] else 24+(sector*13+i*7)%34,"demand":0}
  state.markets.append(market)
  var faction = [0,1,2,3,2,1,3][sector]
  var influence = [15,15,15,15]
  influence[faction] = 55
  state.control.append({"owner":faction,"influence":influence})
  state.events.append({"kind":"stable","good":SPECIALTIES[sector],"left":0})
 generate_orders()

func export_state() -> Dictionary:
 return state.duplicate(true)

func import_state(value) -> void:
 if not value is Dictionary or int(value.get("version",0)) != 1: return
 if not value.get("markets",[]) is Array or value.markets.size()!=7: return
 if not value.get("control",[]) is Array or value.control.size()!=7: return
 for sector in range(7):
  if not value.markets[sector] is Dictionary: return
  for good in GOODS:
   if not value.markets[sector].get(good) is Dictionary: return
   value.markets[sector][good].stock = clampi(int(value.markets[sector][good].get("stock",0)),0,500)
   value.markets[sector][good].demand = clampi(int(value.markets[sector][good].get("demand",0)),-20,30)
  if not value.control[sector] is Dictionary or not value.control[sector].get("influence",[]) is Array or value.control[sector].influence.size()!=4: return
  value.control[sector].owner = clampi(int(value.control[sector].get("owner",0)),0,3)
 if not value.get("rep",[]) is Array or value.rep.size()!=4: return
 for i in range(4): value.rep[i] = clampi(int(value.rep[i]),-100,100)
 for key in ["cargo","xp","hunt","arc","completed","installed","goal"]:
  if not value.get(key) is Dictionary: return
 for key in ["events","contracts","orders","consignments","facilities","history"]:
  if not value.get(key) is Array: return
 if value.events.size()!=7: return
 for good in value.cargo.keys():
  if not GOODS.has(str(good)): value.cargo.erase(good)
  else: value.cargo[good] = clampi(int(value.cargo[good]),0,500)
 for career in CAREERS: value.xp[career] = clampi(int(value.xp.get(career,0)),0,1000000)
 value.history = value.history.slice(0,40)
 value["tone"] = value.get("tone",{"humor":false,"soft":true})
 if not value.tone is Dictionary: value.tone={"humor":false,"soft":true}
 value["player_profile"]=posmod(int(value.get("player_profile",0)),4)
 state = value.duplicate(true)
 if not state.get("relief_jobs",[]) is Array: state["relief_jobs"]=[]
 if not state.get("customs_checks",{}) is Dictionary: state["customs_checks"]={}
 state["relief_completed"]=maxi(0,int(state.get("relief_completed",0)))
 state.tick = maxi(0,int(state.get("tick",0)))
 state.next_id = maxi(1,int(state.get("next_id",1)))
 # An interception reloads the same named target; evidence and paid claims persist.
 last_sector = -1

func persist(message: String = "") -> void:
 if message!="":
  state.notice = message
  state.history.push_front("Cycle %d: %s" % [int(state.tick),message])
  if state.history.size()>40: state.history.resize(40)
  game.announce(message)
 game.save_game()

func amount(good: String) -> int:
 if ["alloys","circuits","cores"].has(good): return int(game.salvage_inventory.get(good,0))
 return int(state.cargo.get(good,0))

func change_cargo(good: String, delta: int) -> void:
 if ["alloys","circuits","cores"].has(good): game.salvage_inventory[good] = maxi(0,amount(good)+delta)
 else: state.cargo[good] = maxi(0,amount(good)+delta)

func cargo_used() -> int:
 var total = int(game.cargo_units)
 for good in GOODS: total += amount(good)
 for c in state.contracts:
  if c.get("status","")=="active": total += int(c.qty)
 return total

func capacity() -> int:
 return int(game.SHIP_CARGO[game.ship_class])+(int(game.ship_outfit[4])-1)*12+int(state.installed.get("cargo_pod",0))*8

func xp(career: String, points: int) -> void:
 state.xp[career] = int(state.xp.get(career,0))+points

func reputation(faction: int, points: int, sector: int) -> void:
 state.rep[faction] = clampi(int(state.rep[faction])+points,-100,100)
 var influence = state.control[sector].influence
 influence[faction] = clampi(int(influence[faction])+points,0,100)
 var owner = int(state.control[sector].owner)
 if int(influence[faction])>=60 and int(influence[faction])>int(influence[owner])+10:
  state.control[sector].owner = faction
  state.history.push_front(FACTIONS[faction]+" took control of "+game.SYSTEM_NAMES[sector])

func price(sector: int, good: String, buy: bool = true) -> int:
 var index = GOODS.find(good)
 if index<0: return 0
 var m = state.markets[sector][good]
 var scarcity = clampf(1.5-float(m.stock)/85.0+float(m.demand)*0.018,0.56,2.35)
 var event = state.events[sector]
 if str(event.good)==good and str(event.kind)=="shortage": scarcity *= 1.45
 if str(event.kind)=="blockade": scarcity *= 1.12
 var discount = clampf(float(state.rep[int(state.control[sector].owner)])*.001,-.08,.08)
 return maxi(1,int(round(float(BASE[index])*scarcity*((1.08-discount) if buy else .90))))

func require_dock() -> bool:
 if not game.docked:
  game.announce("Dock at the local station to transact or use the workshop.")
  return false
 return true

func trade(good: String, qty: int, buy: bool) -> void:
 if qty<=0 or not GOODS.has(good) or not require_dock(): return
 if good=="contraband" and not buy and not customs_clear(): game.announce("Restricted sale blocked: request customs clearance or declare cargo.");show("customs");return
 var sector = int(game.current_system)
 var m = state.markets[sector][good]
 if buy:
  if cargo_used()+qty>capacity(): game.announce("Cargo hold is full."); return
  if int(m.stock)<qty: game.announce("Market stock is insufficient."); return
  var cost = price(sector,good,true)*qty
  if int(game.credits)<cost: game.announce("Insufficient credits."); return
  game.credits -= cost
  m.stock = int(m.stock)-qty
  change_cargo(good,qty)
 else:
  if amount(good)<qty: game.announce("Insufficient cargo."); return
  var earned = price(sector,good,false)*qty
  game.credits += earned
  m.stock = mini(500,int(m.stock)+qty)
  change_cargo(good,-qty)
  xp("merchant",qty*2)
  if str(state.events[sector].kind)=="shortage" and str(state.events[sector].good)==good:
   m.demand = maxi(-20,int(m.demand)-qty)
   reputation(int(state.control[sector].owner),1,sector)
 persist(("Bought " if buy else "Sold ")+"%d %s" % [qty,good.replace("_"," ")])
 show("market_"+good)

func generate_orders() -> void:
 var orders = []
 for sector in range(7):
  for i in range(3):
   var good = GOODS[(sector*3+i*4+int(state.tick))%9]
   orders.append({"id":"%d:%d:%d" % [int(state.tick),sector,i],"sector":sector,"good":good,"qty":3+i*2,"price":int(price(sector,good,false)*1.22),"buyer":["Emergency Quartermaster","Independent Fabricator","Expedition Broker"][i]})
 state.orders = orders

func fulfill_order(id: String) -> void:
 if not require_dock(): return
 for order in state.orders:
  if str(order.id)!=id or int(order.sector)!=int(game.current_system): continue
  var qty = int(order.qty)
  if qty<=0: game.announce("Order has already been filled.");return
  if amount(str(order.good))<qty: game.announce("Bring the full requested quantity.");return
  change_cargo(str(order.good),-qty)
  game.credits += qty*int(order.price)
  order.qty = 0
  xp("merchant",qty*4)
  reputation(int(state.control[game.current_system].owner),2,int(game.current_system))
  persist("Bazaar order fulfilled: "+str(order.buyer))
  show("bazaar")
  return

func consign(good: String, qty: int, markup: float) -> void:
 if not require_dock() or qty<=0: return
 var live = 0
 for c in state.consignments:
  if int(c.qty)>0: live+=1
 if live>=3: game.announce("Three listing slots are already occupied.");return
 if amount(good)<qty: game.announce("Insufficient items for escrow.");return
 var sector = int(game.current_system)
 var ask = maxi(1,int(price(sector,good,false)*markup))
 var fee = maxi(1,int(ask*qty*.02))
 if game.credits<fee: game.announce("Insufficient credits for listing fee.");return
 change_cargo(good,-qty)
 game.credits-=fee
 var id = int(state.next_id); state.next_id=id+1
 state.consignments.append({"id":id,"sector":sector,"good":good,"qty":qty,"ask":ask,"sold":0,"earned":0})
 persist("Items placed in bazaar escrow. NPC buyers evaluate prices each cycle.")
 show("bazaar")

func cancel_listing(id: int) -> void:
 if not require_dock(): return
 for c in state.consignments:
  if int(c.id)!=id: continue
  if int(c.sector)!=int(game.current_system): game.announce("Cancel at the listing station.");return
  if cargo_used()+int(c.qty)>capacity():game.announce("Make cargo space before withdrawing escrow.");return
  change_cargo(str(c.good),int(c.qty));c.qty=0
  persist("Remaining bazaar stock returned to cargo.");show("bazaar");return

func world_tick() -> void:
 state.tick = int(state.tick)+1
 for sector in range(7):
  for good in GOODS:
   var m = state.markets[sector][good]
   var production = 0 if GOODS.find(good)>=12 else 7 if good==SPECIALTIES[sector] else 1
   var consumption = 2+(sector+GOODS.find(good)+int(state.tick))%3
   m.stock = clampi(int(m.stock)+production-consumption,0,160)
  var event = state.events[sector]
  event.left = maxi(0,int(event.left)-1)
  if int(event.left)==0:
   var index = (sector+int(state.tick))%5
   event.kind = ["stable","shortage","blockade","festival","stable"][index]
   event.good = GOODS[(sector+int(state.tick)*3)%8]
   event.left = 3
   if str(event.kind)=="shortage": state.markets[sector][event.good].stock=8
   if str(event.kind)=="festival": state.markets[sector].provisions.demand=12
  # NPC faction pressure evolves independently of player reputation.
  if str(event.kind)=="blockade":
   var challenger=(sector+int(state.tick))%4
   var owner=int(state.control[sector].owner)
   if challenger!=owner:
    state.control[sector].influence[owner]=maxi(0,int(state.control[sector].influence[owner])-2)
    reputation(challenger,3,sector)
    state.rep[challenger]=clampi(int(state.rep[challenger])-3,-100,100)
 for c in state.consignments:
  if int(c.qty)<=0: continue
  if int(c.ask)>int(price(int(c.sector),str(c.good),true)*1.05): continue
  var sold = mini(int(c.qty),1+int(state.tick)%3)
  var revenue = sold*int(c.ask)
  c.qty = int(c.qty)-sold;c.sold = int(c.sold)+sold;c.earned = int(c.earned)+revenue
  game.credits += revenue;xp("merchant",sold*3)
 for facility in state.facilities:
  var sector = int(facility.sector)
  var revenue = 45+int(facility.level)*30
  if str(state.events[sector].kind)=="blockade": revenue=int(revenue*.5)
  facility.earned = int(facility.earned)+revenue
  game.credits+=revenue
 for c in state.contracts:
  if c.get("status","")=="active" and int(state.tick)>int(c.deadline):
   c.status="expired"
   reputation(int(c.faction),-3,int(c.destination))
   state.history.push_front("Delivery expired: "+str(c.name)+"; sealed cargo reclaimed, bond forfeited.")
 for job in state.relief_jobs:
  if str(job.status)=="active" and int(state.tick)>int(job.deadline):
   job.status="expired"
   reputation(int(job.faction),-4,int(job.sector))
   state.history.push_front("Relief commission expired at "+game.SYSTEM_NAMES[int(job.sector)])
 state.relief_jobs=state.relief_jobs.slice(-12)
 state.consignments = state.consignments.filter(func(c): return int(c.qty)>0 or int(c.sold)>0).slice(-12)
 state.contracts = state.contracts.slice(-12)
 generate_orders()
 persist()

func offer_contract(destination: int) -> Dictionary:
 var origin = int(game.current_system)
 var good = str(state.events[destination].good)
 if str(state.events[destination].kind)!="shortage": good = ["medicines","provisions","cells"][(origin+destination)%3]
 return {"id":"delivery:%d:%d:%d" % [int(state.tick),origin,destination],"name":"Supply "+game.SYSTEM_NAMES[destination],"origin":origin,"destination":destination,"good":good,"qty":3+(destination%3),"bond":250,"reward":700+abs(destination-origin)*140,"deadline":int(state.tick)+12,"faction":int(state.control[destination].owner),"status":"active"}

func accept_delivery(destination: int) -> void:
 if not require_dock() or destination==int(game.current_system): return
 var active = 0
 for old in state.contracts:
  if old.status=="active": active+=1
 if active>=2:game.announce("Finish one of your two active freight contracts.");return
 var c = offer_contract(destination)
 for old in state.contracts:
  if str(old.id)==str(c.id):game.announce("This departure contract is already taken.");return
 if game.credits<int(c.bond) or cargo_used()+int(c.qty)>capacity():game.announce("Need 250 CR bond and sealed cargo space.");return
 game.credits-=int(c.bond)
 state.contracts.append(c)
 persist("Sealed freight loaded for "+game.SYSTEM_NAMES[destination])
 show("freight")

func deliver(id: String) -> void:
 if not require_dock(): return
 for c in state.contracts:
  if str(c.id)!=id or c.status!="active":continue
  if int(game.current_system)!=int(c.destination):game.announce("Dock at the specified destination.");return
  if int(state.tick)>int(c.deadline):game.announce("The contract has expired.");return
  c.status="delivered"
  game.credits+=int(c.reward)+int(c.bond)
  state.markets[game.current_system][c.good].stock += int(c.qty)
  reputation(int(c.faction),5,int(c.destination));xp("merchant",45)
  persist("Freight delivered; bond returned and %d CR paid." % int(c.reward))
  show("freight");return

func plot_delivery(id: String) -> void:
 for c in state.contracts:
  if str(c.id)==id and c.status=="active":
   game.plot_route(int(c.destination),true)
   game.nav_target=1
   return

func craft(item: String) -> void:
 if not RECIPES.has(item) or not require_dock():return
 var recipe = RECIPES[item]
 for good in recipe:
  if amount(good)<int(recipe[good]):game.announce("Missing recipe components: "+str(recipe));return
 for good in recipe:change_cargo(good,-int(recipe[good]))
 change_cargo(item,1);xp("artisan",35)
 persist("Crafted "+item.replace("_"," ")+"; install it or trade it.")
 show("workshop")

func install(item: String) -> void:
 if not require_dock() or not RECIPES.has(item):return
 if item=="shield_cell" and int(game.upgrades.shield)>=5:game.announce("Shields are already MK V; keep or sell this cell.");return
 if amount(item)<1:game.announce("Craft or buy the item first.");return
 if int(state.installed.get(item,0))>=3:game.announce("Three permanent installations of this type are fitted.");return
 change_cargo(item,-1);state.installed[item]=int(state.installed.get(item,0))+1
 if item=="shield_cell":
  game.upgrades.shield = mini(5,int(game.upgrades.shield)+1)
  game.shield_hp=game.max_shield()
 xp("artisan",25)
 persist("Installed "+item.replace("_"," "));show("workshop")

func establish_facility() -> void:
 if not require_dock():return
 var sector = int(game.current_system)
 for f in state.facilities:
  if int(f.sector)==sector:
   if int(f.level)>=3:game.announce("This trade office is fully expanded.");return
   var cost = 4000*int(f.level)
   if game.credits<cost:game.announce("Need %d CR for the next office level." % cost);return
   game.credits-=cost;f.level=int(f.level)+1
   persist("Trade office expanded.");show("operations");return
 if int(state.xp.merchant)<100 or int(state.rep[int(state.control[sector].owner)])<10:
  game.announce("Trade office requires Merchant XP 100 and local reputation 10.");return
 if game.credits<5000:game.announce("Need 5,000 CR to establish a trade office.");return
 game.credits-=5000
 state.facilities.append({"sector":sector,"level":1,"earned":0})
 persist("Trade office established; earns commissions each live galaxy cycle.");show("operations")

func site(sector: int, seed: int) -> Vector3:
 var angle = float((seed*137+sector*53)%360)*PI/180.0
 var radius = 2300.0+float((seed*733+sector*241)%3900)
 return game.SECTOR_ORIGINS[sector]+Vector3(cos(angle)*radius,250.0+float(seed%5)*130.0,sin(angle)*radius-3500.0)

func set_goal(sector: int, seed: int, title: String) -> void:
 state.goal={"sector":sector,"seed":seed,"title":title}
 game.plot_route(sector,true)
 game.nav_target=9
 refresh_marker()

func waypoint() -> Vector3:
 if state.goal.is_empty():return game.station_position
 return site(int(state.goal.sector),int(state.goal.seed))

func goal_name() -> String:
 if state.goal.is_empty():return "LIVING GALAXY"
 return str(state.goal.title)+(" / JUMP REQUIRED" if int(state.goal.sector)!=int(game.current_system) else "")

func near_goal(distance: float = 550.0) -> bool:
 return not game.docked and game.jump_timer<=0.0 and not state.goal.is_empty() and int(state.goal.sector)==int(game.current_system) and game.flight_pos.distance_to(waypoint())<=distance

func refresh_marker() -> void:
 if is_instance_valid(goal_marker):goal_marker.queue_free()
 goal_marker=null
 if state.goal.is_empty() or int(state.goal.sector)!=int(game.current_system):return
 goal_marker=Node3D.new();goal_marker.name="LivingGalaxy_InvestigationSite";game.add_child(goal_marker)
 goal_marker.position=waypoint()
 var ring = game.torus(goal_marker,Vector3.ZERO,24,28,Color(.2,.8,.65),1.2)
 ring.rotation.x=PI/2
 game.cube(goal_marker,Vector3(0,0,12),Vector3(30,12,45),Color(.15,.21,.25))
 game.ball(goal_marker,Vector3(0,8,0),5,Color(.3,1,.7),1.5,10)

func accept_hunt(index: int) -> void:
 if index<0 or index>=CAPTAINS.size():return
 if not state.hunt.is_empty() and not ["claimed","abandoned"].has(str(state.hunt.get("stage",""))):game.announce("Complete or abandon the current investigation.");return
 if not state.arc.is_empty() and str(state.arc.get("kind",""))=="siege" and not ["complete","abandoned"].has(str(state.arc.get("stage",""))):game.announce("Complete the blockade expedition before accepting a warrant.");return
 if int(game.mission_stage)<6 or game.bounty_active:game.announce("Finish or abandon your existing combat operation first.");return
 var generation = int(state.completed.get("hunt_"+str(index),0))
 var first=(index+1+generation)%7
 state.hunt={"index":index,"name":CAPTAINS[index],"stage":"trace","first":first,"second":(first+2+index%2)%7,"target":(first+4)%7,"seed":100+index*7+generation*43,"reward":3500+index*450+generation*250,"escapes":0,"timer":0.0,"hp":0.0,"shield":0.0,"captured":false,"loot":false}
 persist("Investigation accepted: "+CAPTAINS[index]+". Track the transponder evidence.")
 plot_hunt()

func plot_hunt() -> void:
 var h=state.hunt
 if h.is_empty():return
 if ["claimed","abandoned"].has(str(h.stage)):return
 if str(h.stage)=="return":game.plot_route(0,true);game.nav_target=1;return
 var sector=int(h.first) if str(h.stage)=="trace" else (int(h.second) if str(h.stage)=="witness" else int(h.target))
 var seed=int(h.seed)+(0 if str(h.stage)=="trace" else 1 if str(h.stage)=="witness" else 2)
 set_goal(sector,seed,"HUNT / "+str(h.name)+" / "+str(h.stage).to_upper())

func near_hunt(distance: float = 550.0) -> bool:
 var h=state.hunt
 if h.is_empty():return false
 var stage=str(h.stage)
 var sector=int(h.first) if stage=="trace" else int(h.second) if stage=="witness" else int(h.target)
 var seed=int(h.seed)+(0 if stage=="trace" else 1 if stage=="witness" else 2)
 return not game.docked and game.jump_timer<=0.0 and int(game.current_system)==sector and game.flight_pos.distance_to(site(sector,seed))<=distance

func near_arc(distance: float = 550.0) -> bool:
 var a=state.arc
 if a.is_empty():return false
 var stage=str(a.stage)
 var leg=0 if stage=="survey" else 1 if stage=="choice" else 2
 var sector=int(a.first) if leg==0 else int(a.second) if leg==1 else int(a.third)
 return not game.docked and game.jump_timer<=0.0 and int(game.current_system)==sector and game.flight_pos.distance_to(site(sector,int(a.seed)+leg))<=distance

func hunt_action(action: String) -> void:
 var h=state.hunt
 if h.is_empty():return
 if action=="claim":
  if str(h.stage)!="return" or not game.docked or int(game.current_system)!=0:game.announce("Return to Gods Command and dock to claim the warrant.");return
  var reward=int(h.reward)+(1200 if bool(h.captured) else 0)
  h.stage="claimed";game.credits+=reward
  var key="hunt_"+str(h.index);state.completed[key]=int(state.completed.get(key,0))+1
  xp("hunter",120);reputation(0,9,0);reputation(2,-4,int(h.target))
  persist("Warrant closed: %s / +%d CR" % [str(h.name),reward]);show("hunts");return
 if action=="abandon":
  h.stage="abandoned";clear_captain();state.goal={};refresh_marker();persist("Investigation abandoned.");show("hunts");return
 if not near_hunt():game.announce("Approach the plotted investigation site within 550 M.");return
 if str(h.stage)=="trace" and action=="scan":
  h.stage="witness";xp("explorer",20);persist("Flight recorder decoded; the captain traded supplies in another sector.");plot_hunt()
 elif str(h.stage)=="witness" and ["pay","threaten"].has(action):
  var fee=witness_fee()
  if action=="pay" and game.credits<fee:game.announce("Need %d CR for the broker's evidence." % fee);return
  if action=="pay":game.credits-=fee;reputation(1,2,int(game.current_system))
  else:reputation(1,-5,int(game.current_system));h.reward=int(h.reward)-300
  h.stage="intercept";h.timer=0.0;h.engine_damage=0.0;h.weapon_damage=0.0;h.shield_damage=0.0;persist("Target route identified. Intercept in "+game.SYSTEM_NAMES[int(h.target)]+".");plot_hunt()
 elif str(h.stage)=="intercept" and action=="capture":
  if not is_instance_valid(captain):game.announce("Target not yet on scanners.");return
  if float(captain.get_meta("hp"))>float(captain.get_meta("max_hp"))*.35 or float(captain.get_meta("shield"))>0.0 or float(captain.get_meta("engine_damage",0.0))<0.92:
   game.announce("Strip shields, disable engines (T), reduce hull below 35%, then board (Shift+B).");return
  if captain.position.distance_to(game.flight_pos)>550:game.announce("Move within boarding range of the captain.");return
  h.captured=true;finish_hunt(false)
 elif str(h.stage)=="salvage" and action=="recover":
  var legendary=LEGENDARY.get(int(h.index),{})
  var needed=5 if not legendary.is_empty() else 4
  if cargo_used()+needed>capacity():game.announce("Make %d units of cargo space for recovered goods." % needed);return
  change_cargo("circuits",2);change_cargo("cores",1);change_cargo("contraband",1)
  if not legendary.is_empty():change_cargo(str(legendary.drop),1)
  h.loot=true;h.stage="return";xp("salvager",40);persist("Pirate cargo recovered. Return for the warrant payment.");plot_hunt()

func clear_captain() -> void:
 for e in game.enemies.duplicate():
  if is_instance_valid(e) and e.has_meta("living_hunt"):
   game.enemies.erase(e);e.queue_free()
 captain=null

func spawn_captain() -> void:
 var h=state.hunt
 clear_captain()
 for i in range(3):
  var e=Node3D.new();game.add_child(e)
  var legendary=LEGENDARY.get(int(h.index),{})
  var kind=str(legendary.get("kind","frigate")) if i==0 else "interceptor"
  e.name=str(h.name).replace(" ","_") if i==0 else "Warrant_Escort_"+str(i)
  e.position=site(int(h.target),int(h.seed)+2)+Vector3((i-1)*220,45,-180-i*90)
  game.build_enemy_visual(e,kind)
  if i==0 and kind=="dreadnought" and not legendary.is_empty():
   for part in e.get_children():part.visible=false
   var model=load("res://art/models/gods_dreadnought.glb") as PackedScene
   if model!=null:e.add_child(model.instantiate())
  var hp=(850.0 if kind=="dreadnought" else 420.0 if not legendary.is_empty() else 320.0) if i==0 else 70.0
  var shield=(350.0 if kind=="dreadnought" else 180.0 if not legendary.is_empty() else 100.0) if i==0 else 40.0
  e.set_meta("hp",float(h.hp) if i==0 and float(h.hp)>0.0 else hp)
  e.set_meta("shield",float(h.shield) if i==0 and float(h.hp)>0.0 else shield)
  e.set_meta("max_hp",hp);e.set_meta("max_shield",shield);e.set_meta("class",kind)
  e.set_meta("phase",float(i));e.set_meta("fire_timer",1.5+float(i));e.set_meta("engine_damage",0.0);e.set_meta("weapon_damage",0.0);e.set_meta("shield_damage",0.0);e.set_meta("missile_timer",10.0);e.set_meta("flank",-1.0 if i%2==0 else 1.0)
  e.set_meta("living_hunt",true)
  if i==0:
   e.set_meta("living_captain",true);captain=e
   for field in ["engine_damage","weapon_damage","shield_damage"]: e.set_meta(field,float(h.get(field,0.0)))
   if not legendary.is_empty():
    e.name=str(legendary.ship).replace(" ","_")
    e.scale=Vector3.ONE*(1.5 if kind=="dreadnought" else 1.25)
  game.enemies.append(e)
 game.announce(str(h.name)+" detected with escorts. Engines can be disabled for boarding.")

func enemy_destroyed(e: Node3D) -> void:
 if e.has_meta("living_arc") and not state.arc.is_empty() and str(state.arc.stage)=="final":
  state.arc.kills=int(state.arc.get("kills",0))+1
  xp("hunter",15)
 if e.has_meta("living_captain") and not state.hunt.is_empty() and str(state.hunt.stage)=="intercept":finish_hunt(true)

func finish_hunt(killed: bool) -> void:
 var h=state.hunt
 if str(h.stage)!="intercept":return
 if is_instance_valid(captain):
  var p=captain.position-game.SECTOR_ORIGINS[int(game.current_system)]
  h.wreck=[p.x,p.y,p.z]
 h.stage="salvage";h.hp=0.0;h.shield=0.0
 if not killed:clear_captain()
 captain=null
 # A separate wreck beacon keeps recovery possible after combat or a reload.
 set_goal(int(h.target),int(h.seed)+2,"RECOVER / "+str(h.name))
 persist("Captain "+("destroyed" if killed else "captured alive")+". Recover cargo at the plotted wreck.")

func start_arc(kind: String) -> void:
 if not ["mercy","relic","siege"].has(kind):return
 if int(game.mission_stage)<6 or game.bounty_active:game.announce("Finish the active flight operation before starting an expedition.");return
 if kind=="siege" and not state.hunt.is_empty() and not ["claimed","abandoned"].has(str(state.hunt.get("stage",""))):game.announce("Finish the named warrant before starting a blockade expedition.");return
 if not state.arc.is_empty() and not ["complete","abandoned"].has(str(state.arc.get("stage",""))):game.announce("Finish your active expedition first.");return
 var iteration=int(state.completed.get("arc_"+kind,0))
 var base=2 if kind=="mercy" else 3 if kind=="relic" else 4
 var first=(base+iteration)%7
 var second=(first+2)%7
 state.arc={"kind":kind,"stage":"survey","first":first,"second":second,"third":(second+2)%7,"seed":300+base*17+iteration*51,"choice":"","reward":2500,"time":0.0,"kills":0}
 persist("Expedition accepted: "+arc_title()+". Three distinct sites and a consequential choice.")
 plot_arc()

func arc_title() -> String:
 if state.arc.is_empty():return "NO EXPEDITION"
 return {"mercy":"The Broken Lifeline","relic":"The Unclaimed Archive","siege":"The Silent Blockade"}.get(str(state.arc.kind),"Expedition")

func plot_arc() -> void:
 var a=state.arc
 if a.is_empty():return
 if str(a.stage)=="return":game.plot_route(0,true);game.nav_target=1;return
 if ["complete","abandoned"].has(str(a.stage)):return
 var leg=0 if str(a.stage)=="survey" else 1 if str(a.stage)=="choice" else 2
 var sector=int(a.first) if leg==0 else int(a.second) if leg==1 else int(a.third)
 set_goal(sector,int(a.seed)+leg,"EXPEDITION / "+arc_title()+" / "+str(a.stage).to_upper())

func arc_action(action: String) -> void:
 var a=state.arc
 if a.is_empty():return
 if action=="abandon":a.stage="abandoned";clear_arc_ships();state.goal={};refresh_marker();persist("Expedition abandoned.");show("expeditions");return
 if str(a.stage)=="return" and action=="claim":
  if not game.docked or int(game.current_system)!=0:game.announce("Dock at Gods Command to report the expedition.");return
  a.stage="complete";game.credits+=int(a.reward)
  var faction=0 if str(a.choice)=="aid" else 3 if str(a.choice)=="archive" else 2
  reputation(faction,8,int(a.third));xp("explorer",100)
  var key="arc_"+str(a.kind);state.completed[key]=int(state.completed.get(key,0))+1
  persist(arc_title()+" complete. Choices recorded; faction influence changed.");show("expeditions");return
 if not near_arc():game.announce("Approach the plotted expedition site within 550 M.");return
 if str(a.stage)=="survey" and action=="survey":
  a.stage="choice";xp("explorer",25);persist("Survey recovered a disputed manifest. Meet the second-site contact.");plot_arc()
 elif str(a.stage)=="choice" and ["aid","archive","profit"].has(action):
  if action=="aid":
   if amount("medicines")<2:game.announce("Humanitarian route requires two medicines. Buy them at a station.");return
   change_cargo("medicines",-2);a.reward=3200
  elif action=="archive":a.reward=2800
  else:a.reward=4300;reputation(0,-4,int(a.second))
  a.choice=action;a.stage="final";a.time=0.0
  persist("Branch chosen: "+action+". A third-sector rendezvous is now available.");plot_arc()
 elif str(a.stage)=="final" and action=="finish":
  if str(a.kind)=="siege" and int(a.kills)<2:game.announce("Clear both blockade vessels before securing the rendezvous.");return
  var required=20.0 if str(a.kind)=="relic" else 10.0
  if float(a.time)<required:game.announce("Hold position at the final site for %d seconds." % int(required));return
  var item="crystals" if str(a.choice)=="archive" else "provisions" if str(a.choice)=="aid" else "contraband"
  if cargo_used()+2>capacity():game.announce("Make two cargo spaces for the expedition reward.");return
  change_cargo(item,2);a.stage="return";xp("salvager",20)
  state.markets[int(a.third)][item].stock+=4
  persist("Final rendezvous secured. Cargo acquired; return to Command.");plot_arc()

func _process(dt: float) -> void:
 if game==null or not game.startup_checked:return
 if int(game.current_system)!=last_sector:
  last_sector=int(game.current_system);clear_captain();clear_arc_ships();refresh_marker()
 if game.menu_open or game.jump_timer>0.0 or game.on_surface:return
 clock+=minf(dt,0.25)
 if clock>=90.0:clock=0.0;world_tick()
 var h=state.hunt
 if not h.is_empty() and str(h.stage)=="intercept":
  if int(game.current_system)==int(h.target) and near_hunt(1800) and not is_instance_valid(captain):spawn_captain()
  if is_instance_valid(captain):
   h.hp=float(captain.get_meta("hp"));h.shield=float(captain.get_meta("shield"))
   for field in ["engine_damage","weapon_damage","shield_damage"]:h[field]=float(captain.get_meta(field))
   var legendary=LEGENDARY.get(int(h.index),{})
   if str(legendary.get("ability",""))=="reactor_shields" and float(h.shield_damage)<.4:
    captain.set_meta("shield",minf(float(captain.get_meta("max_shield")),float(h.shield)+dt*8.0))
   if str(legendary.get("ability",""))=="signal_echo":
    captain.scale=Vector3.ONE*(1.25+.05*sin(float(h.timer)*4.0))
    var cycle=int(float(h.timer)/25.0)
    if cycle>0 and cycle!=int(h.get("echo_cycle",0)):
     h.echo_cycle=cycle
     spawn_echo_decoy()
   h.timer=float(h.timer)+minf(dt,.25)
   if float(h.timer)>=escape_limit() and float(captain.get_meta("engine_damage"))<.55:
    h.escapes=int(h.escapes)+1;h.timer=0.0;h.hp=0.0;h.shield=0.0
    var links=game.SECTOR_LINKS[int(h.target)]
    h.target=int(links[int(h.escapes)%links.size()]);h.reward=int(h.reward)+250
    h.engine_damage=0.0;h.weapon_damage=0.0;h.shield_damage=0.0
    clear_captain();persist(str(h.name)+" escaped to "+game.SYSTEM_NAMES[int(h.target)]+"; the warrant remains active.");plot_hunt()
 var a=state.arc
 if not a.is_empty() and str(a.stage)=="final":
  if str(a.kind)=="siege" and int(a.kills)<2 and near_arc(1800):
   var present=0
   for enemy in game.enemies:
    if is_instance_valid(enemy) and enemy.has_meta("living_arc"):present+=1
   if present==0:spawn_blockade(2-int(a.kills))
  var required=20.0 if str(a.kind)=="relic" else 10.0
  if near_arc() and absf(float(game.velocity))<90.0:a.time=minf(required,float(a.time)+minf(dt,.25))
  else:a.time=maxf(0.0,float(a.time)-dt)

func summary() -> String:
 var owner=int(state.control[game.current_system].owner)
 return "%s / REP %d\nHOLD %d/%d  |  CYCLE %d\n%s" % [FACTIONS[owner],int(state.rep[owner]),cargo_used(),capacity(),int(state.tick),str(state.notice)]

func objective_summary() -> String:
 if not state.goal.is_empty() and game.nav_target==9:
  var destination=game.SYSTEM_NAMES[int(state.goal.sector)]
  return "%s\n%s\nSHIFT+N: DESK / CTRL+F4: FIELD ACTION" % [str(state.goal.title),destination]
 return ""

func action() -> void:
 if not state.goal.is_empty() and str(state.goal.title).begins_with("EXPEDITION"):
  show("expedition_active")
 else:show("hunt_active")

func back() -> void:
 game.add_action("BACK / LIVING GALAXY",show.bind("hub"))
 game.add_action("CLOSE / RETURN TO FLIGHT",game.close_menu)

func show(page: String = "hub") -> void:
 game.menu_open=true;game.menu.visible=true
 for child in game.menu_actions.get_children():game.menu_actions.remove_child(child);child.queue_free()
 game.menu_title.text="LIVING GALAXY / "+page.replace("_"," ").to_upper()
 game.menu_text.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
 game.menu_text.custom_minimum_size.y=210 if page.begins_with("personality_") else 135
 game.menu_text.text=""
 if page=="hub":
  game.menu_text.text="[b]CAPTAIN'S GALAXY DESK[/b]\n"+summary()+"\n\nNamed investigations, three-site expeditions, regional markets, NPC bazaar orders, crafting and faction territory share persistent state. Galaxy cycles take 90 seconds of unpaused play; menus pause the simulation."
  for pair in [["relief","FACTION RELIEF COMMISSIONS"],["route_planner","PROFITABLE TRADE ROUTES"],["customs","STATION CUSTOMS & SECURITY"],["hunts","WARRANTS / NAMED CAPTAINS"],["expeditions","BRANCHING EXPEDITIONS"],["markets","REGIONAL TRADE EXCHANGE"],["bazaar","BAZAAR / ORDERS & ESCROW"],["freight","FREIGHT CONTRACTS"],["workshop","CRAFTING & INSTALLATIONS"],["factions","FACTIONS & TERRITORY"],["careers","CAREERS & INVENTORY"],["operations","TRADE OPERATIONS"],["personalities","JUNG FOUR FUNCTIONS & CONTACTS"],["legendary","LEGENDARY SHIP REGISTRY"],["journal","GALAXY JOURNAL"]]:game.add_action(str(pair[1]),show.bind(str(pair[0])))
 elif page=="route_planner":
  var origin=int(game.current_system)
  var opportunities=[]
  for destination in range(7):
   if destination==origin: continue
   for good in GOODS:
    if GOODS.find(good)>=12: continue
    var stock=int(state.markets[origin][good].stock)
    var buy_price=price(origin,good,true)
    var sale_price=price(destination,good,false)
    var profit=sale_price-buy_price
    if stock<=0 or profit<=0: continue
    opportunities.append({"sector":destination,"good":good,"profit":profit,"buy":buy_price,"sell":sale_price,"stock":stock})
  opportunities.sort_custom(func(a,b):return int(a.profit)>int(b.profit))
  game.menu_text.text="[b]TRADE ROUTE ANALYZER[/b]\nLive regional prices and per-unit gross margins. Profit does not include fuel, piracy or changing market prices.\n"
  for i in range(mini(12,opportunities.size())):
   var r=opportunities[i]
   game.menu_text.text+="\n%s to %s: +%d CR/unit (%d buy / %d sell)" % [str(r.good).to_upper(),game.SYSTEM_NAMES[int(r.sector)],int(r.profit),int(r.buy),int(r.sell)]
   game.add_action("PLOT %s / %s / +%d CR" % [game.SYSTEM_NAMES[int(r.sector)],str(r.good).to_upper(),int(r.profit)],game.plot_route.bind(int(r.sector),true))
  if opportunities.is_empty(): game.menu_text.text+="\nNo positive-margin opportunities at current quotes."
 elif page=="relief":
  game.menu_text.text="[b]FACTION RELIEF COMMISSIONS[/b]\nBuy requested supplies, carry them to the destination, dock and deliver. Deadlines follow galaxy cycles. Deliveries restore supplies, strengthen the local faction and earn career XP. Maximum two active jobs."
  for job in state.relief_jobs:
   if str(job.status)=="active":
    game.menu_text.text+="\nACTIVE: %d %s to %s / due cycle %d / %d CR" % [int(job.qty),str(job.good),game.SYSTEM_NAMES[int(job.sector)],int(job.deadline),int(job.reward)]
    game.add_action("PLOT RELIEF / "+game.SYSTEM_NAMES[int(job.sector)],game.plot_route.bind(int(job.sector),true))
    game.add_action("DELIVER / "+game.SYSTEM_NAMES[int(job.sector)],deliver_relief.bind(int(job.id)))
  for sector in range(7):
   if sector==int(game.current_system): continue
   var offer=relief_offer(sector)
   game.add_action("COMMISSION / %s / %d %s / %d CR" % [game.SYSTEM_NAMES[sector],int(offer.qty),str(offer.good),int(offer.reward)],accept_relief.bind(sector))
 elif page=="customs":
  var sector=int(game.current_system)
  var owner=int(state.control[sector].owner)
  game.menu_text.text="[b]STATION CUSTOMS[/b]\nSecurity authority: %s\nContraband onboard: %d units\nReputation: %d\nInspection is required before selling restricted goods. Low reputation increases scrutiny. Voluntary declaration confiscates illegal goods without a fine." % [FACTIONS[owner],amount("contraband"),int(state.rep[owner])]
  game.add_action("REQUEST CUSTOMS CLEARANCE",request_clearance)
  game.add_action("VOLUNTARILY DECLARE CONTRABAND",declare_contraband)
  game.add_action("RETURN TO MARKET",show.bind("markets"))
 elif page=="markets":
  game.menu_text.text="[b]LOCAL TRADE EXCHANGE[/b]\n"+summary()+"\nBuy / sell spreads apply. Purchases consume stock; deliveries replenish it. Trade requires docking."
  for good in GOODS:game.add_action("%s / BUY %d SELL %d / STOCK %d" % [good.to_upper(),price(game.current_system,good),price(game.current_system,good,false),int(state.markets[game.current_system][good].stock)],show.bind("market_"+good))
  game.add_action("COMPARE REGIONAL PRICES",show.bind("routes"))
 elif page.begins_with("market_"):
  var good=page.trim_prefix("market_")
  if GOODS.has(good):
   game.menu_text.text="[b]%s[/b]\nOnboard %d | Hold %d/%d\nBuy %d CR / Sell %d CR per unit\nLocal stock %d. Transaction prices reflect the current market." % [good.to_upper(),amount(good),cargo_used(),capacity(),price(game.current_system,good),price(game.current_system,good,false),int(state.markets[game.current_system][good].stock)]
   for qty in [1,5,10]:
    game.add_action("BUY %d / %d CR" % [qty,price(game.current_system,good)*qty],trade.bind(good,qty,true))
    game.add_action("SELL %d / %d CR" % [qty,price(game.current_system,good,false)*qty],trade.bind(good,qty,false))
   game.add_action("LIST 1 AT MARKET PRICE / ESCROW",consign.bind(good,1,1.0))
   game.add_action("LIST 5 AT +20% ASK / MAY REMAIN UNSOLD",consign.bind(good,5,1.2))
   game.add_action("BACK / ALL GOODS",show.bind("markets"))
 elif page=="routes":
  var lines=PackedStringArray()
  for sector in range(7):
   var good=str(SPECIALTIES[game.current_system])
   lines.append("%s: sells %s for %d CR / buys for %d CR / %s" % [game.SYSTEM_NAMES[sector],good,price(sector,good),price(sector,good,false),str(state.events[sector].kind)])
   game.add_action("PLOT / "+game.SYSTEM_NAMES[sector],game.plot_route.bind(sector,true))
  game.menu_text.text="[b]REGIONAL ROUTE INTELLIGENCE[/b]\n"+"\n".join(lines)+"\n\nPrices are current quotes; fuel, price spread and cargo risk affect net profit."
 elif page=="bazaar":
  game.menu_text.text="[b]NPC BAZAAR[/b]\nLocal buyers request full lots. Orders refresh each cycle. Consigned items leave your hold for escrow; NPC fills credit you automatically. A 2% listing fee applies.\n"
  for order in state.orders:
   if int(order.sector)==int(game.current_system) and int(order.qty)>0:game.add_action("%s / %d %s / %d CR" % [str(order.buyer),int(order.qty),str(order.good),int(order.qty)*int(order.price)],fulfill_order.bind(str(order.id)))
  for c in state.consignments:
   game.menu_text.text+="\nListing #%d / %s / %s / remaining %d / sold %d / earned %d CR" % [int(c.id),game.SYSTEM_NAMES[int(c.sector)],str(c.good),int(c.qty),int(c.sold),int(c.earned)]
   if int(c.qty)>0:game.add_action("WITHDRAW UNSOLD #%d" % int(c.id),cancel_listing.bind(int(c.id)))
  game.add_action("CHOOSE ITEMS TO LIST",show.bind("markets"))
 elif page=="freight":
  game.menu_text.text="[b]SEALED FREIGHT[/b]\n250 CR refundable bond. Two active contracts maximum. Twelve cycles to deliver; expiry forfeits the bond and loses reputation. Sealed freight cannot be sold.\n"
  for c in state.contracts:
   game.menu_text.text+="\n%s / %s / %d units / due cycle %d" % [str(c.name),str(c.status),int(c.qty),int(c.deadline)]
   if c.status=="active":
    game.add_action("PLOT / "+str(c.name),plot_delivery.bind(str(c.id)))
    game.add_action("DELIVER / "+str(c.name),deliver.bind(str(c.id)))
  for destination in range(7):
   if destination==int(game.current_system):continue
   var c=offer_contract(destination)
   game.add_action("ACCEPT %s / %d %s / %d CR" % [str(c.name),int(c.qty),str(c.good),int(c.reward)],accept_delivery.bind(destination))
 elif page=="workshop":
  game.menu_text.text="[b]CRAFTING WORKSHOP[/b]\nCrafted items can be sold or installed up to three times. Sensor kits reduce information fees; cargo pods add eight spaces each; shield cells improve shield upgrades up to MK V.\n"
  for item in RECIPES:
   game.menu_text.text+="\n%s: %s | stored %d | fitted %d" % [str(item).to_upper(),str(RECIPES[item]),amount(item),int(state.installed.get(item,0))]
   game.add_action("CRAFT / "+str(item),craft.bind(str(item)))
   game.add_action("INSTALL / "+str(item),install.bind(str(item)))
 elif page=="hunts":
  game.menu_text.text="[b]INVESTIGATION WARRANTS[/b]\nTrace a recorder, negotiate with a witness, then intercept a named captain and escorts. Captains can escape after 120 seconds; damage engines to prevent it. Capture requires no shields and hull below 35%. Recover cargo, then dock at Command for payment."
  if not state.hunt.is_empty():game.add_action("ACTIVE / "+str(state.hunt.name),show.bind("hunt_active"))
  for i in range(CAPTAINS.size()):game.add_action("INVESTIGATE / %s / %d CR + CAPTURE BONUS" % [CAPTAINS[i],3500+i*450],accept_hunt.bind(i))
 elif page=="hunt_active":
  var h=state.hunt
  if h.is_empty():game.menu_text.text="No active investigation."
  else:
   game.menu_text.text="[b]%s[/b]\nStage %s / Reward %d CR / Escapes %d\n%s\n\nInvestigate within 550 M of the selected beacon. Capture requires proximity to the ship itself." % [str(h.name),str(h.stage),int(h.reward),int(h.escapes),goal_name()]
   var p=TEMPERAMENTS.profile(int(h.index))
   var legendary=LEGENDARY.get(int(h.index),{})
   game.menu_text.text+="\nCaptain: %s / %s\nShip: %s\nEscape window: %d sec" % [str(p.code),str(p.name),str(legendary.get("ship","Independent Frigate")),int(escape_limit())]
   if str(h.stage)=="witness":game.menu_text.text+="\n\nBroker: "+TEMPERAMENTS.line(int(h.index)+7,bool(state.tone.humor),bool(state.tone.soft))
   game.add_action("PLOT CURRENT WARRANT STAGE",plot_hunt)
   if str(h.stage)=="trace":game.add_action("SCAN FLIGHT RECORDER",hunt_action.bind("scan"))
   if str(h.stage)=="witness":
    game.add_action("PAY BROKER / %d CR" % witness_fee(),hunt_action.bind("pay"))
    game.add_action("THREATEN BROKER / GUILD REPUTATION LOSS",hunt_action.bind("threaten"))
   if str(h.stage)=="intercept":game.add_action("BOARD DISABLED CAPTAIN",hunt_action.bind("capture"))
   if str(h.stage)=="salvage":game.add_action("RECOVER FOUR CARGO UNITS",hunt_action.bind("recover"))
   if str(h.stage)=="return":game.add_action("CLAIM WARRANT AT COMMAND",hunt_action.bind("claim"))
   if not ["claimed","abandoned"].has(str(h.stage)):game.add_action("ABANDON INVESTIGATION",hunt_action.bind("abandon"))
 elif page=="expeditions":
  game.menu_text.text="[b]BRANCHING STORY EXPEDITIONS[/b]\nThree rotating sector sites per expedition. Survey evidence, choose humanitarian aid, public archiving or a black-market sale, then complete a timed rendezvous. Cargo and faction consequences differ by choice."
  if not state.arc.is_empty():game.add_action("ACTIVE / "+arc_title(),show.bind("expedition_active"))
  for pair in [["mercy","THE BROKEN LIFELINE"],["relic","THE UNCLAIMED ARCHIVE"],["siege","THE SILENT BLOCKADE"]]:game.add_action("ACCEPT / "+str(pair[1]),start_arc.bind(str(pair[0])))
 elif page=="expedition_active":
  var a=state.arc
  if a.is_empty():game.menu_text.text="No active expedition."
  else:
   game.menu_text.text="[b]%s[/b]\nStage %s / Choice %s / Reward %d CR\nFinal-site hold %.1f seconds\n%s" % [arc_title(),str(a.stage),str(a.choice),int(a.reward),float(a.time),goal_name()]
   var story={"mercy":"A relief carrier has vanished. Its recorder names a refuge whose supplies are failing.","relic":"An unregistered archive holds research claimed by three factions. Decide who should inherit it.","siege":"A silent blockade is starving a frontier station. Two armed interdiction ships guard the final rendezvous."}
   game.menu_text.text+="\n\n"+str(story.get(str(a.kind),""))+"\n"+TEMPERAMENTS.line(13 if str(a.kind)=="mercy" else 3 if str(a.kind)=="relic" else 8,bool(state.tone.humor),bool(state.tone.soft))
   game.menu_text.text+="\nFinal task: "+("20-second archive scan" if str(a.kind)=="relic" else "Destroy two blockade ships, then hold ten seconds" if str(a.kind)=="siege" else "Ten-second relief transfer")
   game.add_action("PLOT CURRENT EXPEDITION STAGE",plot_arc)
   if str(a.stage)=="survey":game.add_action("SURVEY EVIDENCE",arc_action.bind("survey"))
   if str(a.stage)=="choice":
    game.add_action("AID SURVIVORS / CONSUMES 2 MEDICINES",arc_action.bind("aid"))
    game.add_action("ARCHIVE FINDINGS / VEIL REPUTATION",arc_action.bind("archive"))
    game.add_action("SELL TO SYNDICATE / WARDEN REPUTATION LOSS",arc_action.bind("profit"))
   if str(a.stage)=="final":game.add_action("COMPLETE TIMED RENDEZVOUS",arc_action.bind("finish"))
   if str(a.stage)=="return":game.add_action("REPORT AT COMMAND / CLAIM PAYMENT",arc_action.bind("claim"))
   if not ["complete","abandoned"].has(str(a.stage)):game.add_action("ABANDON EXPEDITION",arc_action.bind("abandon"))
 elif page=="factions":
  game.menu_text.text="[b]FACTIONS & TERRITORY[/b]\nReputation changes trade prices and office access. Completed jobs add influence; a faction taking a ten-point lead at 60+ influence captures a sector.\n"
  for i in range(4):game.menu_text.text+="\n%s / reputation %d" % [FACTIONS[i],int(state.rep[i])]
  for sector in range(7):game.add_action("%s / %s / %s" % [game.SYSTEM_NAMES[sector],FACTIONS[int(state.control[sector].owner)],str(state.events[sector].kind)],game.plot_route.bind(sector,true))
 elif page=="careers":
  game.menu_text.text="[b]CAREERS & HOLD MANIFEST[/b]\n"+summary()+"\n"
  for career in CAREERS:game.menu_text.text+="\n%s / XP %d / Rank %d" % [str(career).to_upper(),int(state.xp[career]),1+int(int(state.xp[career])/100)]
  game.menu_text.text+="\n\nCargo:"
  for good in GOODS:
   if amount(good)>0:game.menu_text.text+="\n%s x %d" % [good,amount(good)]
 elif page=="operations":
  game.menu_text.text="[b]TRADE OFFICES[/b]\nEstablish regional offices with Merchant XP 100, local reputation 10 and 5,000 CR. Each office earns commissions per 90-second live cycle. Blockades halve income. Offices grow to level three.\n"
  for f in state.facilities:game.menu_text.text+="\n%s / Level %d / earned %d CR" % [game.SYSTEM_NAMES[int(f.sector)],int(f.level),int(f.earned)]
  game.add_action("ESTABLISH / UPGRADE LOCAL OFFICE",establish_facility)
 elif page=="personalities":
  game.menu_text.text="[b]JUNG-INSPIRED FOUR FUNCTIONS[/b]\nSensation, Intuition, Thinking and Feeling. Each fictional contact has scores in all four functions and a dominant preference. Warmth, composure and other soft traits also affect dialogue and decisions. Scores are authored game traits, not test results.\nHumor: %s / Gentle tone: %s / Captain profile: %s" % ["ON" if bool(state.tone.humor) else "OFF","ON" if bool(state.tone.soft) else "OFF",TEMPERAMENTS.CODES[int(state.player_profile)]]
  game.add_action("TOGGLE HUMOR / REMEMBER MY CHOICE",toggle_tone.bind("humor"))
  game.add_action("TOGGLE GENTLE DIALOGUE",toggle_tone.bind("soft"))
  for i in range(4):game.add_action(TEMPERAMENTS.CODES[i]+" / "+TEMPERAMENTS.NAMES[i],show.bind("personality_"+str(i)))
 elif page.begins_with("personality_"):
  var index=clampi(int(page.trim_prefix("personality_")),0,3)
  var p=TEMPERAMENTS.profile(index)
  game.menu_title.text="JUNG FOUR FUNCTIONS / "+str(p.code).to_upper()
  game.menu_text.text="[b]%s / %s[/b]\nSensation %d / Intuition %d\nThinking %d / Feeling %d\nWarmth %d / Composure %d / Caution %d\nAssertion %d / Curiosity %d / Humor %d\n\n%s\n%s" % [str(p.code),str(p.name),int(p.sensation),int(p.intuition),int(p.thinking),int(p.feeling),int(p.warmth),int(p.composure),int(p.caution),int(p.assertion),int(p.curiosity),int(p.humor),str(p.explanation),TEMPERAMENTS.line(index,bool(state.tone.humor),bool(state.tone.soft))]
  game.add_action("USE AS MY CAPTAIN FUNCTION PREFERENCE",select_profile.bind(index))
  game.add_action("BACK / TEMPERAMENT CATALOG",show.bind("personalities"))
 elif page=="legendary":
  game.menu_text.text="[b]LEGENDARY SHIP REGISTRY[/b]\nThree original named ships with distinct abilities and recoverable rare components. Combine all three drops to craft a legendary drive; installation increases flight speed by 12% per drive, up to three.\n"
  for index in LEGENDARY:
   var ship=LEGENDARY[index]
   game.menu_text.text+="\n%s / %s / rare %s" % [str(ship.ship),str(ship.ability),str(ship.drop)]
   game.add_action("TRACK "+str(ship.ship)+" / "+CAPTAINS[int(index)],accept_hunt.bind(int(index)))
 elif page=="journal":game.menu_text.text="[b]GALAXY JOURNAL[/b]\n"+"\n".join(PackedStringArray(state.history))
 back()

func witness_fee() -> int:
 if state.hunt.is_empty():return 350
 var p=TEMPERAMENTS.profile(int(state.hunt.index)+7)
 return maxi(75,350-int(state.installed.get("sensor_kit",0))*75+(int(p.caution)-50)*2-(int(p.warmth)-50))

func escape_limit() -> float:
 if state.hunt.is_empty():return 120.0
 var p=TEMPERAMENTS.profile(int(state.hunt.index))
 var limit=100.0+float(p.caution)*.45-float(p.assertion)*.12
 if str(LEGENDARY.get(int(state.hunt.index),{}).get("ability",""))=="overdrive":limit-=25.0
 return maxf(60.0,limit+float(state.installed.get("legendary_drive",0))*20.0)

func toggle_tone(key: String) -> void:
 if not ["humor","soft"].has(key):return
 state.tone[key]=not bool(state.tone.get(key,false))
 persist("Dialogue preference saved: "+key+" "+("on" if bool(state.tone[key]) else "off"))
 show("personalities")

func select_profile(index: int) -> void:
 state.player_profile=clampi(index,0,3)
 persist("Captain's fictional function preference: "+TEMPERAMENTS.CODES[int(state.player_profile)])
 show("personalities")

func spawn_echo_decoy() -> void:
 if not is_instance_valid(captain):return
 var count=0
 for enemy in game.enemies:
  if is_instance_valid(enemy) and enemy.has_meta("echo_decoy"):count+=1
 if count>=2:return
 var echo=Node3D.new();game.add_child(echo)
 echo.name="Cartographer_Signal_Echo"
 echo.position=captain.position+Vector3(150,80,-70)
 game.build_enemy_visual(echo,"interceptor")
 for key in ["hp","max_hp","shield","max_shield","phase","fire_timer","engine_damage","weapon_damage","shield_damage","missile_timer","flank"]:
  echo.set_meta(key,captain.get_meta(key))
 echo.set_meta("hp",25.0);echo.set_meta("max_hp",25.0);echo.set_meta("shield",0.0);echo.set_meta("max_shield",0.0)
 echo.set_meta("class","interceptor");echo.set_meta("living_hunt",true);echo.set_meta("echo_decoy",true)
 game.enemies.append(echo)
 game.announce("Silent Cartographer released a false attack signature.")

func spawn_blockade(count: int) -> void:
 var a=state.arc
 for i in range(count):
  var e=Node3D.new();game.add_child(e)
  e.name="Silent_Blockade_Interceptor_"+str(i)
  e.position=site(int(a.third),int(a.seed)+2)+Vector3(-170+i*340,70,-210)
  game.build_enemy_visual(e,"gunship")
  e.set_meta("hp",175.0);e.set_meta("max_hp",175.0);e.set_meta("shield",80.0);e.set_meta("max_shield",80.0)
  e.set_meta("class","gunship");e.set_meta("phase",float(i));e.set_meta("fire_timer",2.0);e.set_meta("engine_damage",0.0);e.set_meta("weapon_damage",0.0);e.set_meta("shield_damage",0.0);e.set_meta("missile_timer",10.0);e.set_meta("flank",-1.0 if i==0 else 1.0)
  e.set_meta("living_arc",true)
  game.enemies.append(e)
 game.announce("Silent Blockade: armed interdiction contacts detected.")

func clear_arc_ships() -> void:
 for e in game.enemies.duplicate():
  if is_instance_valid(e) and e.has_meta("living_arc"):
   game.enemies.erase(e);e.queue_free()

# PASS 30 — interconnected relief, customs and trade intelligence.
func relief_offer(sector: int) -> Dictionary:
 var event=state.events[sector]
 var good=str(event.good) if str(event.kind)=="shortage" else ["medicines","provisions","cells","circuits"][sector%4]
 if not GOODS.has(good):good="medicines"
 var qty=4+sector%4
 var reward=qty*price(sector,good,false)+1100+sector*125
 return {"good":good,"qty":qty,"reward":reward}

func accept_relief(sector: int) -> void:
 if not require_dock():return
 var active=0
 for job in state.relief_jobs:
  if str(job.status)=="active":active+=1
 if active>=2:game.announce("Two active relief commissions maximum.");return
 var offer=relief_offer(sector)
 var id=int(state.next_id)
 state.next_id=id+1
 state.relief_jobs.append({"id":id,"sector":sector,"origin":int(game.current_system),"good":str(offer.good),"qty":int(offer.qty),"reward":int(offer.reward),"deadline":int(state.tick)+12,"faction":int(state.control[sector].owner),"status":"active"})
 persist("Relief commission accepted. Acquire the requested supplies and deliver them before the deadline.")
 show("relief")

func deliver_relief(id: int) -> void:
 if not require_dock():return
 for job in state.relief_jobs:
  if int(job.id)!=id or str(job.status)!="active":continue
  if int(game.current_system)!=int(job.sector):game.announce("Dock in the destination sector to deliver.");return
  if int(state.tick)>int(job.deadline):game.announce("Commission expired.");return
  if amount(str(job.good))<int(job.qty):game.announce("Missing supplies: need %d %s" % [int(job.qty),str(job.good)]);return
  change_cargo(str(job.good),-int(job.qty))
  state.markets[int(job.sector)][str(job.good)].stock=mini(500,int(state.markets[int(job.sector)][str(job.good)].stock)+int(job.qty))
  game.credits+=int(job.reward)
  reputation(int(job.faction),5,int(job.sector))
  xp("merchant",int(job.qty)*6)
  state.relief_completed=int(state.get("relief_completed",0))+1
  job.status="delivered"
  persist("Relief delivered: %d CR. Local faction influence increased." % int(job.reward))
  show("relief")
  return

func customs_clear() -> bool:
 var key="%d:%d" % [int(game.current_system),int(state.tick)]
 return bool(state.customs_checks.get(key,false))

func request_clearance() -> void:
 if not require_dock():return
 var sector=int(game.current_system)
 var owner=int(state.control[sector].owner)
 var key="%d:%d" % [sector,int(state.tick)]
 if customs_clear():game.announce("Already cleared this cycle.");show("customs");return
 var illicit=amount("contraband")
 var scrutiny=clampi(40-int(state.rep[owner])/3,15,75)
 var roll=posmod(int(state.tick)*17+sector*31+int(game.dock_count)*19+illicit*11,100)
 if illicit>0 and roll<scrutiny:
  var fine=mini(int(game.credits),illicit*price(sector,"contraband",false)/3+250)
  game.credits-=fine
  change_cargo("contraband",-illicit)
  reputation(owner,-3,sector)
  persist("Customs seizure: %d contraband confiscated, %d CR fine." % [illicit,fine])
 else:
  state.customs_checks[key]=true
  persist("Customs clearance issued for this cycle.")
 show("customs")

func declare_contraband() -> void:
 if not require_dock():return
 var illicit=amount("contraband")
 if illicit<=0:game.announce("No contraband to declare.");return
 change_cargo("contraband",-illicit)
 persist("Voluntary declaration: %d contraband confiscated without fine." % illicit)
 show("customs")
