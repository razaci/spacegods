extends RefCounted
# Jung-inspired four-function framework for fictional NPC behavior.
# Scores are authored game variables, not psychological measurements.
const CODES = ["Sensation", "Intuition", "Thinking", "Feeling"]
const NAMES = ["Grounded Observer", "Possibility Seeker", "Clear Reasoner", "Considerate Guide"]
const GROUPS = ["Sensation", "Intuition", "Thinking", "Feeling"]
const EXPLANATIONS = ["Notices concrete details and present conditions.", "Looks for possibilities, patterns and future implications.", "Weighs evidence, consistency and logical consequences.", "Weighs values, relationships and what matters to people."]
# Warmth, composure, caution, assertion, curiosity, humor.
const SCORES = [[65,85,80,55,45,20],[75,65,45,55,95,60],[55,90,75,70,80,25],[95,75,65,45,70,35]]
# Authored 0..100 function strengths; dominant function follows the row.
const FUNCTIONS = [[90,40,65,55],[45,92,60,70],[65,60,94,45],[60,70,50,95]]

static func profile(index: int) -> Dictionary:
 var i=posmod(index,4)
 var v=SCORES[i]
 var f=FUNCTIONS[i]
 return {"code":CODES[i],"name":NAMES[i],"group":GROUPS[i],"explanation":EXPLANATIONS[i],"sensation":f[0],"intuition":f[1],"thinking":f[2],"feeling":f[3],"warmth":v[0],"composure":v[1],"caution":v[2],"assertion":v[3],"curiosity":v[4],"humor":v[5]}

static func line(index: int, humor: bool, soft: bool) -> String:
 var i=posmod(index,4)
 var text=["The recorder shows a fuel stop and a damaged engine. Those are the details we can verify.", "The signal changes at each jump. There may be another route hidden in that pattern.", "Compare the timestamps with the route. If they agree, we have enough evidence to proceed.", "There are people aboard that ship. Their safety matters when you choose what happens next."][i]
 if humor and int(SCORES[i][5])>=50:text+=" Even a pirate has to stop for supplies."
 if soft:text="Take your time. "+text
 return text
