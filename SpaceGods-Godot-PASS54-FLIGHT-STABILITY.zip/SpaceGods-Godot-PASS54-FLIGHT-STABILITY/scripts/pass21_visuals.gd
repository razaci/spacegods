extends Node3D
# PASS 21 / GRAPHICS: purely visual nodes. No gameplay state or collision modifications.
var game
var quality: int = 2
var ship_details: Node3D
var station_details: Node3D
var sector_details: Node3D
var engine_flares: Array[MeshInstance3D] = []
var nebulae: Array[MeshInstance3D] = []
var atmosphere: MeshInstance3D
var scene_lights: Array[Light3D] = []
var elapsed: float = 0.0

func initialize(root: Node3D) -> void:
 game = root
 add_station_details()
 refresh_ship()

func surface_material(color: Color, metal: float = 0.0, rough: float = 0.4, emission: float = 0.0) -> StandardMaterial3D:
 var m = StandardMaterial3D.new()
 m.albedo_color = color
 m.metallic = metal
 m.roughness = rough
 if emission > 0.0:
  m.emission_enabled = true
  m.emission = color
  m.emission_energy_multiplier = emission
 return m

func mesh_part(parent: Node3D, mesh: Mesh, at: Vector3, mat: Material) -> MeshInstance3D:
 var n = MeshInstance3D.new()
 n.mesh = mesh
 n.position = at
 n.material_override = mat
 n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 parent.add_child(n)
 return n

func box_part(parent: Node3D, at: Vector3, dims: Vector3, mat: Material) -> MeshInstance3D:
 var mesh = BoxMesh.new()
 mesh.size = dims
 return mesh_part(parent,mesh,at,mat)

func orb(parent: Node3D, at: Vector3, radius: float, mat: Material, sides: int = 20) -> MeshInstance3D:
 var mesh = SphereMesh.new()
 mesh.radius = radius
 mesh.height = radius*2.0
 mesh.radial_segments = sides
 mesh.rings = 12
 return mesh_part(parent,mesh,at,mat)

func cylinder(parent: Node3D, at: Vector3, radius: float, height: float, mat: Material) -> MeshInstance3D:
 var mesh = CylinderMesh.new()
 mesh.top_radius = radius
 mesh.bottom_radius = radius
 mesh.height = height
 mesh.radial_segments = 14
 return mesh_part(parent,mesh,at,mat)

func add_station_details() -> void:
 if not is_instance_valid(game.station): return
 station_details = Node3D.new()
 station_details.name = "P21_CommandCenter_IlluminatedArchitecture"
 game.station.add_child(station_details)
 var metal = surface_material(Color(0.14,0.23,0.31),0.85,0.24)
 var ceramic = surface_material(Color(0.39,0.50,0.60),0.72,0.32)
 var cyan = surface_material(Color(0.13,0.83,1.0),0.2,0.16,2.8)
 var amber = surface_material(Color(1.0,0.53,0.15),0.1,0.2,2.4)
 # Faceted observation domes, docking rails and glowing portholes.
 for ring in range(3):
  var z = -40.0+float(ring)*60.0
  for i in range(24):
   var a = TAU*float(i)/24.0
   var p = Vector3(cos(a)*275.0,sin(a)*275.0,z)
   var shell = orb(station_details,p,7.0,ceramic,12)
   shell.scale = Vector3(1.0,0.62,0.48)
   orb(station_details,p+Vector3(0,0,4),3.5,cyan if i%4!=0 else amber,10)
 for side in [-1.0,1.0]:
  for i in range(12):
   var z = -82.0+float(i)*17.0
   box_part(station_details,Vector3(side*72.0,-137.0,z+185.0),Vector3(1.4,0.8,9.0),cyan)
  box_part(station_details,Vector3(side*84.0,-100.0,190.0),Vector3(3.0,6.0,205.0),metal)
 for i in range(8):
  var a = TAU*float(i)/8.0
  var x = cos(a)*105.0
  var y = sin(a)*105.0
  var module = cylinder(station_details,Vector3(x,y,110),11.0,54.0,metal)
  module.rotation.x = PI*0.5
  orb(station_details,Vector3(x,y,140),9.0,amber if i%2 else cyan,12)
 # Real localized lights are limited to the hangar, not one per window.
 for side in [-1.0,1.0]:
  var light = OmniLight3D.new()
  light.position = Vector3(side*55.0,-91.0,195.0)
  light.light_color = Color(0.28,0.79,1.0)
  light.light_energy = 0.75
  light.omni_range = 170.0
  light.shadow_enabled = false
  station_details.add_child(light)
  scene_lights.append(light)

func refresh_ship() -> void:
 if not is_instance_valid(game.fleet_visual): return
 if is_instance_valid(ship_details): ship_details.queue_free()
 ship_details = Node3D.new()
 ship_details.name = "P21_ArmoredPlating_EngineNozzles_Decals"
 game.fleet_visual.add_child(ship_details)
 engine_flares.clear()
 var ship_type = int(game.ship_class)
 var size = [17.0,22.0,32.0,29.0,48.0][ship_type]
 var length = [29.0,35.0,43.0,38.0,66.0][ship_type]
 var deck = [3.0,4.0,7.0,5.0,12.0][ship_type]
 var paint: Color = game.ship_paint()
 var armor = surface_material(paint.lightened(0.10),0.92,0.22)
 var seam = surface_material(paint.darkened(0.55),0.72,0.42)
 var stripe = surface_material(Color(0.91,0.71,0.32),0.63,0.24)
 var glass = surface_material(Color(0.025,0.18,0.29),0.48,0.07)
 var engine_mat = surface_material(Color(0.12,0.78,1.0),0.0,0.2,3.6)
 var thrust_mat = surface_material(Color(0.52,0.91,1.0),0.0,0.2,4.2)
 # Long, layered armor ribs and recesses produce a distinct silhouette per hull.
 for side in [-1.0,1.0]:
  for i in range(6 if ship_type>=3 else 4):
   var z = -length*0.65+float(i)*length*0.24
   var panel = box_part(ship_details,Vector3(side*size*0.30,deck*0.53,z),Vector3(size*0.23,0.35,length*0.14),armor if i%2==0 else seam)
   panel.rotation.y = side*0.11
  var rail = box_part(ship_details,Vector3(side*size*0.62,0.75,length*0.14),Vector3(0.9,1.6,length*0.65),stripe)
  rail.rotation.y = side*0.16
  # Concentric nozzle rings, luminous afterburner and exhaust cone.
  var x = side*size*0.50
  var nozzle = cylinder(ship_details,Vector3(x,-1.0,length*0.58),maxf(2.0,deck*0.4),5.5,seam)
  nozzle.rotation.x = PI*0.5
  orb(ship_details,Vector3(x,-1.0,length*0.66),maxf(1.7,deck*0.35),engine_mat,20)
  var plume = orb(ship_details,Vector3(x,-1.0,length*0.86),maxf(1.7,deck*0.34),thrust_mat,16)
  plume.scale = Vector3(0.6,0.6,3.0)
  engine_flares.append(plume)
  for i in range(3):
   var z = -length*0.32+float(i)*length*0.27
   box_part(ship_details,Vector3(side*size*0.12,deck+1.3,z),Vector3(0.65,0.5,length*0.1),stripe)
 # Transparent-looking dark cockpit canopy plus structural frame.
 var canopy = orb(ship_details,Vector3(0,deck+2.3,-length*0.30),maxf(3.0,deck*0.65),glass,24)
 canopy.scale = Vector3(0.92,0.48,1.8)
 for i in range(5):
  var z = -length*0.55+float(i)*length*0.12
  box_part(ship_details,Vector3(0,deck+2.0,z),Vector3(size*0.36,0.25,0.55),seam)
 if ship_type>=3:
  for side in [-1.0,1.0]:
   for i in range(3 if ship_type==4 else 2):
    var z = -length*0.15+float(i)*length*0.19
    cylinder(ship_details,Vector3(side*size*0.38,deck*1.65,z),1.8,9.0,seam).rotation.x = PI*0.5
    orb(ship_details,Vector3(side*size*0.38,deck*1.65,z-6),1.1,stripe,12)
 apply_quality(quality)

func refresh_sector(which: int) -> void:
 if is_instance_valid(sector_details): sector_details.queue_free()
 sector_details = Node3D.new()
 sector_details.name = "P21_PlanetaryAtmosphere_NebulaBackdrops"
 game.add_child(sector_details)
 nebulae.clear()
 atmosphere = null
 if is_instance_valid(game.world_planet):
  var texture = load("res://art/textures/planet_%d.png" % which) as Texture2D
  if texture != null:
   var planet_mat = StandardMaterial3D.new()
   planet_mat.albedo_texture = texture
   planet_mat.metallic = 0.02
   planet_mat.roughness = 0.87
   planet_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
   game.world_planet.material_override = planet_mat
  var atm = Shader.new()
  atm.code = "shader_type spatial; render_mode unshaded, blend_mix, depth_draw_never, cull_back; uniform vec4 glow_color : source_color = vec4(0.13,0.63,0.95,1.0); void fragment(){float edge=pow(1.0-abs(dot(normalize(NORMAL),normalize(VIEW))),3.5); ALBEDO=glow_color.rgb; EMISSION=glow_color.rgb*edge*0.9; ALPHA=edge*0.40;}"
  var halo_mat = ShaderMaterial.new()
  halo_mat.shader = atm
  var tint: Color = Color.from_hsv(float(which)/7.0,0.52,0.76)
  halo_mat.set_shader_parameter("glow_color",Vector4(tint.r+0.2,tint.g+0.3,tint.b+0.3,1.0))
  atmosphere = orb(sector_details,game.world_planet.global_position,1250.0 if which!=4 else 1630.0,halo_mat,48)
  atmosphere.scale = Vector3(1.0,0.92,1.0)
 # Nebula artwork uses transparent quad sprites, only 4 cards per sector.
 for i in range(4):
  var texture = load("res://art/textures/nebula_%d.png" % ((i+which)%4)) as Texture2D
  if texture == null: continue
  var mat = StandardMaterial3D.new()
  mat.albedo_texture = texture
  mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
  mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
  mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
  mat.cull_mode = BaseMaterial3D.CULL_DISABLED
  mat.no_depth_test = true
  var quad = QuadMesh.new()
  quad.size = Vector2(4500.0,3500.0)
  var offset = Vector3(-7800.0+float(i)*4400.0,2800.0+float((i+which)%3)*1500.0,-14000.0-float(i%2)*3800.0)
  var card = mesh_part(sector_details,quad,(game.station_position+Vector3(700,-80,1700))+offset,mat)
  nebulae.append(card)
 apply_quality(quality)

func apply_quality(level: int) -> void:
 quality = clampi(level,0,2)
 if is_instance_valid(ship_details):
  for part in ship_details.get_children():
   if part is MeshInstance3D: part.visible = quality>=1 or engine_flares.has(part)
 if is_instance_valid(station_details): station_details.visible = quality>=1
 for lamp in scene_lights:
  if is_instance_valid(lamp): lamp.visible = quality==2
 if is_instance_valid(atmosphere): atmosphere.visible = quality>=1
 for card in nebulae:
  if is_instance_valid(card): card.visible = quality==2
 if game.world_env != null:
  game.world_env.glow_enabled = quality==2
  game.world_env.glow_intensity = 0.7
  game.world_env.glow_strength = 0.85

func animate(dt: float) -> void:
 elapsed += dt
 if not is_instance_valid(game.fleet_visual): return
 for i in range(engine_flares.size()):
  var plume = engine_flares[i]
  if not is_instance_valid(plume): continue
  plume.scale = Vector3(0.62,0.62,2.0+float(game.throttle)*2.5+(1.5 if game.boost_active else 0.0)+0.18*sin(elapsed*27.0+float(i)))
  plume.visible = bool(game.chase) and not bool(game.docked)
