extends Node
# Non-modal contextual pilot coaching: deliberately small and low-cost.
var game
var panel: PanelContainer
var label: Label
var visible_tips := true
var elapsed := 0.0
var previous_tip := ""

func initialize(host) -> void:
 game = host
 var layer := CanvasLayer.new()
 layer.layer = 12
 add_child(layer)
 panel = PanelContainer.new()
 panel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
 panel.anchor_left = 1.0
 panel.anchor_right = 1.0
 panel.offset_left = -350.0
 panel.offset_right = -12.0
 panel.offset_top = 75.0
 panel.offset_bottom = 140.0
 panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
 layer.add_child(panel)
 label = Label.new()
 label.custom_minimum_size = Vector2(315, 44)
 label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 label.add_theme_font_size_override("font_size", 13)
 label.mouse_filter = Control.MOUSE_FILTER_IGNORE
 panel.add_child(label)
 update_tip(10.0)

func toggle() -> void:
 visible_tips = not visible_tips
 panel.visible = visible_tips and not game.menu_open

func update_tip(dt: float) -> void:
 if not is_instance_valid(panel): return
 panel.visible = visible_tips and not game.menu_open
 if not panel.visible: return
 elapsed += dt
 if elapsed < 0.6: return
 elapsed = 0.0
 var tip := "F10 TIPS  |  SHIFT+F10 HELP ACADEMY"
 if game.engine_cutoff:
  tip += "\nENGINES OFF: Press ~ to restart."
 elif game.fuel < 13.0:
  tip += "\nLOW FUEL: Shift+F1 > Distress for recovery."
 elif game.hull_hp < game.max_hull() * 0.28:
  tip += "\nCRITICAL HULL: Ctrl+6 manual; seek repair."
 elif game.p38_nav_mode != 0:
  tip += "\nAUTO NAV: Ctrl+6 manual / Ctrl+0 cancel."
 elif game.enemies.size() > 0:
  tip += "\nCOMBAT: Tab target / T subsystem / F fire."
 elif game.docked:
  tip += "\nDOCKED: Shift+F1 opens station services."
 elif game.throttle < 0.05:
  tip += "\nIDLE: 1-9 throttle, 0 full, X all-stop."
 else:
  tip += "\nFLIGHT: Ctrl+7 waypoint / Ctrl+9 auto-dock."
 if tip != previous_tip:
  previous_tip = tip
  label.text = tip
