extends Node

var game: Node3D

func _ready() -> void:
 game = get_parent()
 if "--capture-galaxy" in OS.get_cmdline_user_args():
  call_deferred("capture_galaxy")
 if "--capture-review" in OS.get_cmdline_user_args():
  call_deferred("capture_review")

func _unhandled_key_input(event: InputEvent) -> void:
 if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F12 and event.ctrl_pressed:
  await RenderingServer.frame_post_draw
  var path = "user://capture_%s.png" % Time.get_datetime_string_from_system().replace(":", "-")
  var status = get_viewport().get_texture().get_image().save_png(path)
  game.announce("SCREENSHOT: " + ProjectSettings.globalize_path(path) if status == OK else "SCREENSHOT FAILED")

func capture_review() -> void:
 await get_tree().process_frame
 game.close_menu()
 game.alert_label.visible = false
 game.ship_class = 4
 game.rebuild_ship_model()
 game.docked = false
 game.chase = true
 game.throttle = 0.0
 game.velocity = 0.0
 game.linear_velocity = Vector3.ZERO
 game.flight_pos = game.station_position + Vector3(0, 100, 1000)
 game.player.position = game.flight_pos
 game.player.rotation = Vector3.ZERO
 game.set_process(false)
 game.update_hud()
 game.camera.global_position = game.flight_pos + Vector3(105, 70, 165)
 game.camera.look_at(game.flight_pos + Vector3(0, 4, 0))
 game.camera.fov = 60.0
 await get_tree().create_timer(3.0).timeout
 await RenderingServer.frame_post_draw
 var folder = "res://review_captures"
 DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(folder))
 var status = get_viewport().get_texture().get_image().save_png(folder + "/01-dreadnought-flight.png")
 print("CAPTURE FLIGHT STATUS ", status)
 game.camera.global_position = game.station_position + Vector3(400, 300, 950)
 game.camera.look_at(game.station_position)
 await get_tree().create_timer(2.0).timeout
 await RenderingServer.frame_post_draw
 status = get_viewport().get_texture().get_image().save_png(folder + "/02-command-center.png")
 print("CAPTURE STATION STATUS ", status)
 get_tree().quit()

func capture_galaxy() -> void:
 await get_tree().process_frame
 game.set_process(false)
 game.living_galaxy.set_process(false)
 game.alert_label.visible=false
 game.camera.global_position=game.station_position+Vector3(350,240,950)
 game.camera.look_at(game.station_position)
 var folder="res://galaxy_captures"
 DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(folder))
 for page in ["hub","personalities","personality_3","legendary","markets"]:
  game.living_galaxy.show(page)
  await get_tree().create_timer(1.5).timeout
  await RenderingServer.frame_post_draw
  var status=get_viewport().get_texture().get_image().save_png(folder+"/"+page+".png")
  print("GALAXY CAPTURE ",page," STATUS ",status)
 get_tree().quit()
