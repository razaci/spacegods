extends Node3D
# PASS 22: Desktop Forward+ graphics, independent of mission/combat/save state.
# All new nodes are visual only, with no collisions or mission modifications.
var game: Node3D
var quality: int = 2
var hero_details: Node3D
var orbit_details: Node3D
var engine_trails: Array[GPUParticles3D] = []
var extra_lights: Array[Light3D] = []
var cinematic_material: ShaderMaterial
var seconds: float = 0.0

func initialize(root: Node3D) -> void:
 game = root
 make_ship_material()
 refresh_ship()
 refresh_sector(int(game.current_system))

func make_ship_material() -> void:
 var shader = Shader.new()
 shader.code = """shader_type spatial;
render_mode specular_schlick_ggx, diffuse_burley;
uniform sampler2D detail_tex : source_color, filter_linear_mipmap, repeat_enable;
uniform sampler2D normal_tex : hint_normal, filter_linear_mipmap, repeat_enable;
uniform sampler2D rough_tex : hint_roughness_r, filter_linear_mipmap, repeat_enable;
uniform vec4 hull_tint : source_color = vec4(0.28,0.47,0.64,1.0);
uniform float metalness : hint_range(0.0,1.0) = 0.87;
uniform float panel_scale = 8.0;
void fragment() {
 vec2 uv = UV * panel_scale;
 vec3 brushed = texture(detail_tex,uv).rgb;
 ALBEDO = hull_tint.rgb * mix(vec3(0.80),brushed*1.9,0.38);
 METALLIC = metalness;
 ROUGHNESS = clamp(texture(rough_tex,uv).r*0.7+0.15,0.12,0.75);
 NORMAL_MAP = texture(normal_tex,uv).rgb;
 NORMAL_MAP_DEPTH = 0.3;
 SPECULAR = 0.85;
}"""
 cinematic_material = ShaderMaterial.new()
 cinematic_material.shader = shader
 cinematic_material.set_shader_parameter("detail_tex",load("res://art/textures/p22_brushed_metal.png"))
 cinematic_material.set_shader_parameter("normal_tex",load("res://art/textures/p22_normal.png"))
 cinematic_material.set_shader_parameter("rough_tex",load("res://art/textures/p22_roughness.png"))

func create_part(parent: Node3D, mesh: Mesh, at: Vector3, material: Material) -> MeshInstance3D:
 var node = MeshInstance3D.new()
 node.mesh = mesh
 node.position = at
 node.material_override = material
 parent.add_child(node)
 return node

func make_glow(c: Color, strength: float) -> StandardMaterial3D:
 var m = StandardMaterial3D.new()
 m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 m.albedo_color = c
 m.emission_enabled = true
 m.emission = c
 m.emission_energy_multiplier = strength
 return m

func refresh_ship() -> void:
 if not is_instance_valid(game.fleet_visual): return
 if is_instance_valid(hero_details): hero_details.queue_free()
 hero_details = Node3D.new()
 hero_details.name = "P22_RefinedHardpoints_EngineParticles"
 game.fleet_visual.add_child(hero_details)
 engine_trails.clear()
 var cls: int = clampi(int(game.ship_class),0,4)
 var wingspan: float = [17.0,22.0,32.0,29.0,48.0][cls]
 var length: float = [29.0,35.0,43.0,38.0,66.0][cls]
 cinematic_material.set_shader_parameter("hull_tint",game.ship_paint())
 var plating = cinematic_material
 var accent = make_glow(Color(0.11,0.69,1.0),2.5)
 var ember = make_glow(Color(0.95,0.52,0.13),2.5)
 # Shaped tapered winglets: no placeholder cube slabs.
 for side in [-1.0,1.0]:
  var st = SurfaceTool.new()
  st.begin(Mesh.PRIMITIVE_TRIANGLES)
  var a = Vector3(side*wingspan*.18,1.8,-length*.40)
  var b = Vector3(side*wingspan*.92,.2,length*.20)
  var c = Vector3(side*wingspan*.22,.8,length*.47)
  var d = Vector3(side*wingspan*.22,-.8,-length*.20)
  for tri in [[a,b,c],[c,b,d],[c,b,a],[d,b,c]]:
   for v in tri:
    st.set_uv(Vector2(v.x*.035,v.z*.035))
    st.add_vertex(v)
  st.generate_normals()
  create_part(hero_details,st.commit(),Vector3.ZERO,plating)
  for j in range(3):
   var beacon = SphereMesh.new()
   beacon.radius = 0.8
   beacon.height = 1.6
   beacon.radial_segments = 10
   create_part(hero_details,beacon,Vector3(side*wingspan*.66,0.7,length*(-.22+float(j)*.20)),accent if j%2==0 else ember)
  var particles = GPUParticles3D.new()
  particles.name = "EnginePlasma"
  particles.position = Vector3(side*wingspan*.50,-1.0,length*.67)
  particles.amount = 24
  particles.lifetime = .45
  particles.explosiveness = 0.0
  particles.local_coords = true
  particles.visibility_aabb = AABB(Vector3(-7,-7,-5),Vector3(14,14,45))
  var process = ParticleProcessMaterial.new()
  process.direction = Vector3(0,0,1)
  process.spread = 11.0
  process.gravity = Vector3.ZERO
  process.initial_velocity_min = 23.0
  process.initial_velocity_max = 42.0
  process.scale_min = .6
  process.scale_max = 1.6
  process.color = Color(0.3,0.77,1.0,0.85)
  particles.process_material = process
  var sphere = SphereMesh.new()
  sphere.radius = 1.3
  sphere.height = 2.6
  sphere.radial_segments = 8
  sphere.material = accent
  particles.draw_pass_1 = sphere
  hero_details.add_child(particles)
  particles.emitting = true
  engine_trails.append(particles)
 apply_quality(quality)

func refresh_sector(_which: int) -> void:
 if is_instance_valid(orbit_details): orbit_details.queue_free()
 orbit_details = Node3D.new()
 orbit_details.name = "P22_OrbitLighting_StationRingAccents"
 game.add_child(orbit_details)
 extra_lights.clear()
 if is_instance_valid(game.station):
  var ring = TorusMesh.new()
  ring.inner_radius = 265.0
  ring.outer_radius = 269.0
  ring.rings = 8
  ring.ring_segments = 96
  var glow = make_glow(Color(0.09,0.65,1.0),2.4)
  var torus = create_part(orbit_details,ring,game.station.global_position,glow)
  torus.rotation.x = PI*0.5
  # A handful of physical lights, not hundreds of point lights.
  for i in range(3):
   var lamp = OmniLight3D.new()
   lamp.position = game.station.global_position + Vector3(cos(float(i)*TAU/3.0)*150.0,80.0,sin(float(i)*TAU/3.0)*150.0)
   lamp.light_color = Color(0.25,0.75,1.0)
   lamp.light_energy = 1.25
   lamp.omni_range = 160.0
   lamp.shadow_enabled = false
   orbit_details.add_child(lamp)
   extra_lights.append(lamp)
 apply_quality(quality)

func apply_quality(level: int) -> void:
 quality = clampi(level,0,2)
 if is_instance_valid(hero_details):
  for child in hero_details.get_children():
   if child is GPUParticles3D: child.emitting = quality==2
   elif child is MeshInstance3D: child.visible = quality>=1
 if is_instance_valid(orbit_details): orbit_details.visible = quality>=1
 for light in extra_lights:
  if is_instance_valid(light): light.visible = quality==2
 if game.world_env != null:
  var env: Environment = game.world_env
  env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
  env.glow_enabled = quality==2
  env.glow_intensity = 0.85
  env.glow_strength = 1.0
  env.ssao_enabled = quality==2
  env.ssil_enabled = quality==2
  env.ssr_enabled = quality==2
  env.volumetric_fog_enabled = quality==2
  env.volumetric_fog_density = 0.00005

func animate(dt: float) -> void:
 seconds += dt
 if not is_instance_valid(hero_details): return
 var thrust: float = clampf(float(game.throttle),0.0,1.0)
 for p in engine_trails:
  if is_instance_valid(p):
   p.speed_scale = .65+thrust*1.7
