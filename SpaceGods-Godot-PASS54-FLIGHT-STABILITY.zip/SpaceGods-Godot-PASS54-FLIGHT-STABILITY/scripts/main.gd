extends Node3D
# SPACE GODS / GODOT 4 / PASS 22: FORWARD+ CINEMATIC / SHIPWORKS / GALAXY
# All world meshes, HUD, flight and gameplay are generated at runtime.
const SAVE_PATH = "user://space_gods_native_v10.json"
const SAVE_BACKUP_PATH = "user://space_gods_native_v10.backup.json"
const SAVE_TEMP_PATH = "user://space_gods_native_v10.pending.json"
const HUD_REFRESH_INTERVAL = 0.12
const SAVE_SCHEMA_VERSION = 20
const SAVE_MAX_BYTES = 3000000
var pass20_low_detail = false
var pass21_visuals
var pass22_visuals
var living_galaxy
var command_nexus
var pass46_auto: Node
var pass45_help
var pass50_starport
var living_saved_state: Dictionary = {}
var pass27_dreadnought
var pass21_quality = 2 # 0 PERFORMANCE, 1 BALANCED, 2 CINEMATIC
var pass20_checks: Array[String] = []
var pass20_recoveries = 0
var pass20_last_check = "NOT RUN"
var pass20_asteroids: Array[Node3D] = []
var startup_checked = false
var recovered_pending_save = false
var save_write_busy = false
var runtime_warnings: Array[String] = []
var hud_refresh_timer = 0.0
var diagnostics_visible = false
var diagnostics_label: Label
var diagnostics_refresh_timer = 0.0
var autosave_failures = 0
var last_save_ok = true
var last_save_status = "NOT SAVED"
var frame_count = 0
var frame_seconds = 0.0
var measured_fps = 0.0
var performance_mode = true
var ui_minimized = false
var ui_left_panel: PanelContainer
var ui_help_strip: Label
var ui_nav_panel: Label
var ui_docking_panel: Label

const COLORS = {"hull": Color(0.18,0.30,0.42),"edge": Color(0.42,0.65,0.75),"glow": Color(0.10,0.80,1.0),"enemy": Color(0.68,0.19,0.20),"gold": Color(1.0,0.69,0.22)}
const SYSTEM_NAMES = ["GODS COMMAND", "MOON BASE", "BLACKGLASS REACH", "THE PALE REACH", "EMBER CROWN", "GHOST TIDE", "CITADEL VEIL"]
const SYSTEM_TINTS = [Color(0.08,0.30,0.56),Color(0.37,0.40,0.48),Color(0.42,0.13,0.56),Color(0.13,0.54,0.46),Color(0.66,0.23,0.13),Color(0.12,0.50,0.63),Color(0.42,0.30,0.67)]
const SECTOR_ORIGINS = [Vector3.ZERO,Vector3(105000,0,-12000),Vector3(220000,0,-36000),Vector3(330000,0,-13000),Vector3(90000,0,145000),Vector3(225000,0,153000),Vector3(345000,0,151000)]
const SECTOR_LINKS = [[1,4],[0,2,4],[1,3,5],[2,5,6],[0,1,5],[2,3,4,6],[3,5]]
const SECTOR_DESCRIPTIONS = ["Home defense / trade / command hangars", "Lunar outpost / cold mineral belt", "Raider territory / darkglass debris", "Ancient gateway / uncharted physics", "Red giant / burning debris sea", "Ion storms / drifting signal ruins", "Lost fortress / high-threat perimeter"]
const MISSIONS = [
 {"name":"Aurora Corridor Patrol","type":"patrol","sector":0,"goal":Vector3(-4500.0,70.0,-3600.0),"second":Vector3(-2300.0,-220.0,-7200.0),"reward":2700,"need":2,"first":"combat","final":"scan"},
 {"name":"Cold Relay Rescue","type":"rescue","sector":1,"goal":Vector3(101497.0,183.0,-16979.0),"second":Vector3(104423.0,-9.0,-21113.0),"reward":3140,"need":1,"first":"rescue","final":"escort"},
 {"name":"Blackglass Ambush","type":"combat","sector":2,"goal":Vector3(217494.0,296.0,-42358.0),"second":Vector3(221146.0,202.0,-47026.0),"reward":3580,"need":2,"first":"combat","final":"combat"},
 {"name":"Pale Reach Signal","type":"scan","sector":3,"goal":Vector3(328491.0,409.0,-20737.0),"second":Vector3(332869.0,413.0,-25939.0),"reward":4020,"need":1,"first":"scan","final":"salvage"},
 {"name":"Ember Convoy","type":"escort","sector":4,"goal":Vector3(89488.0,522.0,135884.0),"second":Vector3(94592.0,-96.0,137048.0),"reward":4460,"need":1,"first":"escort","final":"combat"},
 {"name":"Ghost Tide Survey","type":"explore","sector":5,"goal":Vector3(225485.0,95.0,142505.0),"second":Vector3(220115.0,115.0,143135.0),"reward":4900,"need":1,"first":"scan","final":"explore"},
 {"name":"Citadel Defense","type":"defense","sector":6,"goal":Vector3(346482.0,208.0,146226.0),"second":Vector3(341838.0,326.0,139222.0),"reward":5340,"need":1,"first":"defense","final":"combat"},
 {"name":"Command Supply Run","type":"delivery","sector":0,"goal":Vector3(2479.0,321.0,-6153.0),"second":Vector3(-1439.0,-183.0,-6791.0),"reward":4520,"need":1,"first":"delivery","final":"scan"},
 {"name":"Lunar Black Box","type":"salvage","sector":1,"goal":Vector3(108476.0,434.0,-19532.0),"second":Vector3(109584.0,28.0,-23804.0),"reward":4960,"need":1,"first":"salvage","final":"combat"},
 {"name":"Glassknife Raiders","type":"combat","sector":2,"goal":Vector3(224473.0,547.0,-44911.0),"second":Vector3(226307.0,239.0,-49717.0),"reward":5400,"need":2,"first":"combat","final":"combat"},
 {"name":"Silent Observatory","type":"scan","sector":3,"goal":Vector3(325770.0,120.0,-23290.0),"second":Vector3(333730.0,450.0,-25530.0),"reward":5840,"need":1,"first":"scan","final":"salvage"},
 {"name":"Burning Freighter","type":"rescue","sector":4,"goal":Vector3(86767.0,233.0,140431.0),"second":Vector3(95453.0,-59.0,137457.0),"reward":6280,"need":1,"first":"rescue","final":"escort"},
 {"name":"Phantom Escort","type":"escort","sector":5,"goal":Vector3(222764.0,346.0,147052.0),"second":Vector3(220976.0,152.0,143544.0),"reward":6720,"need":1,"first":"escort","final":"combat"},
 {"name":"Bastion Interdiction","type":"patrol","sector":6,"goal":Vector3(343761.0,459.0,143673.0),"second":Vector3(342699.0,363.0,139631.0),"reward":7160,"need":2,"first":"combat","final":"scan"},
 {"name":"Perimeter Ghosts","type":"scan","sector":0,"goal":Vector3(-242.0,572.0,-8706.0),"second":Vector3(3722.0,-146.0,-9482.0),"reward":6340,"need":1,"first":"scan","final":"salvage"},
 {"name":"Icefield Extraction","type":"salvage","sector":1,"goal":Vector3(105755.0,145.0,-22085.0),"second":Vector3(110445.0,65.0,-23395.0),"reward":6780,"need":1,"first":"salvage","final":"combat"},
 {"name":"Shattered Crown","type":"explore","sector":2,"goal":Vector3(221752.0,258.0,-40364.0),"second":Vector3(222868.0,276.0,-46208.0),"reward":7220,"need":1,"first":"scan","final":"explore"},
 {"name":"Pale Gate Calibration","type":"gate","sector":3,"goal":Vector3(332749.0,371.0,-18743.0),"second":Vector3(334591.0,487.0,-25121.0),"reward":7660,"need":1,"first":"scan","final":"gate"},
 {"name":"Ashfall Evacuation","type":"rescue","sector":4,"goal":Vector3(93746.0,484.0,137878.0),"second":Vector3(85114.0,-22.0,137866.0),"reward":8100,"need":1,"first":"rescue","final":"escort"},
 {"name":"Ion Storm Defense","type":"defense","sector":5,"goal":Vector3(229743.0,597.0,144499.0),"second":Vector3(221837.0,189.0,143953.0),"reward":8540,"need":1,"first":"defense","final":"combat"},
 {"name":"Citadel Courier","type":"delivery","sector":6,"goal":Vector3(341040.0,170.0,141120.0),"second":Vector3(347860.0,400.0,136940.0),"reward":8980,"need":1,"first":"delivery","final":"scan"},
 {"name":"Gods Command Red Alert","type":"defense","sector":0,"goal":Vector3(-2963.0,283.0,-4159.0),"second":Vector3(283.0,-109.0,-12873.0),"reward":8160,"need":1,"first":"defense","final":"combat"},
 {"name":"Moon Convoy Shield","type":"escort","sector":1,"goal":Vector3(103034.0,396.0,-17538.0),"second":Vector3(107006.0,102.0,-19886.0),"reward":8600,"need":1,"first":"escort","final":"combat"},
 {"name":"Blackglass Contraband","type":"salvage","sector":2,"goal":Vector3(219031.0,509.0,-42917.0),"second":Vector3(223729.0,313.0,-45799.0),"reward":9040,"need":1,"first":"salvage","final":"combat"},
 {"name":"Whispering Beacon","type":"scan","sector":3,"goal":Vector3(330028.0,82.0,-21296.0),"second":Vector3(335452.0,-196.0,-24712.0),"reward":9480,"need":1,"first":"scan","final":"salvage"},
 {"name":"Cinder Line Patrol","type":"patrol","sector":4,"goal":Vector3(91025.0,195.0,135325.0),"second":Vector3(85975.0,15.0,138275.0),"reward":9920,"need":2,"first":"combat","final":"scan"},
 {"name":"Ghost Fleet Pursuit","type":"combat","sector":5,"goal":Vector3(227022.0,308.0,149046.0),"second":Vector3(222698.0,226.0,144362.0),"reward":10360,"need":2,"first":"combat","final":"combat"},
 {"name":"Fortress Archive","type":"gate","sector":6,"goal":Vector3(348019.0,421.0,145667.0),"second":Vector3(344421.0,437.0,140449.0),"reward":10800,"need":1,"first":"scan","final":"gate"},
 {"name":"Orbital Medical Shuttle","type":"delivery","sector":0,"goal":Vector3(4016.0,534.0,-6712.0),"second":Vector3(1144.0,-72.0,-12464.0),"reward":9980,"need":1,"first":"delivery","final":"scan"},
 {"name":"Lunar Distress Choir","type":"rescue","sector":1,"goal":Vector3(110013.0,107.0,-20091.0),"second":Vector3(116467.0,139.0,-25677.0),"reward":10420,"need":1,"first":"rescue","final":"escort"},
 {"name":"Darkglass Wreck Hunt","type":"salvage","sector":2,"goal":Vector3(216310.0,220.0,-45470.0),"second":Vector3(224590.0,350.0,-45390.0),"reward":10860,"need":1,"first":"salvage","final":"combat"},
 {"name":"Unmapped Corridor","type":"explore","sector":3,"goal":Vector3(327307.0,333.0,-16749.0),"second":Vector3(325113.0,-159.0,-24303.0),"reward":11300,"need":1,"first":"scan","final":"explore"},
 {"name":"Ember Firebreak","type":"defense","sector":4,"goal":Vector3(88304.0,446.0,139872.0),"second":Vector3(91136.0,52.0,135584.0),"reward":11740,"need":1,"first":"defense","final":"combat"},
 {"name":"Tidebreaker Escort","type":"escort","sector":5,"goal":Vector3(224301.0,559.0,146493.0),"second":Vector3(227859.0,263.0,141671.0),"reward":12180,"need":1,"first":"escort","final":"combat"},
 {"name":"Citadel Core Scan","type":"scan","sector":6,"goal":Vector3(345298.0,132.0,143114.0),"second":Vector3(349582.0,474.0,137758.0),"reward":12620,"need":1,"first":"scan","final":"salvage"},
 {"name":"Command Last Watch","type":"patrol","sector":0,"goal":Vector3(1295.0,245.0,-9265.0),"second":Vector3(6305.0,-35.0,-15155.0),"reward":11800,"need":2,"first":"combat","final":"scan"},
 {"name":"Moon Shadow Raiders","type":"combat","sector":1,"goal":Vector3(107292.0,358.0,-22644.0),"second":Vector3(108728.0,176.0,-19068.0),"reward":12240,"need":2,"first":"combat","final":"combat"},
 {"name":"Blackglass Data Courier","type":"delivery","sector":2,"goal":Vector3(223289.0,471.0,-40923.0),"second":Vector3(225451.0,387.0,-44981.0),"reward":12680,"need":1,"first":"delivery","final":"scan"},
 {"name":"Pale Rift Rescue","type":"rescue","sector":3,"goal":Vector3(334286.0,584.0,-19302.0),"second":Vector3(325974.0,-122.0,-23894.0),"reward":13120,"need":1,"first":"rescue","final":"escort"},
 {"name":"Citadel Veil Revelation","type":"gate","sector":6,"goal":Vector3(340583.0,157.0,143319.0),"second":Vector3(342697.0,89.0,138193.0),"reward":13920,"need":1,"first":"scan","final":"gate"},
]
var player: Node3D
var camera: Camera3D
var ship_visual: Node3D
var station: Node3D
var ui_layer: CanvasLayer
var hud: Label
var mission_hud: Label
var alert_label: Label
var menu: PanelContainer
var menu_title: Label
var menu_text: RichTextLabel
var menu_actions: VBoxContainer
var reticle: Label
var flight_pos = Vector3(0,0,0)
var station_position = Vector3(-700,80,-1700)
var velocity = 0.0
var throttle = 0.0
var engine_cutoff: bool = false
# PASS36 — Flight Phase 3: power allocation and tactical pilot abilities.
var p36_power_engines: int = 2
var p36_power_weapons: int = 2
var p36_power_shields: int = 2
var p36_ability_cooldown: float = 0.0
var p36_shield_boost_timer: float = 0.0
var p36_jammer_timer: float = 0.0
var p36_overdrive_timer: float = 0.0
# PASS37: tactical flight computer. 0 manual, 1 pursue, 2 hold combat range.
var p37_flight_mode: int = 0
var p37_combat_range: float = 650.0
var p37_status: String = "MANUAL"
# PASS38: local-space travel pilot; 0 off, 1 active waypoint, 2 station approach.
var p38_nav_mode: int = 0
var p38_arrival_radius: float = 260.0
var p38_nav_status: String = "STANDBY"
# PASS41: predictive obstacle scan and emergency flight protection.
var p41_hazard_status: String = "CLEAR"
var p41_emergency_hold: bool = false
var p41_scan_timer: float = 0.0
var p41_hazard_point: Vector3 = Vector3.ZERO
var p41_hazard_distance: float = 999999.0
var p41_hazard_kind: String = ""
# PASS42 — tactical threat escape and persistent obstacle detours.
var p42_evasion_active: bool = false
var p42_evasion_time: float = 0.0
var p42_saved_nav_mode: int = 0
var p42_detour_side: float = 0.0
var p42_detour_timer: float = 0.0
var p42_detour_point: Vector3 = Vector3.ZERO
var p42_status: String = "STANDBY"
# PASS43: opt-in defensive escort for navigation; never fires weapons.
var p43_guardian_enabled: bool = false
var p43_scan_cooldown: float = 0.0
var p43_recovery_cooldown: float = 0.0
var p43_auto_evading: bool = false
var p43_status: String = "OFF"
# PASS44: configurable defensive doctrine and a short flight-computer incident record.
var p44_profile: int = 1 # 0 cautious, 1 balanced, 2 daring
var p44_fuel_reserve: float = 12.0
var p44_fuel_hold: bool = false
var p44_incidents: Array[String] = []
var p44_last_guardian_state: String = ""





var yaw = 0.0
var pitch = 0.0
var roll = 0.0
var cruise = false
var chase = true
var docked = false
var hull_hp = 100.0
var shield_hp = 100.0
var energy = 100.0
var credits = 5000
var upgrades = {"engine":1,"shield":1,"weapon":1,"scanner":1,"armor":1}
var enemies: Array[Node3D] = []
var bullets: Array[Dictionary] = []
var effects: Array[Dictionary] = []
var contacts: Array[Dictionary] = []
var codex: Array[String] = []
var active_mission = 0
var mission_stage = 6 # 6 = no active operation / completed
var mission_kills = 0
# PASS 15 — mission director with two objective locations and distinct stage interactions.
var mission_elapsed = 0.0
var mission_phase_kills = 0
var mission_action_ready = false
var mission_completed: Array[int] = []
var mission_successes = 0
var mission_beacons: Array[Node3D] = []
var mission_event_spawned = false
var mission_reward_bonus = 0
var mission_chain_count = 0
var mission_last_notice = -1
var mission_ui_sector = 0
# PASS 15B: mission-specific physical props, escort gameplay, bonus sites, log and records.
var mission_props: Array[Node3D] = []
var mission_escort: Node3D
var escort_progress = 0.0
var escort_integrity = 100.0
var escort_damage_clock = 0.0
var mission_bonus_done: Array[String] = []
var mission_bonus_value = 0
var mission_journal: Array[String] = []
var mission_fails = 0
var mission_retries = 0
var mission_last_result = "NO COMPLETED OPERATION"
var mission_scan_charge = 0.0
# PASS 15C: deliberate scanner actions, reliable convoy failure, graded records.
var mission_scan_active = false
var mission_escort_failed = false
var mission_best_grades: Dictionary = {}
var mission_current_damage = 0.0
var mission_current_start_hull = 100.0
var mission_current_retries = 0
var mission_last_grade = "UNRATED"
var mission_bonus_beacon: Node3D
# PASS 25: additional long-form operation legs, saved independently of old stages.
var mission_extra_active = false
var mission_extra_done = false
var mission_extra_total = 0
# PASS 26: optional location-specific encounters; independent from main objectives.
var encounter_done: Array[String] = []
var encounter_node: Node3D
var encounter_scan_active = false
var encounter_scan_progress = 0.0
var encounter_time = 0.0
var current_system = 0
var jump_target = 1
var jump_timer = 0.0
var shot_cooldown = 0.0
var world_time = 0.0
var enemy_attack_timer = 0.0
var autosave_timer = 0.0
var alert_timer = 0.0
var event_timer = 0.0
var camera_shake = 0.0
var menu_open = false
var mouse_delta = Vector2.ZERO
# PASS 11: real flight vector, damped attitude control and distinct travel modes.
var roll_delta = 0.0
var linear_velocity = Vector3.ZERO
var angular_velocity = Vector3.ZERO
var flight_assist = true
var boost_active = false
var boost_reserve = 100.0
var cruise_spool = 0.0
var nav_assist = false
var camera_distance = 65.0
var camera_fov = 76.0
var cockpit_pitch = 0.0
var target_heading = 0.0
var target_pitch = 0.0
var ship_response = 1.0
var flight_diagnostics: Label
var flight_mode_label: Label
var chase_distance_target = 65.0
var rng = RandomNumberGenerator.new()
var gate: Node3D
var gate_active = false
var engine_glows: Array[MeshInstance3D] = []
var target_index = 0
var status_message = "GODS COMMAND CENTER ONLINE"
# PASS 12: landing control, station services, real hangar and light station traffic.
var clearance_granted = false
var landing_timer = 0.0
var launch_timer = 0.0
var landing_start = Vector3.ZERO
var station_pad = Vector3.ZERO
var station_job: Dictionary = {}
var cargo_units = 0
var fuel = 100.0
var dock_count = 0
var station_radio_timer = 0.0
var station_traffic: Array[Node3D] = []
var traffic_phase: Array[float] = []
var hangar_view: Node3D
var docking_label: Label
var radio_log: Array[String] = []
var ship_service_count = 0
var docking_beacons: Array[MeshInstance3D] = []
var clearance_timer = 0.0
var last_menu = "station"
var active_station_view = false

# PASS 1 - Reliable startup, procedural scene helpers, material cache.
# PASS 13 tactical state. Old save keys remain compatible.
var missiles: Array[Dictionary] = []
var enemy_shots: Array[Dictionary] = []
var loot_nodes: Array[Node3D] = []
var salvage_inventory: Dictionary = {"alloys":0,"circuits":0,"cores":0}
var target_subsystem = 0
var subsystem_names = ["HULL", "ENGINES", "WEAPONS", "SHIELDS"]
var missile_ammo = 12
var missile_cooldown = 0.0
var countermeasure_cooldown = 0.0
var countermeasure_timer = 0.0
var player_shield_delay = 0.0
var target_readout: Label
# PASS34: SWG-inspired pilot controls and predictive targeting.
var p34_lead_label: Label
var p34_speed_label: Label
var p34_target_last: Dictionary = {}
var p34_target_vel: Dictionary = {}
var p34_optimal_min: float = 0.45
var p34_optimal_max: float = 0.75
var combat_readout: Label
var combat_wave = 0
var restored_enemy_state: Array = []
var combat_music_pulse = 0.0
# PASS 13B: live combat systems, preserved in the Pass 10+ save file.
var weapon_mode = 0
const WEAPON_NAMES = ["PULSE", "RAIL", "FLAK"]
var weapon_heat = 0.0
var weapon_overheat = false
var shield_power = 1
var wingman_active = false
var wingman: Node3D
var wingman_cooldown = 0.0
var wingman_hp = 100.0
var tractor_active = false
var bounty_round = 0
var bounty_active = false
var combat_kills = 0
var combat_damage_dealt = 0.0
var combat_damage_taken = 0.0
var combat_missiles_fired = 0
var combat_bounties_completed = 0
var bounty_timer = 0.0
var tactical_panel: Label
var wingman_beam_timer = 0.0
var materials = {}
# PASS 14 — navigation, multi-hop routes and persistent exploration
var route_destination = -1
var route_legs: Array[int] = []
var visited_sectors: Array[int] = [0]
var charted_sectors: Array[int] = [0]
var jump_from = 0
var jump_to = 0
var jump_charge_total = 4.8
var jump_streaks: Array[Node3D] = []
var sector_scenery: Node3D
var nav_label: Label
var jump_label: Label
var nav_target = 0 # 0: mission objective, 1: local station, 2: jump route
var scan_cooldown = 0.0
var scan_results = "SCANNER STANDBY"
var starfield: MultiMeshInstance3D
var station_home_position = Vector3(-700,80,-1700)
var station_names = ["GODS COMMAND CENTER","MOON BASE OUTPOST","BLACKGLASS FREEPORT","PALE REACH OBSERVATORY","EMBER CROWN REFINERY","GHOST TIDE LISTENING POST","CITADEL VEIL BASTION"]

# PASS 17: seven low-cost procedural worlds and persistent surface expeditions.
const WORLD_NAMES = ["AURORA SHALLOWS", "SILVERFROST BASIN", "OBSIDIAN SPIRES", "LUMEN GARDEN", "CINDERFALL PLAINS", "ECHO CRYSTAL SEA", "VEIL OF TITANS"]
const WORLD_GROUND = [Color(0.12,0.25,0.32),Color(0.46,0.57,0.67),Color(0.18,0.13,0.27),Color(0.12,0.36,0.31),Color(0.42,0.19,0.12),Color(0.12,0.29,0.43),Color(0.27,0.19,0.39)]
const WORLD_ACCENTS = [Color(0.25,0.92,0.88),Color(0.74,0.91,1.0),Color(0.78,0.30,0.95),Color(0.50,1.0,0.48),Color(1.0,0.52,0.16),Color(0.35,0.86,1.0),Color(0.87,0.64,1.0)]
var world_surface: Node3D
var world_planet: MeshInstance3D
var world_orbit_position = Vector3.ZERO
var world_surface_center = Vector3.ZERO
var on_surface = false
var world_transition = 0.0
var world_transition_to_surface = false
var surveyed_worlds: Array[int] = []
var surface_flights = 0
var world_discovery_total = 0
var world_message: Label
var world_env: Environment
# PASS 17B: three meaningful survey sites on every world, saved separately.
const SURVEY_SITE_NAMES = ["LANDING BEACON", "OUTER FORMATION", "ANOMALOUS SOURCE"]
const SURVEY_SITE_OFFSETS = [Vector3(0,0,0),Vector3(690,0,-520),Vector3(-740,0,-680)]
var surface_site_nodes: Array[Node3D] = []
var surface_records: Dictionary = {} # Keys: "sector:site", values: completion true
var selected_surface_site = 0
var surface_scan_time = 0.0
var surface_scan_site = -1
var surface_hazard_time = 0.0
var surface_hazard_alert = 0.0
var surface_samples = 0
var surface_scan_completed = 0

# PASS 16 — owned hulls, modular outfitting and persistent fleet command.
const SHIP_NAMES = ["AEGIS INTERCEPTOR", "NOMAD EXPLORER", "ATLAS HAULER", "WARLANCE GUNSHIP", "GODS DREADNOUGHT"]
const SHIP_PRICES = [0, 12500, 18500, 29000, 68000]
const SHIP_HULLS = [100.0, 125.0, 190.0, 240.0, 420.0]
const SHIP_SHIELDS = [100.0, 135.0, 115.0, 190.0, 300.0]
const SHIP_SPEEDS = [1.16, 1.06, 0.77, 0.94, 0.63]
const SHIP_TURNS = [1.18, 1.08, 0.72, 0.91, 0.57]
const SHIP_CARGO = [12, 20, 55, 25, 90]
const OUTFIT_NAMES = ["REACTOR", "THRUSTERS", "WEAPON RACK", "SHIELD MATRIX", "CARGO RACK", "SENSOR ARRAY"]
const OUTFIT_PRICES = [950, 1150, 1350, 1100, 700, 850]
const FLEET_ORDERS = ["ESCORT", "ATTACK MY TARGET", "DEFEND ME", "HOLD POSITION"]
var ship_class = 0
var owned_ships: Array[int] = [0]
var ship_outfit: Array[int] = [1,1,1,1,1,1]
var ship_custom_colors: Array[int] = [0,0,0,0,0]
var fleet_order = 0
var fleet_drone_owned = false
var fleet_drone_active = false
var fleet_drone_hp = 100.0
var fleet_drone: Node3D
var fleet_drone_cooldown = 0.0
var fleet_anchor = Vector3.ZERO
var fleet_visual: Node3D
var fleet_hardpoints: Node3D
var fleet_model_refresh = true
var fleet_kills = 0
var fleet_service_spent = 0
# PASS 16B — every owned ship has its own modules and service condition.
var hull_module_banks: Dictionary = {}
var hull_conditions: Dictionary = {}
var loadout_presets: Dictionary = {}
var formation_index = 0
var fleet_rules = 0 # 0 weapons free, 1 defensive only, 2 hold fire
var fleet_damage_record = 0.0
var ship_transfers = 0
# PASS 16C — active fleet coordination, stored-hull servicing and readiness.
var fleet_sorties = 0
var fleet_regroups = 0
var fleet_marked_targets = 0
var fleet_repair_spending = 0
var fleet_focus_time = 0.0
var fleet_focus_target: Node3D
var fleet_status_timer = 0.0
const FLEET_FORMATIONS = ["V WING", "LINE ABREAST", "TRAIL", "TIGHT ESCORT"]
const FLEET_RULES = ["WEAPONS FREE", "DEFENSIVE FIRE", "HOLD FIRE"]


# PASS 18 — persistent mystery expeditions, rare encounters and an ancient sanctuary.
const UNKNOWN_NAMES = ["SILENT ARK", "ORPHAN TRANSMITTER", "OBSIDIAN CHOIR", "FRACTURED HALO", "ECHO LEVIATHAN", "THE LAST VAULT", "GLASS SINGULARITY"]
const UNKNOWN_TYPES = ["derelict", "relay", "monolith", "ring", "leviathan", "vault", "rift"]
const UNKNOWN_DESCRIPTIONS = [
 "An immense lost vessel broadcasting a repeating distress sequence.",
 "A relay answering transmissions from an impossible century.",
 "A procession of dark monoliths emitting harmonic pulses.",
 "A broken orbital halo holding a strange energy signature.",
 "A colossal silhouette drifting without visible propulsion.",
 "A sealed archive protected by ancient autonomous machinery.",
 "A lensing fracture bending the light of distant stars."]
var unknown_root: Node3D
var unknown_sites: Array[Dictionary] = []
var unknown_nodes: Array[Node3D] = []
var unknown_records: Dictionary = {}
var unknown_selected = 0
var unknown_scan_progress = 0.0
var unknown_scanning = false
var unknown_discoveries = 0
var unknown_credits = 0
var unknown_messages: Array[String] = []
var unknown_rare_timer = 115.0
var unknown_rare_node: Node3D
var unknown_rare_pos = Vector3.ZERO
var unknown_rare_time = 0.0
var unknown_rare_serial = 0
var unknown_rare_record = ""
var unknown_pocket = false
var unknown_pocket_return = Vector3.ZERO
var unknown_pocket_root: Node3D
var unknown_signal_hud: Label
var unknown_gate_uses = 0
# Pass 18B: lock scans to the exact contact, recover artifacts and solve the sanctuary.
var unknown_scan_key = ""
var unknown_scan_position = Vector3.ZERO
var unknown_artifacts: Dictionary = {}
var unknown_artifact_count = 0
var unknown_sanctuary_keys: Dictionary = {}
var unknown_vaults_opened: Dictionary = {}
var unknown_pylon_nodes: Array[Node3D] = []
var unknown_pylon_index = 0
var unknown_interference = 0.0
var unknown_stability = 100.0

func material(c: Color, luminous: float = 0.0) -> StandardMaterial3D:
 var key = str(c.to_html()) + ":" + str(luminous)
 if materials.has(key): return materials[key]
 var m = StandardMaterial3D.new()
 m.albedo_color = c
 m.metallic = 0.65
 m.roughness = 0.36
 if luminous > 0.0:
  m.emission_enabled = true
  m.emission = c
  m.emission_energy_multiplier = luminous
 materials[key] = m
 return m
func mesh_node(parent: Node3D, shape: Mesh, pos: Vector3, col: Color, luminous: float = 0.0) -> MeshInstance3D:
 var n = MeshInstance3D.new()
 n.mesh = shape
 n.position = pos
 n.material_override = material(col,luminous)
 parent.add_child(n)
 return n
func cube(parent: Node3D, pos: Vector3, size: Vector3, col: Color, luminous: float = 0.0) -> MeshInstance3D:
 var m = BoxMesh.new()
 m.size = size
 return mesh_node(parent,m,pos,col,luminous)
func ball(parent: Node3D, pos: Vector3, radius: float, col: Color, luminous: float = 0.0, segments: int = 12) -> MeshInstance3D:
 var m = SphereMesh.new()
 m.radius = radius
 m.height = radius * 2.0
 m.radial_segments = segments
 m.rings = 6
 return mesh_node(parent,m,pos,col,luminous)
func tube(parent: Node3D, pos: Vector3, radius: float, length: float, col: Color, luminous: float = 0.0) -> MeshInstance3D:
 var m = CylinderMesh.new()
 m.top_radius = radius
 m.bottom_radius = radius
 m.height = length
 m.radial_segments = 12
 return mesh_node(parent,m,pos,col,luminous)
func torus(parent: Node3D, pos: Vector3, inner: float, outer: float, col: Color, luminous: float = 0.0) -> MeshInstance3D:
 var m = TorusMesh.new()
 m.inner_radius = inner
 m.outer_radius = outer
 m.rings = 64
 m.ring_segments = 10
 return mesh_node(parent,m,pos,col,luminous)
func triangle_mesh(parent: Node3D, verts: PackedVector3Array, col: Color) -> MeshInstance3D:
 var m = ArrayMesh.new()
 var a = []
 a.resize(Mesh.ARRAY_MAX)
 a[Mesh.ARRAY_VERTEX] = verts
 var normals = PackedVector3Array()
 for i in range(0,verts.size(),3):
  var nrm = (verts[i+1]-verts[i]).cross(verts[i+2]-verts[i]).normalized()
  normals.append(nrm)
  normals.append(nrm)
  normals.append(nrm)
 a[Mesh.ARRAY_NORMAL] = normals
 m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a)
 var n = mesh_node(parent,m,Vector3.ZERO,col)
 n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 return n
func _ready() -> void:
 var capture = preload("res://scripts/capture_review.gd").new()
 add_child.call_deferred(capture)
 Engine.max_fps=60
 rng.seed = 778812
 create_environment()
 create_player()
 create_station()
 create_station_pass12()
 pass50_starport = preload("res://scripts/pass50_starport.gd").new()
 add_child(pass50_starport)
 pass50_starport.initialize(self)
 create_locations()
 create_asteroids()
 create_gate()
 create_ui()
 install_cockpit_hud()
 living_galaxy = preload("res://scripts/living_galaxy.gd").new()
 add_child(living_galaxy)
 living_galaxy.initialize(self)
 command_nexus = preload("res://scripts/command_nexus.gd").new()
 add_child(command_nexus)
 command_nexus.initialize(self)
 pass45_help = preload("res://scripts/pass45_help.gd").new()
 add_child(pass45_help)
 pass45_help.initialize(self)
 pass46_auto = preload("res://scripts/pass46_auto_missions.gd").new()
 add_child(pass46_auto)
 pass46_auto.initialize(self)
 load_game()
 living_galaxy.import_state(living_saved_state)
 rebuild_ship_model()
 pass21_visuals = preload("res://scripts/pass21_visuals.gd").new()
 add_child(pass21_visuals)
 pass21_visuals.initialize(self)
 pass22_visuals = preload("res://scripts/pass22_visuals.gd").new()
 add_child(pass22_visuals)
 pass22_visuals.initialize(self)
 pass27_dreadnought = preload("res://scripts/pass27_dreadnought.gd").new()
 add_child(pass27_dreadnought)
 pass27_dreadnought.initialize(self)
 setup_sector(current_system)
 apply_pass20_detail()
 pass21_visuals.apply_quality(pass21_quality)
 pass22_visuals.apply_quality(pass21_quality)
 if on_surface: restore_surface_position()
 if docked:
  on_surface=false
  if is_instance_valid(world_surface): world_surface.visible=false
  if is_instance_valid(sector_scenery): sector_scenery.visible=true
 create_mission_beacons()
 create_jump_streaks()
 validate_loaded_state()
 update_hud()
 if route_destination >= 0 and route_destination != current_system:
  if route_legs.is_empty() or not SECTOR_LINKS[current_system].has(route_legs[0]):
   plot_route(route_destination, false)
 spawn_enemies()
 restore_enemy_state()
 Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
 startup_checked = true
 run_pass20_health_check()
 announce("LIVING GALAXY ONLINE / SHIFT+N: DESK / CTRL+F4: FIELD ACTION / F5 SAVE")
 if docked:
  flight_pos = station_pad
  throttle = 0.0
  velocity = 0.0
  linear_velocity = Vector3.ZERO
  if current_system == 0:
   hand_in_mission()
   hand_in_station_job()
  show_menu("station")

func ship_paint() -> Color:
 var choices = [Color(0.17,0.36,0.51), Color(0.44,0.25,0.62), Color(0.64,0.33,0.16), Color(0.16,0.53,0.43), Color(0.55,0.55,0.61)]
 return choices[clampi(ship_custom_colors[ship_class],0,choices.size()-1)]

func rebuild_ship_model() -> void:
 if is_instance_valid(fleet_visual): fleet_visual.queue_free()
 fleet_visual = Node3D.new()
 fleet_visual.name = "Shipworks_Sculpted_Hull"
 player.add_child(fleet_visual)
 for child in ship_visual.get_children(): child.visible = ship_class == 0
 if ship_class == 0:
  # Apply selected paint to the original sculpted hull and its wing panels.
  var starter_color = ship_paint()
  for part in ship_visual.get_children():
   if part is MeshInstance3D and part.mesh is ArrayMesh:
    part.material_override = material(starter_color)
  fleet_visual.visible = true
 else:
  var width = [17.0,22.0,32.0,29.0,48.0][ship_class]
  var length = [29.0,35.0,43.0,38.0,66.0][ship_class]
  var deck = [3.0,4.0,7.0,5.0,12.0][ship_class]
  var tone = ship_paint()
  triangle_mesh(fleet_visual,PackedVector3Array([
   Vector3(0,deck,-length),Vector3(-width,0,4),Vector3(0,deck+3,12),
   Vector3(0,deck,-length),Vector3(0,deck+3,12),Vector3(width,0,4),
   Vector3(0,-deck,-length*.6),Vector3(width,0,4),Vector3(-width,0,4),
   Vector3(-width,0,4),Vector3(width,0,4),Vector3(0,-deck,length*.55)
  ]),tone)
  cube(fleet_visual,Vector3(0,0,5),Vector3(width*.7,deck*1.6,length*.6),tone.darkened(.25))
  ball(fleet_visual,Vector3(0,deck+2,-length*.33),maxf(3.0,deck*.68),Color(.07,.42,.63),.75,16)
  for side in [-1.0,1.0]:
   var wing = cube(fleet_visual,Vector3(side*width*.77,0,7),Vector3(width*.85,2.0,length*.5),tone.lightened(.22))
   wing.rotation.y = side*.19
   var engine = tube(fleet_visual,Vector3(side*width*.5,-1,length*.42),maxf(2.0,deck*.35),length*.42,Color(.12,.17,.22))
   engine.rotation.x = PI/2.0
   ball(fleet_visual,Vector3(side*width*.5,-1,length*.64),maxf(1.7,deck*.32),Color(.12,.82,1.0),2.8,12)
   var fin = cube(fleet_visual,Vector3(side*width*.55,deck*.8,length*.30),Vector3(1.5,deck*2.3,length*.26),tone.lightened(.32))
   fin.rotation.z = side*-.23
  if ship_class >= 3:
   cube(fleet_visual,Vector3(0,deck*1.4,12),Vector3(width*.38,deck,length*.36),tone.darkened(.33))
   for side in [-1.0,1.0]:
    tube(fleet_visual,Vector3(side*width*.25,deck*1.9,-length*.20),1.6,length*.30,Color(.20,.27,.31))
  if ship_class == 4:
   for side in [-1.0,1.0]:
    for j in range(3):
     cube(fleet_visual,Vector3(side*(width*.55+j*4),deck*.25,length*.15+j*9),Vector3(3,3,6),tone.lightened(.1))
 if is_instance_valid(fleet_hardpoints): fleet_hardpoints.queue_free()
 fleet_hardpoints=Node3D.new()
 fleet_hardpoints.name="Equipped_Visible_Hardpoints"
 fleet_visual.add_child(fleet_hardpoints)
 var mounts=2+int(ship_outfit[2]/2)+(2 if ship_class>=3 else 0)
 for i in range(mounts):
  var side=-1.0 if i%2==0 else 1.0
  var depth=-15.0+float(i/2)*8.0
  cube(fleet_hardpoints,Vector3(side*(7.0+float(i/2)*4.0),1.0,depth),Vector3(2.2,1.7,9),Color(.20,.28,.35))
  ball(fleet_hardpoints,Vector3(side*(7.0+float(i/2)*4.0),1.0,depth-5),.8,Color(.17,.90,1.0),1.6,8)
 fleet_model_refresh=false
 if is_instance_valid(pass21_visuals): pass21_visuals.refresh_ship()
 if is_instance_valid(pass22_visuals): pass22_visuals.refresh_ship()
 if is_instance_valid(pass27_dreadnought): pass27_dreadnought.refresh_ship()

func store_current_hull() -> void:
 hull_module_banks[str(ship_class)] = ship_outfit.duplicate()
 hull_conditions[str(ship_class)] = [hull_hp, shield_hp]

func ship_module_bank(index: int) -> Array[int]:
 var result: Array[int] = [1,1,1,1,1,1]
 var raw = hull_module_banks.get(str(index), [])
 if raw is Array and raw.size() == OUTFIT_NAMES.size():
  for i in range(OUTFIT_NAMES.size()): result[i] = clampi(int(raw[i]),1,5)
 return result

func ship_inspection(index: int) -> void:
 var modules = ship_module_bank(index) if index != ship_class else ship_outfit
 var details = "[b]%s[/b]\nStatus: %s\nPrice: %d CR\nBase hull: %d  /  Shield: %d\nSpeed: %d%%  /  Turn: %d%%\nCargo: %d\n\nINSTALLED MODULES\n" % [SHIP_NAMES[index],"OWNED" if owned_ships.has(index) else "AVAILABLE",SHIP_PRICES[index],int(SHIP_HULLS[index]),int(SHIP_SHIELDS[index]),int(SHIP_SPEEDS[index]*100.0),int(SHIP_TURNS[index]*100.0),SHIP_CARGO[index]+(modules[4]-1)*12]
 for i in range(OUTFIT_NAMES.size()): details += "%s: MK %d\n" % [OUTFIT_NAMES[i],modules[i]]
 menu_open = true
 menu.visible = true
 for child in menu_actions.get_children(): child.queue_free()
 menu_title.text = "SHIP INSPECTION"
 menu_text.text = details
 if docked: add_action("PURCHASE / TRANSFER TO THIS HULL",buy_ship.bind(index))
 add_action("BACK TO SHIPWORKS",show_menu.bind("shipyard"))

func save_power_preset() -> void:
 if not docked: announce("SAVE PRESETS WHILE DOCKED");return
 loadout_presets[str(ship_class)] = [weapon_mode, shield_power, fleet_order, formation_index, fleet_rules]
 announce("TACTICAL PRESET STORED FOR " + SHIP_NAMES[ship_class])
 save_game()
 show_menu("outfitting")

func recall_power_preset() -> void:
 var profile = loadout_presets.get(str(ship_class),[])
 if not (profile is Array) or profile.size() != 5:
  announce("NO SAVED TACTICAL PRESET FOR THIS HULL");return
 weapon_mode=clampi(int(profile[0]),0,WEAPON_NAMES.size()-1)
 shield_power=clampi(int(profile[1]),0,2)
 fleet_order=clampi(int(profile[2]),0,FLEET_ORDERS.size()-1)
 formation_index=clampi(int(profile[3]),0,FLEET_FORMATIONS.size()-1)
 fleet_rules=clampi(int(profile[4]),0,FLEET_RULES.size()-1)
 announce("TACTICAL PRESET RECALLED: " + SHIP_NAMES[ship_class])
 save_game()

func cycle_formation() -> void:
 formation_index=(formation_index+1)%FLEET_FORMATIONS.size()
 announce("FLEET FORMATION: "+FLEET_FORMATIONS[formation_index])
 save_game()
 if menu_open: show_menu("fleet")

func cycle_fleet_rules() -> void:
 fleet_rules=(fleet_rules+1)%FLEET_RULES.size()
 announce("FLEET ENGAGEMENT: "+FLEET_RULES[fleet_rules])
 save_game()
 if menu_open: show_menu("fleet")

func formation_anchor(side: float) -> Vector3:
 var local = Vector3(side*65.0,17.0,48.0)
 match formation_index:
  1: local=Vector3(side*105.0,8.0,10.0)
  2: local=Vector3(side*18.0,12.0,105.0 if side>0.0 else 170.0)
  3: local=Vector3(side*32.0,12.0,28.0)
 return player.to_global(local)

func fleet_can_fire(target: Node3D) -> bool:
 if fleet_rules==2: return false
 if fleet_rules==1 and target.position.distance_to(flight_pos)>950.0: return false
 return true

func fleet_readiness() -> String:
 var ready = 0
 var damaged = 0
 for hull in owned_ships:
  var levels = ship_module_bank(hull)
  var maximum = SHIP_HULLS[hull]+float(upgrades["armor"]-1)*25.0
  var shield_maximum = SHIP_SHIELDS[hull]+float(upgrades["shield"]-1)*25.0+float(levels[3]-1)*18.0
  var condition = hull_conditions.get(str(hull),[maximum,shield_maximum])
  if hull == ship_class: condition = [hull_hp,shield_hp]
  if float(condition[0]) >= maximum*.75 and float(condition[1]) >= shield_maximum*.50: ready+=1
  else: damaged+=1
 return "READY %d / DAMAGED %d / OWNED %d" % [ready,damaged,owned_ships.size()]

func ship_compare(index: int) -> void:
 var a = ship_class
 var current_modules = ship_outfit
 var other_modules = ship_module_bank(index)
 menu_open=true
 menu.visible=true
 for child in menu_actions.get_children(): child.queue_free()
 menu_title.text="SHIP COMPARISON"
 menu_text.text="[b]%s  vs  %s[/b]\nHull: %d / %d\nShields: %d / %d\nSpeed: %d%% / %d%%\nTurning: %d%% / %d%%\nCargo: %d / %d\nWeapon rack: MK %d / MK %d\nThrusters: MK %d / MK %d\n\nLeft: active ship. Right: comparison ship." % [SHIP_NAMES[a],SHIP_NAMES[index],int(SHIP_HULLS[a]),int(SHIP_HULLS[index]),int(SHIP_SHIELDS[a]),int(SHIP_SHIELDS[index]),int(SHIP_SPEEDS[a]*100),int(SHIP_SPEEDS[index]*100),int(SHIP_TURNS[a]*100),int(SHIP_TURNS[index]*100),SHIP_CARGO[a]+(current_modules[4]-1)*12,SHIP_CARGO[index]+(other_modules[4]-1)*12,current_modules[2],other_modules[2],current_modules[1],other_modules[1]]
 if docked and index != ship_class: add_action("BUY OR TRANSFER TO COMPARED SHIP",buy_ship.bind(index))
 add_action("BACK TO SHIP CATALOG",show_menu.bind("ship_catalog"))

func repair_stored_hull(index: int) -> void:
 if not docked: announce("DOCK TO SERVICE STORED SHIPS");return
 if not owned_ships.has(index): announce("HULL NOT OWNED");return
 var levels=ship_module_bank(index)
 var maximum=SHIP_HULLS[index]+float(upgrades["armor"]-1)*25.0
 var shield_maximum=SHIP_SHIELDS[index]+float(upgrades["shield"]-1)*25.0+float(levels[3]-1)*18.0
 var condition=hull_conditions.get(str(index),[maximum,shield_maximum])
 if index==ship_class: condition=[hull_hp,shield_hp]
 var price=int(ceilf(maxf(0.0,maximum-float(condition[0])))*9.0+ceilf(maxf(0.0,shield_maximum-float(condition[1])))*3.0)
 if price==0: announce("HULL ALREADY AT FULL CONDITION");return
 if credits<price: announce("SERVICE REQUIRES %d CR"%price);return
 credits-=price
 fleet_repair_spending+=price
 hull_conditions[str(index)]=[maximum,shield_maximum]
 if index==ship_class:
  hull_hp=maximum
  shield_hp=shield_maximum
 announce("SERVICE COMPLETE: "+SHIP_NAMES[index]+" / "+str(price)+" CR")
 save_game()
 show_menu("ship_service")

func repair_all_owned_hulls() -> void:
 if not docked: announce("FLEET SERVICE REQUIRES DOCKING");return
 store_current_hull()
 var cost=0
 for index in owned_ships:
  var levels=ship_module_bank(index)
  var maximum=SHIP_HULLS[index]+float(upgrades["armor"]-1)*25.0
  var shield_maximum=SHIP_SHIELDS[index]+float(upgrades["shield"]-1)*25.0+float(levels[3]-1)*18.0
  var condition=hull_conditions.get(str(index),[maximum,shield_maximum])
  cost+=int(ceilf(maxf(0.0,maximum-float(condition[0])))*9.0+ceilf(maxf(0.0,shield_maximum-float(condition[1])))*3.0)
 if cost==0: announce("FLEET ALREADY FULLY SERVICED");return
 if credits<cost: announce("FLEET REPAIR REQUIRES %d CR"%cost);return
 credits-=cost
 fleet_repair_spending+=cost
 for index in owned_ships:
  var levels=ship_module_bank(index)
  var maximum=SHIP_HULLS[index]+float(upgrades["armor"]-1)*25.0
  var shield_maximum=SHIP_SHIELDS[index]+float(upgrades["shield"]-1)*25.0+float(levels[3]-1)*18.0
  hull_conditions[str(index)]=[maximum,shield_maximum]
 hull_hp=max_hull()
 shield_hp=max_shield()
 announce("ALL OWNED HULLS SERVICED / %d CR"%cost)
 save_game()
 show_menu("ship_service")

func mark_fleet_target() -> void:
 if docked: announce("LAUNCH TO DESIGNATE A TARGET");return
 if target_index<0 or target_index>=enemies.size(): announce("SELECT HOSTILE WITH TAB FIRST");return
 var candidate=enemies[target_index]
 if not is_instance_valid(candidate): announce("NO VALID HOSTILE");return
 fleet_focus_target=candidate
 fleet_focus_time=18.0
 fleet_order=1
 fleet_marked_targets+=1
 announce("FLEET FOCUS: "+candidate.name+" / 18 SEC")

func emergency_fleet_regroup() -> void:
 if docked: announce("FLEET ALREADY IN HANGAR");return
 fleet_order=0
 fleet_focus_time=0.0
 fleet_focus_target=null
 fleet_regroups+=1
 if fleet_drone_active and is_instance_valid(fleet_drone): fleet_drone.position=formation_anchor(-1.0)
 if wingman_active and is_instance_valid(wingman): wingman.position=formation_anchor(1.0)
 announce("FLEET REGROUPED ON COMMAND SHIP")

func select_ship(index: int) -> void:
 if is_instance_valid(living_galaxy) and index>=0 and index<SHIP_NAMES.size():
  var modules=ship_module_bank(index)
  var hold=SHIP_CARGO[index]+(modules[4]-1)*12+int(living_galaxy.state.installed.get("cargo_pod",0))*8
  if living_galaxy.cargo_used()>hold:
   announce("Unload cargo or finish sealed freight before transferring to this smaller hold.")
   return
 if not docked: announce("SHIP EXCHANGE REQUIRES DOCKING");return
 if not owned_ships.has(index): announce("HULL NOT OWNED");return
 if index==ship_class: announce("ALREADY FLYING THIS HULL");return
 store_current_hull()
 ship_class=index
 ship_outfit=ship_module_bank(index)
 var condition = hull_conditions.get(str(index),[])
 if condition is Array and condition.size()==2:
  hull_hp=clampf(float(condition[0]),0.0,max_hull())
  shield_hp=clampf(float(condition[1]),0.0,max_shield())
 else:
  hull_hp=max_hull()
  shield_hp=max_shield()
 ship_transfers+=1
 throttle=0.0
 linear_velocity=Vector3.ZERO
 rebuild_ship_model()
 announce("SHIP TRANSFER COMPLETE: "+SHIP_NAMES[ship_class])
 save_game()
 show_menu("shipyard")

func buy_ship(index: int) -> void:
 if not docked: announce("PURCHASE REQUIRES STATION BERTH");return
 if owned_ships.has(index): select_ship(index);return
 var cost=int(SHIP_PRICES[index])
 if credits<cost: announce("SHIP PURCHASE NEEDS %d CR"%cost);return
 credits-=cost
 owned_ships.append(index)
 select_ship(index)

func upgrade_outfit(slot: int) -> void:
 if not docked: announce("OUTFITTING REQUIRES DOCKING");return
 var level=ship_outfit[slot]
 if level>=5: announce("OUTFIT AT MK V");return
 var cost=int(OUTFIT_PRICES[slot])*level*level
 if credits<cost: announce("NEED %d CR"%cost);return
 credits-=cost
 ship_outfit[slot]=level+1
 hull_module_banks[str(ship_class)]=ship_outfit.duplicate()
 hull_hp=minf(hull_hp,max_hull())
 shield_hp=minf(shield_hp,max_shield())
 rebuild_ship_model()
 announce(OUTFIT_NAMES[slot]+" FITTED MK "+str(level+1))
 save_game()
 show_menu("outfitting")

func repaint_ship() -> void:
 if not docked: announce("PAINT SHOP REQUIRES DOCKING");return
 if credits<180: announce("PAINT COSTS 180 CR");return
 credits-=180
 ship_custom_colors[ship_class]=(ship_custom_colors[ship_class]+1)%5
 rebuild_ship_model()
 save_game()
 show_menu("shipyard")

func buy_fleet_drone() -> void:
 if not docked: announce("FLEET PURCHASE REQUIRES DOCKING");return
 if fleet_drone_owned: announce("SENTINEL ALREADY OWNED");return
 if credits<8800: announce("SENTINEL REQUIRES 8800 CR");return
 credits-=8800
 fleet_drone_owned=true
 announce("SENTINEL ESCORT ACQUIRED")
 save_game()
 show_menu("fleet")

func fleet_order_next() -> void:
 fleet_order=(fleet_order+1)%FLEET_ORDERS.size()
 fleet_anchor=flight_pos
 announce("FLEET ORDER: "+FLEET_ORDERS[fleet_order])
 save_game()

func toggle_fleet_drone() -> void:
 if docked: announce("LAUNCH BEFORE DEPLOYING SENTINEL");return
 if not fleet_drone_owned: announce("BUY SENTINEL AT SHIPWORKS");return
 if fleet_drone_hp<=0.0: announce("SENTINEL NEEDS REPAIRS");return
 fleet_drone_active=not fleet_drone_active
 if fleet_drone_active: fleet_sorties+=1
 if fleet_drone_active and is_instance_valid(fleet_drone): fleet_drone.position=flight_pos+Vector3(-70,15,50)
 if fleet_drone_active and not is_instance_valid(fleet_drone):
  fleet_drone=Node3D.new()
  fleet_drone.name="Sentinel_Escort"
  add_child(fleet_drone)
  triangle_mesh(fleet_drone,PackedVector3Array([
   Vector3(0,0,-13),Vector3(-13,0,8),Vector3(0,3,6),
   Vector3(0,0,-13),Vector3(0,3,6),Vector3(13,0,8),
   Vector3(-13,0,8),Vector3(13,0,8),Vector3(0,-2,7)
  ]),Color(.63,.48,.18))
  ball(fleet_drone,Vector3(0,0,7),2.5,Color(.9,.7,.14),2.0,10)
  fleet_drone.position=flight_pos+Vector3(-70,15,50)
 if is_instance_valid(fleet_drone): fleet_drone.visible=fleet_drone_active
 announce("SENTINEL "+("DEPLOYED" if fleet_drone_active else "RECALLED"))

func repair_fleet_drone() -> void:
 if not docked: announce("FLEET SERVICE REQUIRES DOCKING");return
 var cost=int(ceilf(100.0-fleet_drone_hp))*15
 if credits<cost: announce("INSUFFICIENT CREDITS");return
 credits-=cost
 fleet_service_spent+=cost
 fleet_drone_hp=100.0
 announce("SENTINEL RESTORED")
 save_game()
 show_menu("fleet")

func update_fleet_drone(dt: float) -> void:
 if fleet_drone_active and is_instance_valid(fleet_drone) and fleet_drone.position.distance_to(flight_pos)>3500.0:
  fleet_drone.position=formation_anchor(-1.0)
 fleet_drone_cooldown=maxf(0.0,fleet_drone_cooldown-dt)
 fleet_focus_time=maxf(0.0,fleet_focus_time-dt)
 if fleet_focus_time<=0.0: fleet_focus_target=null
 if docked or jump_timer>0.0 or not fleet_drone_active or not is_instance_valid(fleet_drone):return
 var anchor=formation_anchor(-1.0)
 if fleet_order==3: anchor=fleet_anchor
 fleet_drone.position=fleet_drone.position.lerp(anchor,minf(1.0,dt*1.9))
 fleet_drone.rotation=player.rotation
 if fleet_order==3 or fleet_drone_cooldown>0.0:return
 var target: Node3D=null
 if fleet_focus_time>0.0 and is_instance_valid(fleet_focus_target): target=fleet_focus_target
 if target==null and fleet_order==1 and not enemies.is_empty() and target_index>=0 and target_index<enemies.size(): target=enemies[target_index]
 if target==null:
  var nearest=2300.0 if fleet_order==1 else 1400.0
  for e in enemies:
   if not is_instance_valid(e):continue
   var d=e.position.distance_to(fleet_drone.position)
   if d<nearest: nearest=d;target=e
 if target==null or not is_instance_valid(target) or not fleet_can_fire(target):return
 fleet_drone_cooldown=1.1 if fleet_order==1 else 1.8
 spawn_impact(target.position,Color(.98,.72,.21),8.0)
 var enemy_hp_before=float(target.get_meta("hp"))+float(target.get_meta("shield"))
 var damage=23.0+float(ship_outfit[2])*2.0
 hit_enemy(target,damage,0)
 if enemy_hp_before<=damage: fleet_kills+=1

# PASS 2 - Sculpted spaceship with layered wings, canopy, fins and luminous engines.
func create_player() -> void:
 player = Node3D.new()
 player.name = "GodsShip"
 add_child(player)
 ship_visual = Node3D.new()
 player.add_child(ship_visual)
 var vertices = PackedVector3Array([
  Vector3(0,1,-25),Vector3(-16,-1,8),Vector3(0,5,9),
  Vector3(0,1,-25),Vector3(0,5,9),Vector3(16,-1,8),
  Vector3(0,-4,-15),Vector3(0,1,-25),Vector3(16,-1,8),
  Vector3(0,-4,-15),Vector3(16,-1,8),Vector3(-16,-1,8),
  Vector3(0,-4,-15),Vector3(-16,-1,8),Vector3(0,1,-25)
 ])
 triangle_mesh(ship_visual,vertices,COLORS.hull)
 cube(ship_visual,Vector3(0,2,-2),Vector3(5,2,14),Color(0.04,0.15,0.24))
 ball(ship_visual,Vector3(0,4,-7),3.5,Color(0.08,0.37,0.56),0.35)
 for side in [-1.0,1.0]:
  var wing = cube(ship_visual,Vector3(side*12,-1,4),Vector3(12,1.3,13),COLORS.edge)
  wing.rotation.y = side * 0.20
  var engine = tube(ship_visual,Vector3(side*9,-1,9),2.4,15,Color(0.13,0.17,0.25))
  engine.rotation.x = PI/2.0
  engine_glows.append(ball(ship_visual,Vector3(side*9,-1,17),1.8,COLORS.glow,2.4))
  var fin = cube(ship_visual,Vector3(side*13,3,11),Vector3(1.2,8,7),Color(0.26,0.44,0.55))
  fin.rotation.z = side * -0.24
  cube(ship_visual,Vector3(side*8,0,-5),Vector3(2,1,14),Color(0.28,0.38,0.48))
 for i in range(3):
  cube(ship_visual,Vector3(-2.8+i*2.8,3.3,0),Vector3(0.55,0.3,8),COLORS.glow,0.8)
 camera = Camera3D.new()
 camera.fov = 76
 camera.current = true
 add_child(camera)

# PASS 3 - Orbital station with smooth toroidal rings, hangars, rotating wheel and docking corridor.
func create_station() -> void:
 station = Node3D.new()
 station.name = "GodsCommandCenter"
 station.position = station_position
 add_child(station)
 var wheel = Node3D.new()
 wheel.name = "RotatingHabitat"
 station.add_child(wheel)
 var model = load("res://art/models/gods_command_center.glb") as PackedScene
 if model != null:
  station.add_child(model.instantiate())

# PASS 12: detailed but lightweight hangar, landing corridor, and active traffic.
func create_station_pass12() -> void:
 station_pad = station_position + Vector3(0,-125,145)
 hangar_view = Node3D.new()
 hangar_view.name = "CommandHangar"
 hangar_view.position = Vector3(0,-132,190)
 station.add_child(hangar_view)
 var deck = cube(hangar_view,Vector3(0,-2,0),Vector3(170,6,230),Color(0.105,0.17,0.22))
 deck.material_override = material(Color(0.13,0.20,0.26))
 for side in [-1.0,1.0]:
  cube(hangar_view,Vector3(side*83,20,-12),Vector3(6,42,210),Color(0.18,0.28,0.36))
  cube(hangar_view,Vector3(side*68,47,-5),Vector3(16,6,190),Color(0.27,0.38,0.47))
  for i in range(7):
   cube(hangar_view,Vector3(side*75,6,-93+i*31),Vector3(5,1.5,16),COLORS.glow,0.7)
   cube(hangar_view,Vector3(side*45,-0.2,-92+i*30),Vector3(2,0.5,9),COLORS.gold,0.6)
 for i in range(4):
  cube(hangar_view,Vector3(0,49,-85+i*55),Vector3(168,5,5),Color(0.29,0.37,0.47))
  cube(hangar_view,Vector3(0,45,-85+i*55),Vector3(90,1.2,1.5),COLORS.glow,0.8)
 for i in range(2):
  var gantry = cube(hangar_view,Vector3(-38+i*76,13,48),Vector3(5,29,5),Color(0.35,0.40,0.45))
  gantry.rotation.z = (-0.12 if i==0 else 0.12)
  cube(hangar_view,Vector3(-38+i*76,29,48),Vector3(22,4,8),COLORS.gold)
 var bay_door = torus(station,Vector3(0,-115,297),75,83,Color(0.24,0.39,0.47),0.5)
 bay_door.rotation.x = PI/2.0
 for i in range(9):
  var p = Vector3(-80+i*20,-138,360+i*47)
  ball(station,p,3,COLORS.glow,2.2,8)
  ball(station,p+Vector3(160,0,0),3,COLORS.gold,1.7,8)
 # Clear approach centerline: guides remain visible from outside the hangar.
 for i in range(12):
  var z = 350.0+float(i)*48.0
  var lamp = ball(station,Vector3(0,-124,z),4.5,COLORS.glow,2.2,8)
  docking_beacons.append(lamp)
 # Landing pad markings and a raised docking-control tower.
 for i in range(5):
  cube(hangar_view,Vector3(-48+float(i)*24,-0.5,-22),Vector3(11,0.4,3),COLORS.gold,0.5)
 tube(hangar_view,Vector3(-63,24,-75),8,45,Color(0.23,0.35,0.44))
 ball(hangar_view,Vector3(-63,50,-75),11,Color(0.15,0.60,0.72),0.9)
 # Eight low-poly craft, one node each; animate transforms rather than rebuilding meshes.
 for i in range(8):
  var t = Node3D.new()
  t.name = "Traffic_%02d" % i
  station.add_child(t)
  var verts = PackedVector3Array([
   Vector3(0,0,-11),Vector3(-8,-1,8),Vector3(0,2,6),
   Vector3(0,0,-11),Vector3(0,2,6),Vector3(8,-1,8),
   Vector3(-8,-1,8),Vector3(8,-1,8),Vector3(0,-2,-5)
  ])
  triangle_mesh(t,verts,Color(0.35,0.58,0.65) if i%3 else Color(0.65,0.53,0.32))
  ball(t,Vector3(0,0,8),1.7,COLORS.glow,1.6,8)
  station_traffic.append(t)
  traffic_phase.append(TAU*float(i)/8.0)

func update_station_traffic(dt: float) -> void:
 var station_near = flight_pos.distance_to(station_position)<9000.0
 for i in range(docking_beacons.size()):
  docking_beacons[i].visible = station_near and (clearance_granted or landing_timer>0.0)
  if docking_beacons[i].visible:
   docking_beacons[i].scale = Vector3.ONE*(0.82+0.18*sin(world_time*5.0-float(i)*0.65))
 for t in station_traffic:
  t.visible = station_near
 if not station_near: return
 for i in range(station_traffic.size()):
  var t = station_traffic[i]
  var a = world_time*(0.09+float(i%3)*0.025)+traffic_phase[i]
  var r = 400.0+float(i%3)*105.0
  t.position = Vector3(cos(a)*r,sin(a)*r*0.6+float((i%3)-1)*70.0,130.0+sin(a*0.67+float(i))*105.0)
  t.rotation.y = a+PI*0.5
  t.rotation.z = sin(a)*0.12
 station_radio_timer += dt
 if station_radio_timer>34.0:
  station_radio_timer=0.0
  var reports = ["TRAFFIC CONTROL: inbound shuttle cleared to approach lane 2.","GODS SECURITY: perimeter patrol maintaining formation.","SHIPWORKS: service tug moving to fabrication berth.","DOCK CONTROL: landing pads operational; request clearance before approach.","CARGO CONTROL: outbound freighter departing logistics wing."]
  radio_message(reports[rng.randi_range(0,reports.size()-1)])

func radio_message(s: String) -> void:
 radio_log.push_front(s)
 if radio_log.size()>8: radio_log.pop_back()
 if flight_pos.distance_to(station_position)<2200.0 and not menu_open: announce(s)

func dock_range() -> float:
 return flight_pos.distance_to(station_position)

func begin_landing() -> void:
 if docked or landing_timer>0.0 or launch_timer>0.0: return
 if not clearance_granted: announce("REQUEST DOCKING CLEARANCE FIRST (E)");return
 if dock_range()>900.0: announce("LANDING DENIED — APPROACH WITHIN 900 M");return
 landing_start=flight_pos
 landing_timer=4.2
 cruise=false
 cruise_spool=0.0
 boost_active=false
 throttle=0.0
 velocity=0.0
 linear_velocity=Vector3.ZERO
 close_menu()
 announce("AUTOMATED LANDING — APPROACH VECTOR LOCKED")

func update_docking_sequence(dt: float) -> void:
 if landing_timer>0.0:
  landing_timer=maxf(0.0,landing_timer-dt)
  var progress=1.0-landing_timer/4.2
  var eased=progress*progress*(3.0-2.0*progress)
  flight_pos=landing_start.lerp(station_pad,eased)
  yaw=lerp_angle(yaw,PI,minf(1.0,dt*1.5))
  pitch=lerpf(pitch,0.0,minf(1.0,dt*1.8))
  roll=lerpf(roll,0.0,minf(1.0,dt*1.8))
  if landing_timer<=0.0:
   yaw=PI
   pitch=0.0
   roll=0.0
   docked=true
   clearance_granted=false
   dock_count+=1
   flight_pos=station_pad
   shield_hp=minf(max_shield(),shield_hp+20.0)
   radio_message("DOCK CONTROL: touchdown confirmed, berth assigned.")
   if current_system == 0:
    hand_in_mission()
    hand_in_station_job()
   save_game()
   show_menu("station")
 if launch_timer>0.0:
  launch_timer=maxf(0.0,launch_timer-dt)
  var f=1.0-launch_timer/2.4
  flight_pos=station_pad.lerp(station_position+Vector3(0,-75,630),f*f*(3.0-2.0*f))
  if launch_timer<=0.0:
   cruise=false
   clearance_granted=false
   throttle=0.18
   velocity=0.0
   linear_velocity=Vector3.ZERO
   announce("DOCK CONTROL: launch clearance granted. Safe flight.")
   save_game()

func hand_in_mission() -> void:
 if current_system!=0 or mission_stage!=5: return
 var score=100-mini(45,int(mission_current_damage/5.0))-mission_current_retries*12
 score+=mini(15,int(mission_bonus_value/250))
 var grade="S" if score>=108 else ("A" if score>=88 else ("B" if score>=68 else "C"))
 mission_last_grade=grade
 var mission_key=str(active_mission)
 var ranks={"C":0,"B":1,"A":2,"S":3}
 if not mission_best_grades.has(mission_key) or int(ranks.get(grade,0))>int(ranks.get(str(mission_best_grades[mission_key]),0)):
  mission_best_grades[mission_key]=grade
 mission_stage=6
 mission_extra_active=false
 mission_extra_done=false
 var reward=int(MISSIONS[active_mission]["reward"])+mission_reward_bonus
 credits+=reward
 mission_successes+=1
 mission_chain_count+=1
 cargo_units=0
 if not mission_completed.has(active_mission): mission_completed.append(active_mission)
 clear_mission_beacons()
 clear_mission_props()
 mission_last_result=String(MISSIONS[active_mission]["name"])+" / GRADE "+mission_last_grade+" / +"+str(reward)+" CR"
 mission_log("Operation delivered / +%d credits" % reward)
 announce("OPERATION COMPLETE — GRADE %s / +%d CR / %d OF 40 CLEARED" % [mission_last_grade,reward,mission_completed.size()])
 save_game()

func hand_in_station_job() -> void:
 if current_system!=0:return
 if station_job.is_empty() or not bool(station_job.get("complete",false)):return
 var reward=int(station_job.get("reward",0))
 credits+=reward
 cargo_units=0
 announce("STATION CONTRACT DELIVERED — +%d CR" % reward)
 station_job.clear()

func start_station_job(kind: String) -> void:
 if current_system!=0: announce("STATION CONTRACTS ORIGINATE AT GODS COMMAND");return
 if not docked: announce("ACCEPT STATION CONTRACTS WHILE DOCKED");return
 if not station_job.is_empty(): announce("FINISH THE CURRENT STATION CONTRACT FIRST");return
 var job: Dictionary = {"cargo":{"name":"Emergency Medical Freight","goal":Vector3(1100,110,-3300),"reward":2600},"salvage":{"name":"Relay Recovery","goal":Vector3(-2700,-170,-5800),"reward":3100},"security":{"name":"Outer Perimeter Inspection","goal":Vector3(2100,230,-4400),"reward":2900}}[kind]
 station_job={"name":job["name"],"goal":job["goal"],"reward":job["reward"],"complete":false,"kind":kind}
 cargo_units=3 if kind=="cargo" else 0
 save_game()
 announce("CONTRACT ACCEPTED — "+String(job["name"]))
 show_menu("station")

func update_station_job() -> void:
 if station_job.is_empty() or bool(station_job.get("complete",false)) or docked:return
 if flight_pos.distance_to(station_job["goal"])<250.0:
  station_job["complete"]=true
  announce("STATION CONTRACT OBJECTIVE COMPLETE — RETURN TO DOCK")
  save_game()

func station_service(kind: String) -> void:
 if not docked: announce("STATION SERVICE REQUIRES DOCKING");return
 if kind=="repair":
  var cost=int(ceilf(max_hull()-hull_hp)*9.0+ceilf(max_shield()-shield_hp)*3.0)
  if credits<cost:announce("REPAIR DENIED — %d CR REQUIRED"%cost);return
  credits-=cost;hull_hp=max_hull();shield_hp=max_shield();announce("REPAIR COMPLETE — %d CR"%cost)
 elif kind=="refuel":
  var cost=int(ceilf(100.0-fuel)*6.0)
  if credits<cost:announce("REFUEL DENIED — %d CR REQUIRED"%cost);return
  credits-=cost;fuel=100.0;announce("FUEL RESTORED — %d CR"%cost)
 elif kind=="recharge":
  energy=100.0;shield_hp=max_shield();announce("REACTOR AND SHIELDS RECHARGED")
 elif kind=="rearm":
  var needed=12-missile_ammo
  var cost=needed*140
  if needed<=0: announce("MISSILE RACK ALREADY FULL");return
  if credits<cost: announce("REARM DENIED — %d CR REQUIRED"%cost);return
  credits-=cost;missile_ammo=12;announce("MISSILE RACK REARMED — %d CR"%cost)
 ship_service_count+=1
 save_game()
 show_menu("station")

func sell_salvage() -> void:
 if not docked: announce("SALVAGE TRADING REQUIRES DOCKING");return
 var total=int(salvage_inventory["alloys"])*180+int(salvage_inventory["circuits"])*360+int(salvage_inventory["cores"])*900
 if total<=0: announce("NO SALVAGE IN INVENTORY");return
 credits+=total
 for k in salvage_inventory.keys(): salvage_inventory[k]=0
 announce("SALVAGE SOLD  +"+str(total)+" CR")
 save_game()
 show_menu("armory")

func launch_from_station() -> void:
 # Manual departure always takes precedence over a running mission computer.
 if is_instance_valid(pass46_auto) and pass46_auto.enabled and not pass46_auto.launch_requested_by_auto:
  pass46_auto.stop()
 if not docked:
  if launch_timer>0.0: announce("DEPARTURE ALREADY IN PROGRESS")
  else: announce("SHIP IS ALREADY UNDOCKED")
  return
 if landing_timer>0.0 or launch_timer>0.0:
  announce("WAIT FOR DOCKING SEQUENCE TO FINISH")
  return
 docked=false
 clearance_granted=false
 landing_timer=0.0
 launch_timer=2.4
 cruise=false
 boost_active=false
 throttle=0.0
 velocity=0.0
 linear_velocity=Vector3.ZERO
 p38_nav_mode=0
 close_menu()
 announce("DEPARTURE SEQUENCE — HANGAR DOORS OPEN")

# PASS 4 - Starfield, colorful celestial bodies, nebula, asteroid clusters and ancient gate.
func create_environment() -> void:
 var sun = DirectionalLight3D.new()
 sun.rotation_degrees = Vector3(-30,55,8)
 sun.light_energy = 1.1
 add_child(sun)
 var world = WorldEnvironment.new()
 var env = Environment.new()
 env.background_mode = Environment.BG_COLOR
 env.background_color = Color(0.002,0.004,0.018)
 env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
 env.ambient_light_color = Color(0.13,0.20,0.32)
 env.ambient_light_energy = 0.75
 var reflection_sky = Sky.new()
 var sky_shader = Shader.new()
 sky_shader.code = "shader_type sky; void sky(){ vec3 d=normalize(EYEDIR); vec3 c=vec3(0.055,0.08,0.13); c+=vec3(0.36,0.46,0.58)*pow(max(dot(d,normalize(vec3(-0.4,0.8,0.3))),0.0),5.0); c+=vec3(0.26,0.14,0.06)*pow(max(dot(d,normalize(vec3(0.9,0.2,-0.4))),0.0),12.0); COLOR=c; }"
 var sky_material = ShaderMaterial.new()
 sky_material.shader = sky_shader
 reflection_sky.sky_material = sky_material
 env.sky = reflection_sky
 env.reflected_light_source = 2
 sun.shadow_enabled = true
 env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
 world_env = env
 world.environment = env
 add_child(world)
 var mm = MultiMesh.new()
 mm.transform_format = MultiMesh.TRANSFORM_3D
 var sm = SphereMesh.new()
 sm.radius = 1.0
 sm.height = 2.0
 sm.radial_segments = 4
 sm.rings = 2
 mm.mesh = sm
 mm.instance_count = 1400
 for i in range(mm.instance_count):
  var p = Vector3(rng.randf_range(-16000,16000),rng.randf_range(-10000,10000),rng.randf_range(-17000,12000))
  mm.set_instance_transform(i,Transform3D(Basis.IDENTITY.scaled(Vector3.ONE*rng.randf_range(0.6,3.5)),p))
 var stars = MultiMeshInstance3D.new()
 stars.multimesh = mm
 starfield = stars
 stars.material_override = material(Color(0.65,0.80,1.0),2.0)
 add_child(stars)
 var giant = ball(self,Vector3(6500,-3000,-12000),1650,Color(0.12,0.26,0.55),0.15,48)
 giant.scale = Vector3(1,0.94,1)
 var ring = torus(self,Vector3(6500,-3000,-12000),1900,2300,Color(0.30,0.36,0.50))
 ring.rotation = Vector3(0.7,0.2,0.35)
 ball(self,Vector3(-6500,2000,-13500),520,Color(0.52,0.15,0.34),0.7,24)
func create_locations() -> void:
 var moon = ball(self,Vector3(4800,1300,-6500),630,Color(0.42,0.45,0.50),0.1,24)
 moon.scale = Vector3(1.0,0.94,1.0)
 var relay = Node3D.new()
 relay.position = Vector3(-2700,-170,-5800)
 add_child(relay)
 for i in range(3):
  var arm = cube(relay,Vector3(0,0,0),Vector3(380,7,10),Color(0.24,0.36,0.47))
  arm.rotation.z = float(i)*TAU/3.0
 ball(relay,Vector3.ZERO,36,COLORS.gold,1.2)
func create_asteroids() -> void:
 for i in range(95):
  var p = Vector3(rng.randf_range(-4400,4400),rng.randf_range(-1300,1300),rng.randf_range(-11500,-1900))
  if p.distance_to(station_position)<500: continue
  var rock = ball(self,p,rng.randf_range(12,75),Color(0.22,0.23,0.27),0.0,8)
  rock.scale = Vector3(rng.randf_range(.65,1.6),rng.randf_range(.6,1.2),rng.randf_range(.65,1.5))
  pass20_asteroids.append(rock)
func create_gate() -> void:
 gate = Node3D.new()
 gate.position = Vector3(5200,300,-11700)
 gate.name = "AncientSpaceGodsGate"
 add_child(gate)
 for i in range(3):
  var r = torus(gate,Vector3(0,0,float(i)*10),150+float(i)*12,163+float(i)*12,Color(0.36,0.24,0.62),0.65)
  r.rotation.x = PI/2.0
 for i in range(16):
  var a = TAU*float(i)/16.0
  ball(gate,Vector3(cos(a)*162,sin(a)*162,0),8,Color(0.63,0.43,1),1.7,8)
 gate_active = true

# PASS 5 - Smooth ship flight, camera modes, manual fire and cruise/jump animation.
# PASS 11 - independent left-drag steering, right-drag roll, mouse-wheel chase zoom.
func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventMouseMotion and not menu_open and not docked:
  if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
   mouse_delta += event.relative * 0.0035
  if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
   roll_delta += event.relative.x * 0.006
 if event is InputEventMouseButton and event.pressed and not menu_open:
  if event.button_index == MOUSE_BUTTON_WHEEL_UP:
   chase_distance_target = clampf(chase_distance_target - 7.0, 36.0, 125.0)
  elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
   chase_distance_target = clampf(chase_distance_target + 7.0, 36.0, 125.0)
 if event is InputEventKey and event.pressed and not event.echo:
  # A powered-down ship cannot keep automatic pursuit engaged.
  # PASS32: tilde is a latched engine shutdown, not a throttle preset.
  if event.keycode == KEY_QUOTELEFT or event.keycode == KEY_ASCIITILDE:
   if not docked and not menu_open:
    engine_cutoff = not engine_cutoff
    if engine_cutoff:
     p37_flight_mode = 0
     p38_nav_mode = 0
     p42_evasion_active = false
     p42_detour_timer = 0.0
    throttle = 0.0
    cruise = false
    cruise_spool = 0.0
    boost_active = false
    velocity = 0.0
    linear_velocity = Vector3.ZERO
    announce("ENGINES OFF / ZERO VELOCITY — PRESS ~ TO RESTART" if engine_cutoff else "ENGINES ONLINE / THROTTLE IDLE")
   get_viewport().set_input_as_handled()
   return
  # PASS32: fine detents and 75% blue-zone cruise shortcut.
  if event.keycode in [KEY_MINUS, KEY_EQUAL, KEY_BACKSLASH] and not menu_open and not docked:
   if engine_cutoff:
    announce("ENGINES OFF — PRESS ~ TO RESTART")
   else:
    if event.keycode == KEY_BACKSLASH:
     throttle = 0.75
    else:
     throttle = clampf(snappedf(throttle + (0.05 if event.keycode == KEY_EQUAL else -0.05), 0.05), 0.0, 1.0)
    announce("THROTTLE %d%%" % int(roundf(throttle * 100.0)))
   get_viewport().set_input_as_handled()
   return
  # PASS44: cycle defensive doctrine without touching the throttle presets.
  if event.ctrl_pressed and event.shift_pressed and event.keycode == KEY_4:
   if not menu_open:
    p44_profile = (p44_profile + 1) % 3
    p44_log("DOCTRINE: " + p44_profile_name())
    announce("GUARDIAN PROFILE: " + p44_profile_name())
   get_viewport().set_input_as_handled()
   return
  # PASS44: review recent flight computer interventions in the announcement panel.
  if event.ctrl_pressed and event.shift_pressed and event.keycode == KEY_5:
   if not menu_open:
    announce("FLIGHT LOG: " + (" | ".join(p44_incidents.slice(-3)) if not p44_incidents.is_empty() else "NO INCIDENTS"))
   get_viewport().set_input_as_handled()
   return
  # PASS43: toggle autonomous defensive response; manual controls always win.
  if event.ctrl_pressed and event.shift_pressed and event.keycode == KEY_9:
   if not menu_open:
    p43_guardian_enabled = not p43_guardian_enabled
    p43_status = "ARMED" if p43_guardian_enabled else "OFF"
    p44_log("GUARDIAN " + ("ARMED" if p43_guardian_enabled else "OFF"))
    if not p43_guardian_enabled:
     p43_auto_evading = false
    announce("GUARDIAN PILOT %s" % ("ARMED / NAVIGATION PROTECTION" if p43_guardian_enabled else "DISABLED"))
   get_viewport().set_input_as_handled()
   return
  # PASS42: separate emergency escape and resume controls.
  if event.ctrl_pressed and event.shift_pressed and event.keycode in [KEY_7, KEY_8]:
   if not menu_open and not docked:
    if event.keycode == KEY_7:
     p42_start_evasion()
    else:
     p42_resume_route()
   get_viewport().set_input_as_handled()
   return
  # PASS40: emergency computer disconnect, without shutting down engines.
  # PASS41: clear a critical hold manually. The pilot must explicitly resume.
  if event.ctrl_pressed and event.keycode == KEY_6:
   p41_emergency_hold = false
   p41_hazard_status = "MANUAL OVERRIDE"
  if event.ctrl_pressed and event.keycode in [KEY_4, KEY_5, KEY_7, KEY_8, KEY_9]:
   if p41_emergency_hold:
    announce("EMERGENCY HOLD — CTRL+6 TO ACKNOWLEDGE BEFORE REENGAGING")
    get_viewport().set_input_as_handled()
    return
  if event.ctrl_pressed and event.keycode == KEY_0:
   if is_instance_valid(pass46_auto) and pass46_auto.enabled: pass46_auto.stop()
   p40_abort_autopilot()
   get_viewport().set_input_as_handled()
   return
  # PASS38: local navigation and station approach computer.
  if event.ctrl_pressed and event.keycode in [KEY_7, KEY_8, KEY_9]:
   if not menu_open and not docked:
    p38_set_nav_mode(1 if event.keycode == KEY_7 else (2 if event.keycode == KEY_8 else 3))
   get_viewport().set_input_as_handled()
   return
  # PASS37: tactical pilot assistant (no automatic firing).
  if event.ctrl_pressed and event.keycode in [KEY_4, KEY_5, KEY_6]:
   if not menu_open and not docked:
    p37_set_flight_mode(event.keycode - KEY_4 + 1 if event.keycode != KEY_6 else 0)
   get_viewport().set_input_as_handled()
   return
  # PASS36: Ctrl+1/2/3 allocates a power pip to ENG/WEP/SYS. Six total.
  if event.ctrl_pressed and event.keycode in [KEY_1, KEY_2, KEY_3]:
   if not menu_open:
    p36_move_power(event.keycode - KEY_1)
   get_viewport().set_input_as_handled()
   return
  # PASS36: combat abilities require stored energy and share a cooldown.
  if event.ctrl_pressed and event.keycode in [KEY_Q, KEY_E, KEY_R]:
   if not menu_open and not docked:
    p36_activate_ability(event.keycode)
   get_viewport().set_input_as_handled()
   return
  # PASS31: direct throttle detents. Alt+number preserves exploration shortcuts.
  if event.keycode >= KEY_0 and event.keycode <= KEY_9:
   if event.alt_pressed:
    match event.keycode:
     KEY_1: toggle_planet_approach()
     KEY_2: survey_planet()
     KEY_3: show_menu("worlds")
     KEY_4: cycle_surface_site()
     KEY_5: show_menu("unknown")
     KEY_6: investigate_unknown()
     KEY_7: cycle_unknown_site()
     KEY_8: activate_unknown_gate()
     KEY_9: recover_unknown_artifact()
     KEY_0: cycle_sanctuary_pylon()
   elif not menu_open and not docked and not engine_cutoff:
    var detent: int = 10 if event.keycode == KEY_0 else event.keycode - KEY_0
    throttle = float(detent) / 10.0
    announce("THROTTLE PRESET  %d%%" % [detent * 10])
   if engine_cutoff and not event.alt_pressed:
    announce("ENGINES OFF — PRESS ~ TO RESTART")
   get_viewport().set_input_as_handled()
   return
  if event.keycode == KEY_F8 and event.shift_pressed:
   pass46_auto.toggle()
   get_viewport().set_input_as_handled()
   return
  if event.keycode == KEY_F10:
   if event.shift_pressed:
    command_nexus.show("academy")
   else:
    pass45_help.toggle()
   get_viewport().set_input_as_handled()
   return
  if event.keycode == KEY_F1 and event.shift_pressed:
   show_menu("nexus_home")
   get_viewport().set_input_as_handled()
   return
  if event.keycode == KEY_N and event.shift_pressed:
   living_galaxy.show("hub")
   get_viewport().set_input_as_handled()
   return
  if event.keycode == KEY_F4 and event.ctrl_pressed:
   living_galaxy.action()
   get_viewport().set_input_as_handled()
   return
  if event.keycode == KEY_F12 and event.ctrl_pressed:
   return
  if event.keycode == KEY_F4 and event.shift_pressed:
   show_menu("flight_support")
   get_viewport().set_input_as_handled()
   return
  # PASS53: direct departure works from every docked terminal, even when a menu is open.
  if docked and event.keycode == KEY_E and not event.ctrl_pressed and not event.alt_pressed:
   launch_from_station()
   get_viewport().set_input_as_handled()
   return
  if docked and event.keycode == KEY_L and event.shift_pressed:
   launch_from_station()
   get_viewport().set_input_as_handled()
   return
  if menu_open and event.keycode == KEY_ESCAPE:
   if docked:
    # ESC should exit the terminal, not endlessly reopen it.
    close_menu()
   else: close_menu()
   get_viewport().set_input_as_handled()
   return
  if menu_open and event.keycode not in [KEY_F1, KEY_F2, KEY_F3, KEY_F5, KEY_M, KEY_B, KEY_G, KEY_I, KEY_U, KEY_ESCAPE, KEY_F7, KEY_3, KEY_5]:
   return
  match event.keycode:
   KEY_V: chase = not chase; announce("CHASE CAMERA" if chase else "COCKPIT CAMERA")
   KEY_C:
    if engine_cutoff:
     announce("ENGINES OFF — PRESS ~ TO RESTART")
     return
    cruise = not cruise
    cruise_spool = 0.0
    announce("FRAME CRUISE SPOOLING" if cruise else "SUPERCRUISE DISENGAGED")
   KEY_J: begin_jump()
   KEY_E: attempt_dock()
   KEY_M: show_menu("missions")
   KEY_B:
    if event.shift_pressed: p35_board_target()
    else: show_menu("shipyard")
   KEY_G: show_menu("galaxy")
   KEY_F2:
    if event.shift_pressed: toggle_hud_compact()
    else:
     nav_target=(nav_target+1)%4
     announce("NAV TARGET: "+nav_target_name())
   KEY_F3:
    if event.shift_pressed: toggle_performance_mode()
    else: scan_sector()
   KEY_F4: interact_mission()
   KEY_F6:
    if event.shift_pressed: investigate_encounter()
    else: collect_mission_bonus()
   KEY_U: show_menu("codex")
   KEY_F1:
    if event.shift_pressed: toggle_diagnostics()
    else: show_menu("help")
   KEY_F13: toggle_diagnostics()
   KEY_F14: toggle_hud_compact()
   KEY_F15: toggle_performance_mode()
   KEY_TAB:
    if event.shift_pressed: p34_target_nearest()
    else: cycle_target()
   KEY_T: cycle_subsystem()
   KEY_K: launch_missile()
   KEY_L: deploy_countermeasures()
   KEY_Z: cycle_weapon()
   KEY_P: cycle_power()
   KEY_Y: toggle_wingman()
   KEY_O: tractor_active = not tractor_active; announce("TRACTOR BEAM " + ("ONLINE" if tractor_active else "OFFLINE"))
   KEY_I: show_menu("tactics")
   KEY_F7: show_menu("fleet")
   KEY_F8: fleet_order_next()
   KEY_F9: toggle_fleet_drone()
   KEY_F10: cycle_formation()
   KEY_F11: cycle_fleet_rules()
   KEY_F12: mark_fleet_target()
   KEY_BACKSPACE: emergency_fleet_regroup()
   KEY_H: flight_assist = not flight_assist; announce("FLIGHT ASSIST ON" if flight_assist else "FLIGHT ASSIST OFF")
   KEY_N: nav_assist = not nav_assist; announce("NAV BRAKING ON" if nav_assist else "NAV BRAKING OFF")
   KEY_X:
    throttle = 0.0
    cruise = false
    velocity = 0.0
    linear_velocity = Vector3.ZERO
    announce("ALL STOP / FLIGHT VELOCITY ZERO")
   KEY_F5: save_game(); announce("GAME SAVED" if last_save_ok else "SAVE FAILED — CHECK STORAGE")
   KEY_ESCAPE:
    close_menu()

func _process(dt: float) -> void:
 dt = minf(dt, 0.06)
 frame_count += 1
 frame_seconds += dt
 if frame_seconds >= 1.0:
  measured_fps = float(frame_count) / frame_seconds
  frame_count = 0
  frame_seconds = 0.0
 if is_instance_valid(pass45_help): pass45_help.update_tip(dt)
 if is_instance_valid(pass46_auto): pass46_auto.tick(dt)
 if menu_open: return
 world_time += dt
 p36_ability_cooldown = maxf(0.0, p36_ability_cooldown-dt)
 p36_shield_boost_timer = maxf(0.0, p36_shield_boost_timer-dt)
 p36_jammer_timer = maxf(0.0, p36_jammer_timer-dt)
 p36_overdrive_timer = maxf(0.0, p36_overdrive_timer-dt)
 energy = minf(100.0, energy+dt*(1.5+float(p36_power_weapons)*0.9))
 shot_cooldown = maxf(0.0, shot_cooldown - dt)
 missile_cooldown = maxf(0.0, missile_cooldown - dt)
 countermeasure_cooldown = maxf(0.0, countermeasure_cooldown - dt)
 countermeasure_timer = maxf(0.0, countermeasure_timer - dt)
 player_shield_delay = maxf(0.0, player_shield_delay - dt)
 weapon_heat = maxf(0.0,weapon_heat-dt*(21.0 if shield_power==0 else 15.0)*(1.0+float(ship_outfit[0]-1)*.11))
 if weapon_overheat and weapon_heat<34.0: weapon_overheat=false;announce("WEAPON COOLANT RESTORED")
 wingman_cooldown=maxf(0.0,wingman_cooldown-dt)
 bounty_timer=maxf(0.0,bounty_timer-dt)
 if player_shield_delay <= 0.0 and not docked:
  shield_hp = minf(max_shield(), shield_hp + dt * (3.2 + float(upgrades["shield"])) * (0.6+float(p36_power_shields)*0.2) * (2.2 if p36_shield_boost_timer>0.0 else 1.0) * (1.75 if shield_power==2 else (0.65 if shield_power==0 else 1.0)))
 camera_shake = maxf(0.0, camera_shake - dt * 2.0)
 if alert_timer > 0.0: alert_timer -= dt
 elif alert_label != null: alert_label.text = ""
 if world_transition>0.0:
  world_transition=maxf(0.0,world_transition-dt)
  if world_transition<=0.0: complete_world_transition()
 if jump_timer > 0.0:
  jump_timer -= dt
  if jump_timer <= 0.0: complete_jump()
 elif not docked and not menu_open and landing_timer<=0.0 and launch_timer<=0.0 and world_transition<=0.0:
  update_flight(dt)
  if on_surface: constrain_surface_flight()
 else:
  mouse_delta = Vector2.ZERO
  roll_delta = 0.0
 update_docking_sequence(dt)
 if on_surface: update_surface_expedition(dt)
 if on_surface and world_env!=null:
  world_env.background_color=world_ground_sky()
 elif world_env!=null:
  world_env.background_color=Color(0.002,0.004,0.018)
 player.position = flight_pos
 player.rotation = Vector3(pitch, yaw, roll)
 update_flight_camera(dt)
 if is_instance_valid(pass21_visuals): pass21_visuals.animate(dt)
 if is_instance_valid(pass22_visuals): pass22_visuals.animate(dt)
 if is_instance_valid(pass27_dreadnought): pass27_dreadnought.animate(dt)
 if world_transition>0.0: camera.fov=lerpf(camera.fov,105.0,minf(1.0,dt*4.0))
 if jump_timer>0.0:
  camera.fov=lerpf(camera.fov,110.0,minf(1.0,dt*3.0))
 update_jump_streaks(dt)
 if starfield!=null:
  starfield.global_position=flight_pos
 ship_visual.visible = false # Legacy starter mesh hidden: Shipworks renders the active hull
 if is_instance_valid(fleet_visual): fleet_visual.visible=chase or docked
 for engine in engine_glows:
  engine.scale = Vector3.ONE * (1.0 + throttle * .32 + (0.25 if boost_active else 0.0) + sin(world_time * 23.0) * .07)
 var wheel: Node3D = station.get_node_or_null("RotatingHabitat") as Node3D
 if wheel != null: wheel.rotation.z += dt * .018
 update_bullets(dt)
 update_missiles(dt)
 update_enemy_shots(dt)
 update_loot(dt)
 update_enemies(dt)
 p34_track_targets(dt)
 p34_update_aim()
 update_wingman(dt)
 update_fleet_drone(dt)
 update_bounty(dt)
 update_mission(dt)
 update_mission_beacons(dt)
 update_mission_props(dt)
 update_mission_encounter(dt)
 update_exploration(dt)
 update_station_job()
 scan_cooldown=maxf(0.0,scan_cooldown-dt)
 update_station_traffic(dt)
 update_unknown(dt)
 if clearance_granted and not docked and landing_timer<=0.0:
  clearance_timer-=dt
  if clearance_timer<=0.0 or dock_range()>2200.0:
   clearance_granted=false
   announce("DOCK CONTROL: CLEARANCE EXPIRED — REQUEST AGAIN")
 hud_refresh_timer -= dt
 if hud_refresh_timer <= 0.0:
  hud_refresh_timer = HUD_REFRESH_INTERVAL
  update_hud()
 diagnostics_refresh_timer -= dt
 if diagnostics_visible and diagnostics_refresh_timer <= 0.0:
  diagnostics_refresh_timer = 0.25
  update_diagnostics()
 autosave_timer += dt
 if autosave_timer > 60.0:
  if jump_timer<=0.0 and world_transition<=0.0 and landing_timer<=0.0 and launch_timer<=0.0:
   autosave_timer = 0.0
   save_game()

func update_flight(dt: float) -> void:
 # PASS44: fuel-reserve protection applies only to automatic navigation.
 p44_fuel_reserve_tick()
 # PASS43: periodic contact assessment, not an every-frame full scan.
 p43_guardian_tick(dt)
 p41_scan_timer -= dt
 if p41_scan_timer <= 0.0:
  p41_scan_timer = 0.24
  p41_scan_forward()
 if p42_detour_timer > 0.0:
  p42_detour_timer = maxf(0.0, p42_detour_timer - dt)
 # Low hull triggers a latched emergency hold; the pilot can acknowledge with CTRL+6.
 if (hull_hp <= 19.0 or (hull_hp <= 38.0 and shield_hp <= 8.0)) and not p41_emergency_hold and (p37_flight_mode != 0 or p38_nav_mode != 0):
  p41_emergency_hold = true
  p37_flight_mode = 0
  p38_nav_mode = 0
  p42_evasion_active = false
  p43_auto_evading = false
  p42_status = "CRITICAL DAMAGE / MANUAL"
  p37_status = "EMERGENCY HOLD"
  p38_nav_status = "EMERGENCY HOLD"
  throttle = 0.0
  boost_active = false
  announce("CRITICAL DAMAGE — AUTOPILOT HOLD / CTRL+6 ACKNOWLEDGE")
 var engine_level = float(upgrades["engine"])
 var steer_input = Vector3(
  float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)) - mouse_delta.y * 8.0,
  float(Input.is_key_pressed(KEY_A)) - float(Input.is_key_pressed(KEY_D)) - mouse_delta.x * 8.0,
  float(Input.is_key_pressed(KEY_R)) - float(Input.is_key_pressed(KEY_Q)) + roll_delta * 5.0
 )
 # PASS38: local travel pilot uses the real flight model and brakes for arrival.
 if p38_nav_mode != 0:
  if engine_cutoff or docked or jump_timer > 0.0 or on_surface or world_transition > 0.0 or landing_timer > 0.0:
   p38_nav_mode = 0
   p38_nav_status = "DISENGAGED"
  else:
   var p38_destination: Vector3 = nav_waypoint() if p38_nav_mode == 1 else station_position + Vector3(0.0, 0.0, 350.0)
   if p38_nav_mode == 1 and nav_target == 0 and mission_stage < 6:
    p38_destination = mission_objective_position()
   if p38_nav_mode == 1 and is_instance_valid(pass46_auto) and pass46_auto.enabled and pass46_auto.escort_override:
    p38_destination = pass46_auto.escort_destination
   var p38_vector: Vector3 = p38_destination - flight_pos
   var p38_distance: float = p38_vector.length()
   var p38_radius: float = 180.0 if p38_nav_mode == 3 else (350.0 if p38_nav_mode == 2 else p38_arrival_radius)
   if p38_nav_mode == 3 and dock_range() <= 900.0:
    if not clearance_granted:
     attempt_dock()
    if clearance_granted and velocity <= 65.0 and linear_velocity.length() <= 85.0:
     p38_nav_mode = 0
     p38_nav_status = "AUTO DOCK / LANDING"
     begin_landing()
    elif clearance_granted:
     p38_nav_status = "DOCK BRAKING / %d M/S" % int(velocity)
   elif p38_nav_mode == 3 and dock_range() <= 1600.0 and not clearance_granted:
    attempt_dock()
   if p38_nav_mode == 3 and dock_range() > 900.0:
    p38_nav_status = "AUTO DOCK / %d M TO STATION" % int(dock_range())
   elif p38_nav_mode != 3 and p38_distance <= p38_radius:
    p38_nav_mode = 0
    throttle = 0.0
    cruise = false
    velocity = 0.0
    linear_velocity = Vector3.ZERO
    p38_nav_status = "ARRIVED / ALL STOP"
    announce("FLIGHT COMPUTER: ARRIVED / ALL STOP — MANUAL CONTROL")
   elif p38_nav_mode != 0 and p38_distance > 0.1:
    cruise = false
    var p38_local: Vector3 = Basis.from_euler(Vector3(pitch, yaw, roll)).inverse() * p38_vector.normalized()
    steer_input.x += clampf(p38_local.y * 2.8, -0.85, 0.85)
    steer_input.y -= clampf(p38_local.x * 2.8, -0.85, 0.85)
    var p38_alignment: float = clampf(-p38_local.z, 0.0, 1.0)
    # PASS40: speed-aware stopping envelope. Never command forward thrust
    # while current stopping distance exceeds the remaining approach distance.
    var p40_remaining: float = maxf(0.0, p38_distance - p38_radius)
    var p40_brake_rate: float = 125.0 + float(upgrades["engine"]) * 18.0
    var p40_stopping_distance: float = (velocity * velocity) / maxf(1.0, 2.0 * p40_brake_rate)
    var p40_safe_speed: float = sqrt(maxf(0.0, 2.0 * p40_brake_rate * maxf(0.0, p40_remaining - 90.0)))
    var p40_cruise_speed: float = 350.0 * SHIP_SPEEDS[ship_class]
    if is_instance_valid(pass46_auto) and pass46_auto.enabled and p38_nav_mode == 1 and p38_distance > 5000.0:
     p40_cruise_speed *= 3.5
    throttle = clampf(p40_safe_speed / maxf(1.0, p40_cruise_speed), 0.0, 0.70) * p38_alignment
    if p40_stopping_distance + 90.0 >= p40_remaining or p38_alignment < 0.45:
     throttle = 0.0
    if p38_nav_mode == 3 and p38_distance < 1100.0:
     throttle = minf(throttle, 0.12)
    p38_nav_status = ("AUTO DOCK" if p38_nav_mode == 3 else ("STATION APPROACH" if p38_nav_mode == 2 else "WAYPOINT APPROACH")) + " / %d M" % int(p38_distance)
 # PASS42: keep the same avoidance side until the obstruction has cleared.
 if (p38_nav_mode != 0 or p37_flight_mode != 0 or p42_evasion_active) and p41_hazard_distance < 1500.0 and not p41_emergency_hold:
  var avoid_vec: Vector3 = p41_hazard_point - flight_pos
  if avoid_vec.length() > 0.1:
   var avoid_local: Vector3 = Basis.from_euler(Vector3(pitch,yaw,roll)).inverse() * avoid_vec.normalized()
   var hazard_alignment: float = -avoid_local.z
   if hazard_alignment > 0.35:
    var avoidance: float = clampf((1500.0-p41_hazard_distance)/1100.0,0.0,1.0)
    if p42_detour_timer <= 0.0 or p42_detour_point.distance_to(p41_hazard_point) > 400.0:
     p42_detour_side = -1.0 if avoid_local.x >= 0.0 else 1.0
     p42_detour_point = p41_hazard_point
    p42_detour_timer = 2.5
    steer_input.y += p42_detour_side * avoidance * 1.8
    steer_input.x += (-1.0 if avoid_local.y >= 0.0 else 1.0) * avoidance * 0.7
    throttle = minf(throttle,clampf((p41_hazard_distance-220.0)/1450.0,0.0,0.38))
    p41_hazard_status = "DETOUR %s / %d M" % [p41_hazard_kind,int(p41_hazard_distance)]
 # PASS42: threat-escape mode uses the same flight physics, never auto-fires.
 if p42_evasion_active:
  p42_evasion_time -= dt
  if engine_cutoff or docked or jump_timer > 0.0 or p41_emergency_hold:
   p42_evasion_active = false
   p42_status = "EVADE CANCELLED"
  else:
   var nearest_threat: Node3D = null
   var nearest_distance: float = 999999.0
   for threat in enemies:
    if not is_instance_valid(threat):
     continue
    var distance_to_threat: float = flight_pos.distance_to(threat.global_position)
    if distance_to_threat < nearest_distance:
     nearest_threat = threat
     nearest_distance = distance_to_threat
   if nearest_threat == null or nearest_distance > 2500.0 or p42_evasion_time <= 0.0:
    p42_evasion_active = false
    throttle = 0.0
    if p43_auto_evading:
     p43_auto_evading = false
     p43_recovery_cooldown = 12.0
     if p42_saved_nav_mode != 0 and not p41_emergency_hold and not engine_cutoff and not docked and not on_surface:
      p43_status = "THREAT CLEAR / RESUMING ROUTE"
      p44_log("THREAT CLEARED / ROUTE RESUMED")
      p42_resume_route()
     else:
      p43_status = "THREAT CLEAR / MANUAL"
    else:
     p42_status = "CLEAR / CTRL+SHIFT+8 RESUME ROUTE"
    announce("ESCAPE COMPLETE — MANUAL FLIGHT / CTRL+SHIFT+8 RESUME")
   else:
    var escape_vector: Vector3 = flight_pos - nearest_threat.global_position
    if escape_vector.length_squared() > 1.0:
     var escape_local: Vector3 = Basis.from_euler(Vector3(pitch,yaw,roll)).inverse() * escape_vector.normalized()
     steer_input.x += clampf(escape_local.y * 3.0,-1.0,1.0)
     steer_input.y -= clampf(escape_local.x * 3.0,-1.0,1.0)
     throttle = minf(0.78,maxf(0.30,0.75 * clampf(-escape_local.z,0.0,1.0)))
     p42_status = "EVADE / THREAT %d M / %d S" % [int(nearest_distance),int(ceilf(p42_evasion_time))]
 # The flight computer aims at the selected target, never fires automatically.
 if p37_flight_mode != 0:
  if engine_cutoff or cruise or docked or jump_timer > 0.0 or enemies.is_empty() or p38_nav_mode != 0:
   p37_flight_mode = 0
   p37_status = "MANUAL / INTERCEPT LOST"
  else:
   target_index = clampi(target_index, 0, enemies.size()-1)
   var p37_target: Node3D = enemies[target_index]
   if not is_instance_valid(p37_target):
    p37_flight_mode = 0
   else:
    var p37_offset: Vector3 = p37_target.global_position - flight_pos
    var p37_distance: float = p37_offset.length()
    if p37_distance > 0.1:
     var p37_local: Vector3 = Basis.from_euler(Vector3(pitch,yaw,roll)).inverse() * (p37_offset / p37_distance)
     var p37_turn: float = 0.65
     steer_input.x += clampf(p37_local.y * 2.5, -p37_turn, p37_turn)
     steer_input.y -= clampf(p37_local.x * 2.5, -p37_turn, p37_turn)
     if p37_flight_mode == 1:
      throttle = clampf((p37_distance-300.0)/1450.0,0.18,0.85)
      p37_status = "PURSUIT / %d M" % int(p37_distance)
     else:
      throttle = clampf((p37_distance-p37_combat_range)/1000.0+0.24,0.0,0.75)
      p37_status = "RANGE HOLD / %d M → %d M" % [int(p37_distance),int(p37_combat_range)]
 mouse_delta = Vector2.ZERO
 roll_delta = 0.0
 var turn_rate = (1.10 + engine_level * .035) * (0.78+float(p36_power_engines)*0.11) * ship_response * SHIP_TURNS[ship_class] * (1.0+float(ship_outfit[1]-1)*.06)
 # Blue-zone handling: best response at 45-75% throttle, less twitchy at full burn.
 var response_factor: float = 1.12 if throttle >= p34_optimal_min and throttle <= p34_optimal_max else (0.78 if throttle > 0.90 else 0.94)
 var desired_angular = Vector3(steer_input.x, steer_input.y, steer_input.z) * turn_rate * response_factor
 angular_velocity = angular_velocity.lerp(desired_angular, minf(1.0, dt * 7.5))
 pitch = clampf(pitch + angular_velocity.x * dt, -1.52, 1.52)
 yaw += angular_velocity.y * dt
 roll += angular_velocity.z * dt
 if flight_assist and absf(steer_input.z) < 0.04:
  roll = lerp_angle(roll, 0.0, minf(1.0, dt * 0.7))
 if not engine_cutoff and Input.is_key_pressed(KEY_SHIFT): throttle = minf(1.0, throttle + dt * .65)
 if not engine_cutoff and Input.is_key_pressed(KEY_CTRL) and p37_flight_mode == 0 and p38_nav_mode == 0 and not p40_control_combo_held():
  throttle = maxf(0.0, throttle - dt * .8)
 if engine_cutoff or p41_emergency_hold: throttle = 0.0
 boost_active = not engine_cutoff and Input.is_key_pressed(KEY_SPACE) and boost_reserve > 3.0 and not cruise
 if boost_active: boost_reserve = maxf(0.0, boost_reserve - dt * 23.0 / (1.0+float(ship_outfit[0]-1)*.11))
 else: boost_reserve = minf(100.0, boost_reserve + dt * (6.0 if cruise else 12.0)*(1.0+float(ship_outfit[0]-1)*.16))
 if cruise: cruise_spool = minf(1.0, cruise_spool + dt / 2.6)
 else: cruise_spool = maxf(0.0, cruise_spool - dt * 1.8)
 var normal_cap = 350.0 * (1.0 + (engine_level - 1.0) * .17) * SHIP_SPEEDS[ship_class] * (1.0+float(ship_outfit[1]-1)*.07)
 if is_instance_valid(living_galaxy): normal_cap *= 1.0 + float(living_galaxy.state.installed.get("legendary_drive",0))*.12
 var cruise_cap = 2300.0 * (1.0 + (engine_level - 1.0) * .08) * (0.88+SHIP_SPEEDS[ship_class]*.12)
 var cap = lerpf(normal_cap, cruise_cap, cruise_spool) * (0.82+float(p36_power_engines)*0.09) * (1.27 if p36_overdrive_timer>0.0 else 1.0)
 if boost_active: cap *= 1.75
 # Long-distance AUTO MISSIONS use a higher transit cap; normal and manual flight are unchanged.
 if is_instance_valid(pass46_auto) and pass46_auto.enabled and p38_nav_mode == 1:
  var auto_leg_distance: float = flight_pos.distance_to(mission_objective_position())
  if pass46_auto.escort_override:
   auto_leg_distance = flight_pos.distance_to(pass46_auto.escort_destination)
  if auto_leg_distance > 5000.0:
   cap *= 3.5
 var desired_speed = throttle * cap
 if engine_cutoff:
  desired_speed = 0.0
  velocity = 0.0
  linear_velocity = Vector3.ZERO
 if nav_assist and cruise:
  var destination: Vector3 = nav_waypoint()
  if nav_target == 0 and mission_stage < 6:
   destination = mission_objective_position()
  var dist = flight_pos.distance_to(destination)
  desired_speed = minf(desired_speed, maxf(65.0, (dist - 260.0) * 0.65))
 var accel = (175.0 + engine_level * 25.0) * (3.0 if cruise_spool > 0.1 else 1.0)
 if boost_active: accel *= 2.0
 velocity = move_toward(velocity, desired_speed, dt * accel)
 var rotation_basis = Basis.from_euler(Vector3(pitch, yaw, roll))
 var forward = -rotation_basis.z
 var desired_vector = forward * velocity
 if flight_assist:
  linear_velocity = linear_velocity.lerp(desired_vector, minf(1.0, dt * (3.5 if cruise else 2.2)))
 else:
  linear_velocity = linear_velocity.move_toward(desired_vector, dt * accel * 0.7)
 flight_pos += linear_velocity * dt
 if Input.is_key_pressed(KEY_F) and shot_cooldown <= 0.0: fire()

func update_flight_camera(dt: float) -> void:
 if docked and landing_timer<=0.0:
  var hangar_cam = station_pad+Vector3(35,43,95)
  camera.global_position=camera.global_position.lerp(hangar_cam,minf(1.0,dt*4.0))
  camera.look_at(station_pad+Vector3(0,8,-20),Vector3.UP)
  camera.fov=68.0
  return
 camera_distance = lerpf(camera_distance, chase_distance_target, minf(1.0, dt * 5.0))
 var cam_offset = Vector3(0, 12.0 + velocity * .007, camera_distance) if chase else Vector3(0, 3.6, -7.0)
 var desired_camera = player.to_global(cam_offset)
 var smoothing = 7.0 if chase else 18.0
 camera.global_position = camera.global_position.lerp(desired_camera, minf(1.0, dt * smoothing))
 camera.global_rotation = player.global_rotation
 var desired_fov = 76.0 + (6.0 if cruise_spool > .9 else 0.0) + (5.0 if boost_active else 0.0)
 camera_fov = lerpf(camera_fov, desired_fov, minf(1.0, dt * 3.0))
 camera.fov = camera_fov
 # Apply shake once per frame without accumulating camera drift.
 if camera_shake > 0.0:
  camera.global_position += camera.global_transform.basis * Vector3(rng.randf_range(-.4,.4),rng.randf_range(-.4,.4),0) * camera_shake

func begin_jump() -> void:
 if menu_open:
  announce("CLOSE THE MENU BEFORE ENGAGING FRAME SHIFT")
  return
 if unknown_pocket: announce("RETURN FROM SANCTUARY WITH 8 BEFORE JUMPING"); return
 if on_surface or world_transition>0.0:
  announce("FRAME SHIFT LOCKED — ASCEND TO ORBIT WITH 1")
  return
 if docked or jump_timer>0.0 or landing_timer>0.0 or launch_timer>0.0: return
 if route_legs.is_empty():
  announce("NO JUMP ROUTE — OPEN GALAXY MAP (G) AND PLOT A DESTINATION")
  return
 var next_sector: int=route_legs[0]
 if not SECTOR_LINKS[current_system].has(next_sector):
  plot_route(route_destination, false)
  if route_legs.is_empty(): return
  next_sector=route_legs[0]
 var cost=jump_fuel_cost(current_system,next_sector)
 if fuel<float(cost):
  announce("FRAME SHIFT DENIED — NEED %d FUEL / HAVE %d. DOCK TO REFUEL" % [cost,int(fuel)])
  return
 fuel-=float(cost)
 jump_from=current_system
 jump_to=next_sector
 jump_timer=jump_charge_total
 cruise=false
 cruise_spool=0.0
 clearance_granted=false
 clearance_timer=0.0
 close_menu()
 announce("FRAME SHIFT SPOOLING — %s / FUEL -%d" % [SYSTEM_NAMES[next_sector],cost])

func complete_jump() -> void:
 bounty_active=false
 current_system=jump_to
 jump_target=current_system
 flight_pos=SECTOR_ORIGINS[current_system]+Vector3(0,0,950)
 yaw=0.0
 pitch=0.0
 roll=0.0
 throttle=0.0
 velocity=0.0
 linear_velocity=Vector3.ZERO
 if not visited_sectors.has(current_system): visited_sectors.append(current_system)
 if not charted_sectors.has(current_system): charted_sectors.append(current_system)
 if not route_legs.is_empty() and route_legs[0]==current_system: route_legs.remove_at(0)
 setup_sector(current_system)
 create_mission_beacons()
 spawn_enemies()
 if route_legs.is_empty():
  route_destination=-1
  announce("ARRIVED — %s / ROUTE COMPLETE" % SYSTEM_NAMES[current_system])
 else:
  announce("ARRIVED — %s / NEXT LEG %s (J)" % [SYSTEM_NAMES[current_system],SYSTEM_NAMES[route_legs[0]]])
 save_game()

func attempt_dock() -> void:
 if jump_timer>0.0 or world_transition>0.0:
  announce("DOCKING UNAVAILABLE DURING TRANSITION")
  return
 if on_surface:
  announce("SURFACE FLIGHT — PRESS 1 TO ASCEND BEFORE DOCKING")
  return
 if landing_timer>0.0 or launch_timer>0.0:return
 if docked:
  launch_from_station()
  return
 if not clearance_granted:
  if dock_range()>1600.0:announce("DOCK CONTROL: MOVE WITHIN 1,600 M TO REQUEST CLEARANCE");return
  clearance_granted=true
  clearance_timer=90.0
  announce("DOCK CONTROL: CLEARANCE GRANTED — APPROACH WITHIN 900 M AND PRESS E")
  return
 begin_landing()

# PASS 6 - Combat with enemy pursuit, return fire, shields, damage, destruction and targeting.
# PASS 13 — tactical combat, class-based ships, real projectile collisions and salvage.
func spawn_enemies() -> void:
 for e in enemies:
  if is_instance_valid(e): e.queue_free()
 enemies.clear()
 for p in enemy_shots:
  if is_instance_valid(p["node"]): p["node"].queue_free()
 enemy_shots.clear()
 for p in missiles:
  if is_instance_valid(p["node"]): p["node"].queue_free()
 missiles.clear()
 target_index = 0
 if not bounty_active and (mission_stage!=1 and mission_stage!=3 or current_system!=mission_current_sector() or (mission_objective_kind()!="combat" and mission_objective_kind()!="defense" and mission_objective_kind()!="escort")): return
 combat_wave += 1
 var center: Vector3 = flight_pos if bounty_active else mission_objective_position()
 var classes = ["interceptor","gunship","interceptor","frigate","interceptor","dreadnought"] if bounty_active else (["interceptor","gunship"] if mission_objective_kind()=="escort" else ["interceptor","gunship","interceptor"])
 for i in range(classes.size()):
  var kind: String = classes[i]
  var e = Node3D.new()
  e.name = kind.capitalize()+"_"+str(i+1)
  e.position = center + Vector3((float(i%3)-1.0)*420.0,80.0+float(i/3)*160.0,-520.0-float(i/3)*390.0)
  add_child(e)
  build_enemy_visual(e,kind)
  var hp = 65.0 if kind=="interceptor" else (175.0 if kind=="gunship" else (320.0 if kind=="frigate" else 850.0))
  var sh = 45.0 if kind=="interceptor" else (110.0 if kind=="gunship" else (170.0 if kind=="frigate" else 350.0))
  e.set_meta("hp",hp)
  e.set_meta("max_hp",hp)
  e.set_meta("shield",sh)
  e.set_meta("max_shield",sh)
  e.set_meta("class",kind)
  e.set_meta("phase",float(i)*1.5)
  e.set_meta("fire_timer",0.6+float(i)*0.42)
  e.set_meta("engine_damage",0.0)
  e.set_meta("weapon_damage",0.0)
  e.set_meta("shield_damage",0.0)
  e.set_meta("missile_timer",7.0+float(i))
  e.set_meta("flank",-1.0 if i%2==0 else 1.0)
  enemies.append(e)

func build_enemy_visual(e: Node3D, kind: String) -> void:
 var scale_factor = 1.0 if kind=="interceptor" else (1.7 if kind=="gunship" else (2.5 if kind=="frigate" else 5.0))
 var verts = PackedVector3Array([
  Vector3(0,2,-25),Vector3(-18,-1,12),Vector3(0,5,11),
  Vector3(0,2,-25),Vector3(0,5,11),Vector3(18,-1,12),
  Vector3(0,-3,-14),Vector3(0,2,-25),Vector3(18,-1,12),
  Vector3(0,-3,-14),Vector3(18,-1,12),Vector3(-18,-1,12),
  Vector3(0,-3,-14),Vector3(-18,-1,12),Vector3(0,2,-25)
 ])
 triangle_mesh(e,verts,Color(0.52,0.17,0.21) if kind!="dreadnought" else Color(0.28,0.23,0.39))
 var hull = cube(e,Vector3(0,0,4),Vector3(9,5,26),Color(0.20,0.17,0.24))
 hull.rotation.y=0.0
 ball(e,Vector3(0,5,-4),3.2,Color(0.82,0.20,0.16),0.4)
 for side in [-1.0,1.0]:
  var wing = cube(e,Vector3(side*14,-1,5),Vector3(16,1.5,12),Color(0.31,0.24,0.33))
  wing.rotation.y = side*0.2
  tube(e,Vector3(side*10,-1,13),2.5,11,Color(0.12,0.11,0.20))
  ball(e,Vector3(side*10,-1,19),2.3,Color(1.0,0.33,0.12),2.2,10)
  if kind=="gunship" or kind=="frigate" or kind=="dreadnought":
   tube(e,Vector3(side*8,4,-5),1.4,14,Color(0.45,0.36,0.45))
 if kind=="dreadnought":
  for n in range(4):
   cube(e,Vector3(-9.0+float(n)*6.0,6,10),Vector3(3,5,20),Color(0.39,0.27,0.45))
   ball(e,Vector3(-9.0+float(n)*6.0,9,-3),1.7,Color(1,0.28,0.18),1.7,8)
 e.scale = Vector3.ONE*scale_factor

func restore_enemy_state() -> void:
 if restored_enemy_state.is_empty(): return
 for e in enemies.duplicate():
  var found=false
  for state in restored_enemy_state:
   if state is Dictionary and str(state.get("name",""))==e.name: found=true;break
  if not found: enemies.erase(e);e.queue_free()
 for state in restored_enemy_state:
  if not state is Dictionary: continue
  for e in enemies:
   if e.name!=str(state.get("name","")): continue
   if bool(state.get("destroyed",false)):
    enemies.erase(e)
    e.queue_free()
   else:
    e.set_meta("hp",clampf(float(state.get("hp",e.get_meta("hp"))),0.1,float(e.get_meta("max_hp"))))
    e.set_meta("shield",clampf(float(state.get("shield",e.get_meta("shield"))),0.0,float(e.get_meta("max_shield"))))
    for k in ["engine_damage","weapon_damage","shield_damage"]:
     e.set_meta(k,clampf(float(state.get(k,0.0)),0.0,0.9))
   break
 restored_enemy_state.clear()

func p34_target_nearest() -> void:
 var nearest: float = INF
 var chosen: int = -1
 for i in range(enemies.size()):
  var e: Node3D = enemies[i]
  if not is_instance_valid(e): continue
  var distance: float = flight_pos.distance_to(e.global_position)
  if distance < nearest:
   nearest = distance
   chosen = i
 if chosen < 0:
  announce("SCANNER CLEAR — NO HOSTILE CONTACTS")
  return
 target_index = chosen
 announce("NEAREST HOSTILE LOCKED: %s / %d M" % [enemies[chosen].name,int(nearest)])

func p34_track_targets(dt: float) -> void:
 var present: Dictionary = {}
 for e in enemies:
  if not is_instance_valid(e): continue
  var key: int = e.get_instance_id()
  present[key] = true
  if p34_target_last.has(key) and dt > 0.0001:
   var measured: Vector3 = (e.global_position - p34_target_last[key]) / dt
   var previous: Vector3 = p34_target_vel.get(key,Vector3.ZERO)
   p34_target_vel[key] = previous.lerp(measured,minf(1.0,dt*7.0))
  p34_target_last[key] = e.global_position
 for key in p34_target_last.keys():
  if not present.has(key):
   p34_target_last.erase(key)
   p34_target_vel.erase(key)

func p34_update_aim() -> void:
 if p34_lead_label == null: return
 p34_lead_label.hide()
 if docked or menu_open or jump_timer > 0.0 or enemies.is_empty(): return
 var idx: int = clampi(target_index,0,enemies.size()-1)
 var e: Node3D = enemies[idx]
 if not is_instance_valid(e): return
 var muzzle: Vector3 = player.to_global(Vector3(0,0,-19))
 var distance: float = muzzle.distance_to(e.global_position)
 if distance > 4500.0: return
 var bullet_speed: float = [3300.0,6500.0,2600.0][weapon_mode]
 var travel: float = distance / bullet_speed
 var enemy_velocity: Vector3 = p34_target_vel.get(e.get_instance_id(),Vector3.ZERO)
 var lead_point: Vector3 = e.global_position + enemy_velocity * travel
 if camera.is_position_behind(lead_point): return
 var screen: Vector2 = camera.unproject_position(lead_point)
 var size: Vector2 = get_viewport().get_visible_rect().size
 if screen.x < 10.0 or screen.y < 10.0 or screen.x > size.x-100.0 or screen.y > size.y-30.0: return
 p34_lead_label.position = screen-Vector2(28,14)
 p34_lead_label.text = "◇ LEAD"
 p34_lead_label.show()

func cycle_target() -> void:
 if enemies.is_empty(): announce("NO HOSTILE CONTACTS"); return
 target_index = (target_index+1)%enemies.size()
 announce("TARGET LOCK — "+enemies[target_index].name)

# PASS 35 / Phase 2 — nonlethal boarding and subsystem combat.
func p35_board_target() -> void:
 if docked or menu_open or jump_timer>0.0: return
 if enemies.is_empty(): announce("NO TARGET TO BOARD / TAB SELECTS HOSTILES"); return
 var e: Node3D=enemies[clampi(target_index,0,enemies.size()-1)]
 if not is_instance_valid(e): return
 var range_m: float=flight_pos.distance_to(e.global_position)
 if range_m>350.0: announce("BOARDING RANGE 350 M / CURRENT %d M" % int(range_m)); return
 if float(e.get_meta("shield",0.0))>1.0: announce("BOARDING DENIED / STRIP TARGET SHIELDS"); return
 if float(e.get_meta("engine_damage",0.0))<0.92: announce("BOARDING DENIED / TARGET ENGINES STILL ACTIVE / T SELECT ENGINES"); return
 if float(e.get_meta("hp",0.0))>float(e.get_meta("max_hp",1.0))*0.50: announce("BOARDING DENIED / REDUCE HULL BELOW 50 PERCENT"); return
 if is_instance_valid(living_galaxy) and e.has_meta("living_captain"):
  living_galaxy.hunt_action("capture")
  return
 if e.has_meta("echo_decoy"): announce("CANNOT BOARD FALSE SIGNAL"); return
 var kind: String=str(e.get_meta("class","interceptor"))
 var payment: int=400 if kind=="interceptor" else (800 if kind=="gunship" else (1400 if kind=="frigate" else 3000))
 credits+=payment
 drop_salvage(e.global_position,kind)
 enemies.erase(e)
 e.queue_free()
 target_index=clampi(target_index,0,maxi(0,enemies.size()-1))
 announce("VESSEL SECURED / CREW SURRENDERED / +%d CR / SALVAGE RELEASED" % payment)
 save_game()

func cycle_subsystem() -> void:
 target_subsystem = (target_subsystem+1)%subsystem_names.size()
 announce("TARGETING SUBSYSTEM: "+subsystem_names[target_subsystem])

func fire() -> void:
 if weapon_overheat or weapon_heat>94.0:
  if not weapon_overheat: announce("WEAPON SYSTEM OVERHEATED — COOLING")
  weapon_overheat=true
  return
 var cooldowns=[0.17,0.85,0.52]
 var heat_costs=[4.0,25.0,16.0]
 shot_cooldown=maxf(0.08,(float(cooldowns[weapon_mode])-float(upgrades["weapon"]-1)*0.012)*(1.25-float(p36_power_weapons)*0.12))
 weapon_heat=minf(100.0,weapon_heat+float(heat_costs[weapon_mode])*(1.2 if shield_power==2 else (0.75 if shield_power==0 else 1.0)))
 var count=(2+int(ship_outfit[2]/2)+(2 if ship_class>=3 else 0)) if weapon_mode==0 else (1 if weapon_mode==1 else 5)
 for i in range(count):
  var spread=0.0 if weapon_mode!=2 else float(i-2)*0.044
  var side=-1.0 if i%2==0 else 1.0
  var pos=player.to_global(Vector3(side*7.0,0,-19))
  var direction=(-player.global_transform.basis.z+player.global_transform.basis.x*spread).normalized()
  var color=Color(0.15,0.87,1.0) if weapon_mode==0 else (Color(1.0,0.65,0.18) if weapon_mode==1 else Color(0.62,1.0,0.32))
  var b=ball(self,pos,1.65 if weapon_mode==0 else (2.7 if weapon_mode==1 else 1.15),color,3.0,8)
  bullets.append({"node":b,"previous":b.position,"direction":direction,"ttl":2.0,"damage":(19.0 if weapon_mode==0 else (118.0 if weapon_mode==1 else 15.0))*(1.0+float(ship_outfit[2]-1)*.12),"speed":(3300.0 if weapon_mode==0 else (6500.0 if weapon_mode==1 else 2600.0))})
 while bullets.size()>100:
  var oldest = bullets.pop_front()
  if is_instance_valid(oldest["node"]): oldest["node"].queue_free()

func projectile_near_segment(point: Vector3, start: Vector3, finish: Vector3, radius: float) -> bool:
 var path = finish-start
 var ratio = clampf((point-start).dot(path)/maxf(0.01,path.length_squared()),0.0,1.0)
 return point.distance_to(start+path*ratio)<=radius

func hit_enemy(e: Node3D, damage: float, system_hit: int) -> void:
 if not is_instance_valid(e): return
 combat_damage_dealt+=damage
 var es = float(e.get_meta("shield"))
 if es>0.0:
  var absorbed = minf(es,damage)
  e.set_meta("shield",es-absorbed)
  damage -= absorbed
  spawn_impact(e.position,Color(0.22,0.73,1.0),20.0)
 if damage>0.0:
  e.set_meta("hp",float(e.get_meta("hp"))-damage)
  spawn_impact(e.position,Color(1.0,0.45,0.12),16.0)
  if system_hit==1: e.set_meta("engine_damage",minf(1.0,float(e.get_meta("engine_damage"))+damage/185.0))
  if system_hit==2: e.set_meta("weapon_damage",minf(1.0,float(e.get_meta("weapon_damage"))+damage/170.0))
  if system_hit==3: e.set_meta("shield_damage",minf(1.0,float(e.get_meta("shield_damage"))+damage/175.0))
  if float(e.get_meta("engine_damage"))>=0.92 and not bool(e.get_meta("p35_disabled",false)):
   e.set_meta("p35_disabled",true)
   announce("%s / ENGINES DISABLED / SHIFT+B TO BOARD" % e.name)
 if float(e.get_meta("hp"))<=0.0:
  destroy_enemy(e)

func destroy_enemy(e: Node3D) -> void:
 if e.has_meta("echo_decoy"):
  spawn_impact(e.position,Color(.2,.8,1.0),30.0)
  enemies.erase(e);e.queue_free()
  announce("FALSE SIGNAL DISPERSED / NO BOUNTY OR CARGO")
  return
 if is_instance_valid(living_galaxy): living_galaxy.enemy_destroyed(e)
 var kind: String = str(e.get_meta("class"))
 var reward = 650 if kind=="interceptor" else (1100 if kind=="gunship" else (1900 if kind=="frigate" else 5400))
 spawn_impact(e.position,Color(1.0,0.53,0.16),45.0 if kind!="dreadnought" else 110.0)
 drop_salvage(e.position,kind)
 enemies.erase(e)
 e.queue_free()
 mission_kills+=1
 if not bounty_active and current_system==mission_current_sector() and (mission_stage==1 or mission_stage==3) and (mission_objective_kind()=="combat" or mission_objective_kind()=="defense"): mission_phase_kills+=1
 combat_kills+=1
 credits+=reward
 target_index=clampi(target_index,0,maxi(0,enemies.size()-1))
 announce(kind.to_upper()+" DESTROYED  +"+str(reward)+" CR  /  SALVAGE RELEASED")

func spawn_impact(where: Vector3, tint: Color, size: float) -> void:
 var flash = ball(self,where,maxf(2.0,size*0.23),tint,2.8,10)
 effects.append({"node":flash,"life":0.36,"size":size})
 while effects.size()>36:
  var old = effects.pop_front()
  if is_instance_valid(old["node"]): old["node"].queue_free()

func update_bullets(dt: float) -> void:
 for i in range(bullets.size()-1,-1,-1):
  var p: Dictionary = bullets[i]
  var n: Node3D = p["node"]
  if not is_instance_valid(n): bullets.remove_at(i); continue
  var before: Vector3 = n.position
  n.position += p["direction"]*dt*float(p.get("speed",3300.0))
  p["ttl"] = float(p["ttl"])-dt
  var hit = false
  for e in enemies:
   if not is_instance_valid(e): continue
   var radius = 25.0*e.scale.x
   if projectile_near_segment(e.position,before,n.position,radius):
    hit_enemy(e,float(p.get("damage",19.0))+float(upgrades["weapon"]-1)*8.0,target_subsystem)
    hit=true
    break
  if hit or float(p["ttl"])<=0.0:
   n.queue_free()
   bullets.remove_at(i)
  else: bullets[i]=p
 for i in range(effects.size()-1,-1,-1):
  var effect: Dictionary = effects[i]
  var node: Node3D = effect["node"]
  effect["life"] = float(effect["life"])-dt
  if is_instance_valid(node): node.scale=Vector3.ONE*(1.0+dt*5.0)
  if float(effect["life"])<=0.0:
   if is_instance_valid(node): node.queue_free()
   effects.remove_at(i)
  else: effects[i]=effect

func launch_missile() -> void:
 if docked or menu_open or jump_timer>0.0: return
 if missile_cooldown>0.0: announce("MISSILE RACK RELOADING");return
 if missile_ammo<=0: announce("MISSILE RACK EMPTY — REARM AT COMMAND CENTER");return
 if enemies.is_empty(): announce("MISSILE REQUIRES A HOSTILE LOCK");return
 target_index=clampi(target_index,0,enemies.size()-1)
 var e: Node3D = enemies[target_index]
 if e.position.distance_to(flight_pos)>3400.0: announce("TARGET OUTSIDE MISSILE RANGE");return
 missile_ammo-=1
 combat_missiles_fired+=1
 missile_cooldown=1.4
 var n = tube(self,player.to_global(Vector3(0,-3,-22)),1.7,10,Color(1,0.65,0.2),2.0)
 n.rotation.x=PI/2.0
 missiles.append({"node":n,"target":e,"velocity":-player.global_transform.basis.z*900.0,"ttl":7.0})
 announce("MISSILE AWAY — "+e.name)

func update_missiles(dt: float) -> void:
 for i in range(missiles.size()-1,-1,-1):
  var m: Dictionary = missiles[i]
  var n: Node3D = m["node"]
  if not is_instance_valid(n): missiles.remove_at(i); continue
  var e: Node3D = m["target"]
  m["ttl"] = float(m["ttl"])-dt
  if not is_instance_valid(e) or float(m["ttl"])<=0.0:
   n.queue_free(); missiles.remove_at(i); continue
  var desired: Vector3 = (e.position-n.position).normalized()*1500.0
  var v: Vector3 = m["velocity"]
  v=v.lerp(desired,minf(1.0,dt*2.8))
  var before: Vector3=n.position
  n.position+=v*dt
  m["velocity"]=v
  if projectile_near_segment(e.position,before,n.position,30.0*e.scale.x):
   hit_enemy(e,125.0+float(upgrades["weapon"]-1)*22.0,target_subsystem)
   spawn_impact(n.position,Color(1,0.52,0.12),55.0)
   n.queue_free(); missiles.remove_at(i)
  else: missiles[i]=m

func deploy_countermeasures() -> void:
 if docked or menu_open: return
 if countermeasure_cooldown>0.0: announce("COUNTERMEASURES RECHARGING");return
 countermeasure_cooldown=12.0
 countermeasure_timer=2.5
 for i in range(10):
  var theta=TAU*float(i)/10.0
  spawn_impact(flight_pos+Vector3(cos(theta)*30.0,sin(theta)*30.0,0),Color(0.4,0.9,1.0),20.0)
 announce("COUNTERMEASURES DEPLOYED — INCOMING MISSILE JAMMING ACTIVE")

func fire_enemy_projectile(e: Node3D, missile: bool=false) -> void:
 if enemy_shots.size()>=55: return
 var origin: Vector3=e.position+Vector3(0,0,-12.0*e.scale.x)
 var n=ball(self,origin,4.0 if missile else 2.7,Color(1.0,0.22,0.13) if missile else Color(1.0,0.48,0.22),2.2,8)
 var target_drone=wingman_active and is_instance_valid(wingman) and rng.randf()<0.17
 var target_sentinel=not target_drone and fleet_drone_active and is_instance_valid(fleet_drone) and rng.randf()<0.17
 var aim_point=wingman.position if target_drone else (fleet_drone.position if target_sentinel else flight_pos)
 var direction=(aim_point-origin).normalized()
 enemy_shots.append({"node":n,"velocity":direction*(530.0 if missile else 1300.0),"ttl":6.0 if missile else 2.4,"missile":missile,"damage":24.0 if missile else 8.0,"target_drone":target_drone,"target_sentinel":target_sentinel})

func update_enemy_shots(dt: float) -> void:
 for i in range(enemy_shots.size()-1,-1,-1):
  var shot: Dictionary=enemy_shots[i]
  var n: Node3D=shot["node"]
  if not is_instance_valid(n): enemy_shots.remove_at(i);continue
  shot["ttl"]=float(shot["ttl"])-dt
  var before: Vector3=n.position
  var v: Vector3=shot["velocity"]
  if bool(shot["missile"]):
   if countermeasure_timer>0.0:
    spawn_impact(n.position,Color(0.7,0.8,1.0),20.0)
    n.queue_free(); enemy_shots.remove_at(i); continue
   var aim=wingman.position if bool(shot.get("target_drone",false)) and wingman_active and is_instance_valid(wingman) else (fleet_drone.position if bool(shot.get("target_sentinel",false)) and fleet_drone_active and is_instance_valid(fleet_drone) else flight_pos)
   v=v.lerp((aim-n.position).normalized()*680.0,minf(1.0,dt*1.6))
   shot["velocity"]=v
  n.position+=v*dt
  if bool(shot.get("target_drone",false)) and wingman_active and is_instance_valid(wingman) and projectile_near_segment(wingman.position,before,n.position,19.0):
   wingman_hp=maxf(0.0,wingman_hp-float(shot["damage"]))
   spawn_impact(wingman.position,Color(0.4,0.9,1.0),20.0)
   n.queue_free();enemy_shots.remove_at(i)
   if wingman_hp<=0.0:
    wingman_active=false
    wingman.visible=false
    announce("AEGIS WINGMAN DISABLED — REPAIR AT COMMAND CENTER")
  elif bool(shot.get("target_sentinel",false)) and fleet_drone_active and is_instance_valid(fleet_drone) and projectile_near_segment(fleet_drone.position,before,n.position,19.0):
   fleet_drone_hp=maxf(0.0,fleet_drone_hp-float(shot["damage"]))
   spawn_impact(fleet_drone.position,Color(.95,.68,.19),17.0)
   n.queue_free();enemy_shots.remove_at(i)
   if fleet_drone_hp<=0.0:
    fleet_drone_active=false
    fleet_drone.visible=false
    announce("SENTINEL DISABLED — RETURN TO FLEET SERVICE")
  elif not docked and jump_timer<=0.0 and projectile_near_segment(flight_pos,before,n.position,24.0):
   receive_damage(float(shot["damage"]))
   spawn_impact(n.position,Color(0.22,0.75,1.0) if shield_hp>0.0 else Color(1,0.33,0.15),22.0)
   n.queue_free(); enemy_shots.remove_at(i)
  elif float(shot["ttl"])<=0.0:
   n.queue_free(); enemy_shots.remove_at(i)
  else: enemy_shots[i]=shot

func update_enemies(dt: float) -> void:
 if menu_open or docked or jump_timer>0.0: return
 for e in enemies:
  if not is_instance_valid(e): continue
  var distance=e.position.distance_to(flight_pos)
  if distance>3400.0: continue
  var kind: String=str(e.get_meta("class"))
  var phase=float(e.get_meta("phase"))
  var flank=float(e.get_meta("flank"))
  var engine_penalty=1.0-float(e.get_meta("engine_damage"))
  if engine_penalty<=0.08: e.set_meta("p35_disabled",true)
  var speed=(170.0 if kind=="interceptor" else (110.0 if kind=="gunship" else (72.0 if kind=="frigate" else 38.0)))*engine_penalty
  # A badly damaged enemy attempts to retreat; nimble ships evade incoming fire.
  var hull_ratio: float = float(e.get_meta("hp",100.0))/maxf(1.0,float(e.get_meta("max_hp",100.0)))
  var retreating: bool = hull_ratio<0.28 and engine_penalty>0.25 and kind!="dreadnought"
  var evade: float = 1.0 if kind=="interceptor" else 0.35
  var formation_offset=Vector3(flank*(110.0+sin(world_time*.7+phase)*45.0)+sin(world_time*2.7+phase)*100.0*evade,sin(world_time*.6+phase)*85.0+cos(world_time*2.1+phase)*60.0*evade,200.0+cos(world_time*.4+phase)*100.0)
  if retreating:
   var escape_dir: Vector3 = (e.position-flight_pos).normalized()
   e.position += escape_dir*speed*dt*1.5
   e.set_meta("fire_timer",maxf(0.0,float(e.get_meta("fire_timer"))-dt))
   continue
  if distance>260.0 and distance<2600.0:
   e.position=e.position.move_toward(flight_pos+formation_offset+Vector3(sin(world_time*1.7+phase)*35.0,cos(world_time*1.2+phase)*25.0,0),speed*dt)
  elif distance<=260.0:
   e.position+=Vector3(flank*speed*dt*.65,sin(world_time+phase)*dt*15.0,0)
  e.look_at(flight_pos,Vector3.UP)
  var timer=float(e.get_meta("fire_timer"))-dt
  if timer<=0.0 and distance<1750.0 and p36_jammer_timer<=0.0 and float(e.get_meta("weapon_damage"))<0.95 and not bool(e.get_meta("p35_disabled",false)):
   var gun_penalty=float(e.get_meta("weapon_damage"))
   if rng.randf()>gun_penalty:
    fire_enemy_projectile(e)
    if kind=="dreadnought": fire_enemy_projectile(e)
   timer=(1.25 if kind=="interceptor" else (1.75 if kind=="gunship" else 2.3))+rng.randf_range(0.0,0.5)
  e.set_meta("fire_timer",timer)
  var missile_timer=float(e.get_meta("missile_timer"))-dt
  if missile_timer<=0.0 and distance<1500.0 and p36_jammer_timer<=0.0 and kind!="interceptor" and float(e.get_meta("weapon_damage"))<0.95 and not bool(e.get_meta("p35_disabled",false)):
   fire_enemy_projectile(e,true)
   missile_timer=10.0+rng.randf_range(0.0,5.0)
   announce("WARNING — INCOMING HOSTILE MISSILE / L COUNTERMEASURES")
  e.set_meta("missile_timer",missile_timer)
  var shield=float(e.get_meta("shield"))
  var max_enemy_shield=float(e.get_meta("max_shield"))*(1.0-float(e.get_meta("shield_damage")))
  if shield<max_enemy_shield: e.set_meta("shield",minf(max_enemy_shield,shield+dt*1.4))
  if float(e.get_meta("shield_damage"))>=0.95: e.set_meta("shield",0.0)

func drop_salvage(where: Vector3, kind: String) -> void:
 var n=Node3D.new()
 add_child(n)
 n.position=where
 var value=1 if kind=="interceptor" else (2 if kind=="gunship" else (3 if kind=="frigate" else 7))
 var resource="alloys" if kind=="interceptor" else ("circuits" if kind=="gunship" else "cores")
 ball(n,Vector3.ZERO,9.0,Color(0.2,1.0,0.63),1.8,12)
 var ring=torus(n,Vector3.ZERO,11.0,13.0,Color(0.15,0.9,0.8),1.3)
 ring.rotation.x=PI/2.0
 n.set_meta("resource",resource)
 n.set_meta("value",value)
 n.set_meta("life",300.0)
 loot_nodes.append(n)

func update_loot(dt: float) -> void:
 for i in range(loot_nodes.size()-1,-1,-1):
  var n: Node3D=loot_nodes[i]
  if not is_instance_valid(n): loot_nodes.remove_at(i);continue
  n.rotation.y+=dt*.7
  n.set_meta("life",float(n.get_meta("life"))-dt)
  if tractor_active and not docked and n.position.distance_to(flight_pos)<680.0:
   n.position=n.position.move_toward(flight_pos,dt*370.0)
  if not docked and n.position.distance_to(flight_pos)<110.0:
   var resource: String=str(n.get_meta("resource"))
   var value: int=int(n.get_meta("value"))
   if is_instance_valid(living_galaxy) and living_galaxy.cargo_used()+value>living_galaxy.capacity():
    continue
   salvage_inventory[resource]=int(salvage_inventory.get(resource,0))+value
   announce("SALVAGE RECOVERED  +"+str(value)+" "+resource.to_upper())
   n.queue_free();loot_nodes.remove_at(i)
  elif float(n.get_meta("life"))<=0.0:
   n.queue_free();loot_nodes.remove_at(i)

func receive_damage(amount: float) -> void:
 if mission_stage<6: mission_current_damage+=maxf(0.0,amount)
 combat_damage_taken+=amount
 player_shield_delay=5.0
 var blocked=minf(shield_hp,amount)
 shield_hp-=blocked
 hull_hp=maxf(0.0,hull_hp-(amount-blocked))
 camera_shake=.9
 if hull_hp<=0.0:
  credits=maxi(0,credits-500);hull_hp=max_hull();shield_hp=max_shield();flight_pos=station_position+Vector3(0,0,800)
  throttle=0;velocity=0;linear_velocity=Vector3.ZERO;announce("EMERGENCY RESCUE — SHIP RECOVERED / -500 CR")
  save_game()
func max_hull() -> float: return SHIP_HULLS[ship_class]+float(upgrades["armor"]-1)*25.0
func max_shield() -> float: return SHIP_SHIELDS[ship_class]+float(upgrades["shield"]-1)*25.0+float(ship_outfit[3]-1)*18.0

# PASS 7 - Mission board with distinct objectives, rewards, progress and return leg.
# PASS 24: routes are mission-specific. Some contracts remain local; others
# require a linked-sector transfer between their two real objective sites.
# Long operations are selected deterministically. Existing contracts and rewards remain.
func mission_has_third_leg(index: int) -> bool:
 return index % 3 == 1 or index % 7 == 2

func mission_third_sector(index: int) -> int:
 var second: int=mission_sector_for(index,2)
 var first: int=int(MISSIONS[index]["sector"])
 var links: Array=SECTOR_LINKS[second]
 for k in range(links.size()):
  var candidate: int=int(links[(index+k+1)%links.size()])
  if candidate!=first and candidate!=second: return candidate
 return int(links[(index+1)%links.size()])

func mission_third_position(index: int) -> Vector3:
 var target: int=mission_third_sector(index)
 var offset=Vector3(-4200.0+float((index*1091)%6500),160.0+float((index*97)%530),-3400.0-float((index*1277)%7200))
 return SECTOR_ORIGINS[target]+offset

func mission_third_kind(index: int) -> String:
 var kinds=["scan","salvage","combat","rescue","gate","defense","explore","escort"]
 return String(kinds[(index*5+3)%kinds.size()])

func mission_total_sites(index: int) -> int:
 return 3 if mission_has_third_leg(index) else 2

func mission_leg_number() -> int:
 if mission_stage>=4: return mission_total_sites(active_mission)+1
 if mission_extra_active: return 3
 return 1 if mission_stage<2 else 2

func mission_total_steps() -> int:
 return 7 if mission_has_third_leg(active_mission) else 5

func mission_sector_for(index: int, stage: int) -> int:
 var first_sector: int=int(MISSIONS[index]["sector"])
 if stage<2 or stage>=4: return 0 if stage>=4 else first_sector
 if (index%5==0 or index%5==3) and not mission_has_third_leg(index): return first_sector
 var links: Array=SECTOR_LINKS[first_sector]
 return int(links[(index + 2)%links.size()])

func mission_position_for(index: int, stage: int) -> Vector3:
 var contract: Dictionary=MISSIONS[index]
 if stage>=4: return station_home_position
 if stage<2: return contract["goal"]
 var first_sector: int=int(contract["sector"])
 var destination: int=mission_sector_for(index,2)
 var original: Vector3=contract["second"]
 if destination==first_sector: return original
 # Preserve the original distinct local offset while moving the second site
 # to a physically separate star system. No randomization or teleporting.
 var offset: Vector3=original-SECTOR_ORIGINS[first_sector]
 return SECTOR_ORIGINS[destination]+offset

func mission_current_sector() -> int:
 if mission_stage>=6: return current_system
 if mission_extra_active and mission_stage>=2 and mission_stage<=3: return mission_third_sector(active_mission)
 return mission_sector_for(active_mission,mission_stage)

func mission_next_leg_label() -> String:
 if mission_stage>=6: return "SELECT A CONTRACT"
 var sector: int=mission_current_sector()
 if current_system!=sector: return "JUMP TO "+SYSTEM_NAMES[sector]
 if mission_stage>=4: return "RETURN TO GODS COMMAND / DOCK"
 return "LOCAL APPROACH / "+mission_objective_kind().to_upper() if mission_stage==1 or mission_stage==3 else "LOCAL APPROACH / NAV BEACON"

func mission_plot_next_leg() -> void:
 if nav_target==9 and is_instance_valid(living_galaxy) and not living_galaxy.state.goal.is_empty():
  living_galaxy.set_goal(int(living_galaxy.state.goal.sector),int(living_galaxy.state.goal.seed),str(living_galaxy.state.goal.title))
  return
 if mission_stage>=6:
  announce("SELECT A CONTRACT FROM MISSION DIRECTOR")
  return
 var sector: int=mission_current_sector()
 if sector==current_system:
  nav_target=0
  announce("MISSION WAYPOINT ACTIVE / "+SYSTEM_NAMES[sector])
  close_menu()
 else: plot_route(sector,true)

func mission_briefing(index: int) -> String:
 var m: Dictionary=MISSIONS[index]
 var first=str(m["first"])
 var second=str(m["final"])
 var detail={"combat":"Engage hostile craft and clear the approach corridor.","defense":"Hold the perimeter until defense control confirms the zone is secure.","escort":"Stay within 800 meters of the convoy while it crosses the corridor.","rescue":"Approach the damaged vessel and transfer survivors with F4.","salvage":"Recover components from the wreck using F4.","delivery":"Transfer sealed mission cargo at the destination using F4.","scan":"Begin a five-second telemetry scan with F4; stay within 450 meters.","gate":"Initiate a five-second ancient-gate survey with F4.","explore":"Remain near the target to chart the region."}
 var extra_text=""
 if mission_has_third_leg(index):
  extra_text="\nLEG THREE / "+SYSTEM_NAMES[mission_third_sector(index)]+": "+str(detail.get(mission_third_kind(index),"Investigate the final signal."))
 return "[b]COMMAND BRIEFING[/b]\nLEG ONE / "+SYSTEM_NAMES[int(m["sector"])]+": "+str(detail.get(first,"Follow the primary beacon."))+"\nLEG TWO / "+SYSTEM_NAMES[mission_sector_for(index,2)]+": "+str(detail.get(second,"Follow the secondary beacon."))+extra_text+"\nROUTE: "+("THREE-SITE EXPEDITION" if mission_has_third_leg(index) else ("CROSS-SECTOR EXPEDITION" if mission_sector_for(index,2)!=int(m["sector"]) else "LOCAL SECTOR OPERATION"))+"\nOPTIONAL SIGNALS: investigate with SHIFT+F6 for extra discoveries and mission bonuses."

func count_sector_missions(sector: int) -> int:
 var total=0
 for m in MISSIONS:
  if int(m["sector"])==sector: total+=1
 return total

func mission_objective_kind() -> String:
 if mission_stage==1: return String(MISSIONS[active_mission]["first"])
 if mission_stage==3: return mission_third_kind(active_mission) if mission_extra_active else String(MISSIONS[active_mission]["final"])
 return ""

func mission_objective_position() -> Vector3:
 if mission_extra_active and mission_stage>=2 and mission_stage<=3: return mission_third_position(active_mission)
 return mission_position_for(active_mission,mission_stage)

func mission_phase_label() -> String:
 match mission_stage:
  0: return "TRAVEL TO FIRST OBJECTIVE"
  1: return "COMPLETE FIRST OBJECTIVE: "+mission_objective_kind().to_upper()
  2: return "TRAVEL TO "+("THIRD" if mission_extra_active else "SECOND")+" OBJECTIVE"
  3: return "COMPLETE "+("THIRD" if mission_extra_active else "SECOND")+" OBJECTIVE: "+mission_objective_kind().to_upper()
  4: return "RETURN TO GODS COMMAND CENTER"
  5: return "DOCK AT GODS COMMAND TO CLAIM REWARD"
  _: return "NO ACTIVE OPERATION"

func mission_log(message: String) -> void:
 var stamp="[%s / %s] " % [SYSTEM_NAMES[current_system],"STEP "+str(mission_stage+1)]
 mission_journal.push_front(stamp+message)
 if mission_journal.size()>32: mission_journal.resize(32)

func mission_bonus_key() -> String:
 return "%d:%d%s" % [active_mission,mission_stage,":THIRD" if mission_extra_active else ""]

func mission_bonus_position() -> Vector3:
 var center: Vector3=mission_objective_position()
 var side=1.0 if (active_mission+mission_stage)%2==0 else -1.0
 return center+Vector3(side*(710.0+float(active_mission%3)*95.0),170.0,-560.0)

# Each objective has a nearby optional site, distinct from the main waypoint.
# Completion keys include the third-leg suffix to avoid collisions with leg two.
func encounter_key() -> String:
 return mission_bonus_key()+":ENCOUNTER"

func encounter_kind() -> String:
 var kinds=["GRAVITY RIFT","FLIGHT RECORDER","SURVIVOR POD","ANCIENT RELIC"]
 var site=0 if mission_stage<2 else (2 if mission_extra_active else 1)
 return String(kinds[(active_mission*7+site*3)%4])

func encounter_position() -> Vector3:
 var site=0 if mission_stage<2 else (2 if mission_extra_active else 1)
 var direction=1.0 if (active_mission+site)%2==0 else -1.0
 return mission_objective_position()+Vector3(direction*(1220.0+float(active_mission%4)*135.0),float((active_mission*73)%320)-130.0,850.0+float(site)*230.0)

func build_encounter_site() -> void:
 encounter_node=null
 if mission_stage!=1 and mission_stage!=3: return
 if encounter_done.has(encounter_key()): return
 if current_system!=mission_current_sector(): return
 var kind=encounter_kind()
 var node=Node3D.new()
 node.name="OPTIONAL_"+kind.replace(" ","_")
 node.position=encounter_position()
 add_child(node)
 mission_props.append(node)
 encounter_node=node
 var tint=Color(0.3,0.95,1.0)
 if kind=="GRAVITY RIFT":
  tint=Color(0.64,0.26,1.0)
  for j in range(3):
   var hoop=torus(node,Vector3.ZERO,80.0+j*42.0,91.0+j*42.0,tint,1.7)
   hoop.rotation=Vector3(0.5+j*0.45,j*0.6,0.4*j)
  ball(node,Vector3.ZERO,32.0,Color(0.2,0.05,0.43),1.8,16)
 elif kind=="FLIGHT RECORDER":
  tint=Color(1.0,0.7,0.22)
  var wreck=cube(node,Vector3.ZERO,Vector3(110,42,210),Color(0.23,0.33,0.42))
  wreck.rotation=Vector3(0.24,0.5,0.38)
  for j in range(4):
   var shard=cube(node,Vector3((j-2)*85,20-j*25,90+j*42),Vector3(34,15,85),Color(0.35,0.43,0.5))
   shard.rotation=Vector3(j*0.32,j*0.6,0.2)
  ball(node,Vector3(0,55,0),22,tint,1.9)
 elif kind=="SURVIVOR POD":
  tint=Color(0.22,1.0,0.58)
  var capsule=ball(node,Vector3.ZERO,76,Color(0.73,0.82,0.78),0.35,16)
  capsule.scale=Vector3(0.75,0.75,1.8)
  for j in range(3): ball(node,Vector3(-75+j*75,45,0),15,tint,1.8)
 else:
  tint=Color(1.0,0.37,0.72)
  tube(node,Vector3.ZERO,40,200,Color(0.23,0.22,0.4),0.5)
  for j in range(5):
   var a=float(j)*TAU/5.0
   var shard=tube(node,Vector3(cos(a)*125,-30,sin(a)*125),14,160,tint,1.7)
   shard.rotation.z=0.3*cos(a)
  var crown=torus(node,Vector3(0,130,0),105,119,tint,1.8)
  crown.rotation.x=0.7

func investigate_encounter() -> void:
 if mission_stage!=1 and mission_stage!=3:
  announce("ENCOUNTER UNAVAILABLE — ARRIVE AT AN ACTIVE MISSION SITE")
  return
 if current_system!=mission_current_sector():
  announce("ENCOUNTER IN ANOTHER SECTOR")
  return
 if encounter_done.has(encounter_key()):
  announce("ENCOUNTER ALREADY RESOLVED")
  return
 var dist=flight_pos.distance_to(encounter_position())
 if dist>350.0:
  announce("OPTIONAL SIGNAL %d M AWAY — APPROACH WITHIN 350 M" % int(dist))
  return
 if encounter_kind()=="GRAVITY RIFT":
  encounter_scan_active=true
  encounter_scan_progress=0.0
  announce("RIFT STABILIZER ENGAGED — HOLD POSITION FOR 8 SECONDS")
 else:
  finish_encounter()

func finish_encounter() -> void:
 if encounter_done.has(encounter_key()): return
 var kind=encounter_kind()
 encounter_done.append(encounter_key())
 encounter_scan_active=false
 encounter_scan_progress=0.0
 var bonus=500+active_mission*22
 if kind=="SURVIVOR POD":
  bonus+=300
  salvage_inventory["circuits"]=int(salvage_inventory.get("circuits",0))+1
 elif kind=="FLIGHT RECORDER":
  salvage_inventory["cores"]=int(salvage_inventory.get("cores",0))+1
 elif kind=="ANCIENT RELIC":
  bonus+=450
  salvage_inventory["cores"]=int(salvage_inventory.get("cores",0))+1
 else:
  bonus+=200
  salvage_inventory["alloys"]=int(salvage_inventory.get("alloys",0))+2
 mission_reward_bonus+=bonus
 var record=kind+" / "+SYSTEM_NAMES[current_system]+" / "+String(MISSIONS[active_mission]["name"])
 if not codex.has(record): codex.append(record)
 mission_log("Encounter resolved: "+kind+" (+%d CR)" % bonus)
 announce(kind+" RESOLVED — +%d BONUS CR / CODEX UPDATED" % bonus)
 rebuild_mission_props()
 save_game()

func update_mission_encounter(dt: float) -> void:
 if is_instance_valid(encounter_node):
  encounter_node.rotation.y+=dt*0.12
  if encounter_kind()=="GRAVITY RIFT":
   encounter_node.rotation.z=sin(world_time*0.55)*0.12
 if not encounter_scan_active: return
 if mission_stage!=1 and mission_stage!=3 or docked or current_system!=mission_current_sector() or encounter_done.has(encounter_key()):
  encounter_scan_active=false
  encounter_scan_progress=0.0
  return
 if flight_pos.distance_to(encounter_position())<=350.0:
  encounter_scan_progress=minf(8.0,encounter_scan_progress+dt)
  if encounter_scan_progress>=8.0: finish_encounter()
 else:
  encounter_scan_progress=maxf(0.0,encounter_scan_progress-dt*1.4)

func clear_mission_props() -> void:
 for node in mission_props:
  if is_instance_valid(node): node.queue_free()
 mission_props.clear()
 mission_escort=null
 mission_bonus_beacon=null
 encounter_node=null

func build_mission_prop(kind: String, pos: Vector3, stage_index: int) -> void:
 var prop=Node3D.new()
 prop.name="OPERATION_"+kind.to_upper()+"_"+str(stage_index)
 prop.position=pos
 add_child(prop)
 mission_props.append(prop)
 var cyan=Color(0.18,0.84,1.0)
 var amber=Color(1.0,0.68,0.23)
 var color=cyan if stage_index==0 else (Color(0.88,0.42,1.0) if stage_index==2 else amber)
 if kind=="salvage" or kind=="rescue":
  var hull=cube(prop,Vector3.ZERO,Vector3(170,48,360),Color(0.25,0.31,0.38))
  hull.rotation.z=0.32
  cube(prop,Vector3(-120,0,-45),Vector3(230,12,120),Color(0.38,0.46,0.52))
  cube(prop,Vector3(120,0,-45),Vector3(230,12,120),Color(0.38,0.46,0.52))
  for j in range(3): ball(prop,Vector3(-110+j*110,36,-70),18,color,1.6)
  if kind=="rescue":
   for j in range(3):
    var pod=ball(prop,Vector3(-150+j*150,-55,180),34,Color(0.92,0.92,0.75),0.6,12)
    pod.scale=Vector3(1.0,0.7,1.65)
 elif kind=="escort" or kind=="delivery":
  cube(prop,Vector3.ZERO,Vector3(140,65,300),Color(0.38,0.46,0.57))
  cube(prop,Vector3(-125,-12,20),Vector3(170,16,125),Color(0.21,0.39,0.51))
  cube(prop,Vector3(125,-12,20),Vector3(170,16,125),Color(0.21,0.39,0.51))
  for j in range(3): cube(prop,Vector3(-42+j*42,43,0),Vector3(35,28,90),color,0.55)
  if kind=="escort" and (mission_stage==1 or mission_stage==3):
   mission_escort=prop
 elif kind=="gate":
  var ring=torus(prop,Vector3.ZERO,150,180,color,1.7)
  ring.rotation.x=PI*0.5
  for j in range(8):
   var a=float(j)*TAU/8.0
   ball(prop,Vector3(cos(a)*165,sin(a)*165,0),19,color,1.9)
 elif kind=="combat" or kind=="defense":
  tube(prop,Vector3.ZERO,28,270,color,0.5)
  ball(prop,Vector3(0,155,0),65,color,0.65)
  for j in range(4):
   var a=float(j)*TAU/4.0
   cube(prop,Vector3(cos(a)*95,-100,sin(a)*95),Vector3(50,70,50),Color(0.28,0.34,0.43))
 else:
  var disk=torus(prop,Vector3.ZERO,95,108,color,1.0)
  disk.rotation.x=PI*0.5
  tube(prop,Vector3.ZERO,12,240,Color(0.30,0.48,0.57))
  ball(prop,Vector3(0,145,0),36,color,1.4)
 # PASS 24 / visual signatures: the site is a place, not only a waypoint.
 # Each family has a different recognizable silhouette and color language.
 var family: int=(active_mission+stage_index*3)%6
 if family==0: # shattered ancient orbital rings
  for r in range(3):
   var arc=torus(prop,Vector3((r-1)*155,30,-170),105.0+r*22.0,115.0+r*22.0,Color(0.58,0.24,0.92),1.2)
   arc.rotation=Vector3(0.42+r*0.24,0.35*r,0.2)
 elif family==1: # rescue debris and beacon array
  for r in range(5):
   var shard=cube(prop,Vector3((r-2)*115,(-1 if r%2==0 else 1)*95,-150-r*50),Vector3(34+r*8,22,95),Color(0.30,0.42,0.51))
   shard.rotation=Vector3(r*0.21,r*0.53,r*0.16)
 elif family==2: # ion pylons
  for r in range(4):
   var a=float(r)*TAU/4.0
   var place=Vector3(cos(a)*220,0,sin(a)*220)
   tube(prop,place,14.0,210.0,Color(0.15,0.75,0.93),1.1)
   ball(prop,place+Vector3(0,115,0),22,Color(0.35,0.90,1.0),2.0)
 elif family==3: # lost navigation observatory
  var halo=torus(prop,Vector3(0,175,-130),175.0,183.0,Color(0.94,0.61,0.19),1.4)
  halo.rotation.x=0.65
  for r in range(3): ball(prop,Vector3((r-1)*130,-70,-240),36,Color(0.89,0.44,0.14),0.8)
 elif family==4: # bio-luminescent crystal growth
  for r in range(5):
   var spike=tube(prop,Vector3((r-2)*100,-40,-180+(r%2)*95),22,110+r*35,Color(0.19,0.85,0.62),1.4)
   spike.rotation.z=0.2*(r-2)
 else: # citadel field barrier
  for r in range(3):
   var shield_ring=torus(prop,Vector3(0,0,-160-r*75),145.0-r*24,155.0-r*24,Color(0.91,0.30,0.42),1.2)
   shield_ring.rotation.x=0.6

func rebuild_mission_props() -> void:
 clear_mission_props()
 if mission_stage>=4 or current_system!=mission_current_sector(): return
 var m: Dictionary=MISSIONS[active_mission]
 var index: int=0 if mission_stage<2 else (2 if mission_extra_active else 1)
 var kind: String=mission_objective_kind() if mission_stage==1 or mission_stage==3 else (String(m["first"]) if index==0 else (mission_third_kind(active_mission) if mission_extra_active else String(m["final"])))
 build_mission_prop(kind,mission_objective_position(),index)
 if mission_stage==1 or mission_stage==3:
  var key=mission_bonus_key()
  if not mission_bonus_done.has(key):
   mission_bonus_beacon=Node3D.new()
   mission_bonus_beacon.name="OPTIONAL_BONUS_CACHE"
   mission_bonus_beacon.position=mission_bonus_position()
   add_child(mission_bonus_beacon)
   mission_props.append(mission_bonus_beacon)
   var gold=Color(1.0,0.72,0.25)
   var marker=torus(mission_bonus_beacon,Vector3.ZERO,80,92,gold,1.4)
   marker.rotation.x=PI*0.5
   ball(mission_bonus_beacon,Vector3.ZERO,25,gold,1.8)
 build_encounter_site()

func collect_mission_bonus() -> void:
 if mission_stage!=1 and mission_stage!=3: announce("BONUS CACHE NOT ACTIVE — REACH A MISSION OBJECTIVE");return
 if current_system!=mission_current_sector(): announce("BONUS CACHE IN ANOTHER SECTOR");return
 if mission_bonus_done.has(mission_bonus_key()): announce("BONUS CACHE ALREADY RECOVERED");return
 var distance=flight_pos.distance_to(mission_bonus_position())
 if distance>300.0: announce("BONUS CACHE %d M AWAY — CLOSE TO 300 M" % int(distance));return
 mission_bonus_done.append(mission_bonus_key())
 var bonus=350+active_mission*24
 mission_reward_bonus+=bonus
 mission_bonus_value+=bonus
 salvage_inventory["circuits"]=int(salvage_inventory["circuits"])+1
 mission_log("Recovered optional telemetry cache (+%d CR, +1 circuit)" % bonus)
 announce("OPTIONAL CACHE SECURED — +%d MISSION BONUS" % bonus)
 rebuild_mission_props()
 save_game()

func retry_mission_objective() -> void:
 if mission_stage!=1 and mission_stage!=3: announce("RETRY AVAILABLE ONLY DURING A LIVE OBJECTIVE");return
 escort_progress=0.0
 escort_integrity=100.0
 mission_escort_failed=false
 mission_scan_active=false
 mission_scan_charge=0.0
 escort_damage_clock=0.0
 mission_current_retries+=1
 mission_elapsed=0.0
 mission_phase_kills=0
 mission_event_spawned=false
 mission_retries+=1
 if mission_objective_kind()=="combat" or mission_objective_kind()=="defense" or mission_objective_kind()=="escort": spawn_enemies()
 rebuild_mission_props()
 mission_log("Objective reset by pilot")
 announce("OBJECTIVE RESTARTED — MISSION PROGRESS PRESERVED")
 save_game()

func update_mission_props(dt: float) -> void:
 for node in mission_props:
  if not is_instance_valid(node): continue
  if node==mission_escort or node==mission_bonus_beacon: continue
  node.rotation.y+=dt*0.045
 if is_instance_valid(mission_bonus_beacon):
  mission_bonus_beacon.rotation.y+=dt*0.4
 if is_instance_valid(mission_escort) and mission_objective_kind()=="escort":
  var start: Vector3=mission_objective_position()
  var end=start+Vector3(0,0,-1100)
  mission_escort.position=start.lerp(end,escort_progress)
  mission_escort.rotation.y=sin(world_time*0.4)*0.06

func clear_mission_beacons() -> void:
 for beacon in mission_beacons:
  if is_instance_valid(beacon): beacon.queue_free()
 mission_beacons.clear()

func create_mission_beacons() -> void:
 clear_mission_beacons()
 clear_mission_props()
 if mission_stage>=4 or current_system!=mission_current_sector(): return
 for index in range(3):
  if index!=(0 if mission_stage<2 else (2 if mission_extra_active else 1)): continue
  var position: Vector3=mission_objective_position()
  var node=Node3D.new()
  node.position=position
  node.name="MISSION_OBJECTIVE_"+str(index+1)
  add_child(node)
  var hue=Color(0.18,0.94,1.0) if index==0 else (Color(0.88,0.39,1.0) if index==2 else Color(1.0,0.71,0.23))
  var ring=torus(node,Vector3.ZERO,105.0,113.0,hue,1.7)
  ring.rotation.x=PI*0.5
  ball(node,Vector3.ZERO,17.0,hue,2.2,14)
  tube(node,Vector3(0,105,0),5.0,170.0,hue,1.2)
  mission_beacons.append(node)
 rebuild_mission_props()

func update_mission_beacons(dt: float) -> void:
 for i in range(mission_beacons.size()):
  var node=mission_beacons[i]
  if not is_instance_valid(node): continue
  var selected=node.name=="MISSION_OBJECTIVE_"+str(1 if mission_stage<2 else (3 if mission_extra_active else 2))
  node.visible=mission_stage<4 and selected and current_system==mission_current_sector()
  if node.visible:
   node.rotation.y+=dt*0.32
   node.scale=Vector3.ONE*(1.0+sin(world_time*2.5)*0.07)

func advance_mission_phase() -> void:
 var old_kind=mission_objective_kind()
 mission_stage+=1
 # Stage 4 normally means return home. For long operations it becomes
 # a new travel/action pair at a third physical location instead.
 if mission_stage==4 and mission_has_third_leg(active_mission) and not mission_extra_done:
  if mission_extra_active:
   mission_extra_done=true
   mission_extra_active=false
   mission_extra_total+=1
   var third_bonus=850+active_mission*45
   mission_reward_bonus+=third_bonus
   salvage_inventory["circuits"]=int(salvage_inventory["circuits"])+2
   var discovery="THIRD LEG: "+String(MISSIONS[active_mission]["name"])
   if not codex.has(discovery): codex.append(discovery)
   mission_log("Deep-space third objective secured (+%d CR, +2 circuits)" % third_bonus)
  else:
   mission_stage=2
   mission_extra_active=true
 if old_kind=="combat" or old_kind=="defense" or old_kind=="escort":
  for enemy in enemies:
   if is_instance_valid(enemy): enemy.queue_free()
  enemies.clear()
 mission_elapsed=0.0
 mission_phase_kills=0
 mission_action_ready=false
 mission_event_spawned=false
 encounter_scan_active=false
 encounter_scan_progress=0.0
 escort_progress=0.0
 escort_integrity=100.0
 mission_escort_failed=false
 mission_scan_active=false
 mission_scan_charge=0.0
 rebuild_mission_props()
 mission_log("Phase completed — "+mission_phase_label())
 if mission_stage==2:
  announce(("SECOND SITE SECURED — THIRD LEG: " if mission_extra_active else "FIRST SITE SECURED — SECOND LEG: ")+SYSTEM_NAMES[mission_current_sector()])
  if current_system!=mission_current_sector():
   clear_mission_beacons()
   clear_mission_props()
   plot_route(mission_current_sector(),false)
  else: create_mission_beacons()
 elif mission_stage==4:
  clear_mission_beacons()
  announce("OPERATION OBJECTIVES COMPLETE — RETURN TO GODS COMMAND")
  if current_system!=0: plot_route(0,false)
 elif mission_stage==5: announce("MISSION READY FOR HAND-IN — DOCK AT GODS COMMAND")
 else:
  create_mission_beacons()
  announce(mission_phase_label())
 save_game()

func interact_mission() -> void:
 if mission_stage!=1 and mission_stage!=3: announce("NO INTERACTIVE OBJECTIVE — FOLLOW MISSION NAV");return
 if current_system!=mission_current_sector(): announce("WRONG SECTOR — FOLLOW GALAXY ROUTE");return
 var d=flight_pos.distance_to(mission_objective_position())
 if d>500.0: announce("MOVE WITHIN 500 M OF THE OBJECTIVE / %d M REMAINING" % int(d));return
 var kind=mission_objective_kind()
 if kind=="combat" or kind=="defense" or kind=="escort": announce("COMPLETE THE LIVE OBJECTIVE — %s" % kind.to_upper());return
 if kind=="scan" or kind=="gate":
  if mission_scan_active: announce("SCANNER ALREADY RUNNING — MAINTAIN 450 M PROXIMITY")
  else:
   mission_scan_active=true
   mission_scan_charge=0.0
   mission_log("Telemetry scan initiated — hold near the target for 5 seconds")
   announce("SCANNER ONLINE — REMAIN WITHIN 450 M FOR 5 SECONDS")
  return
 if kind=="delivery":
  if cargo_units<=0: announce("NO MISSION CARGO ON BOARD — RETURN TO GODS COMMAND");return
  cargo_units-=1
  announce("CARGO DELIVERED — %d CONTAINERS REMAIN" % cargo_units)
 if kind=="salvage":
  salvage_inventory["alloys"]=int(salvage_inventory["alloys"])+2
  salvage_inventory["circuits"]=int(salvage_inventory["circuits"])+1
  announce("SALVAGE RECOVERED — ALLOYS +2 / CIRCUITS +1")
 elif kind=="rescue": announce("SURVIVORS TRANSFERRED TO LIFE SUPPORT")
 elif kind=="gate":
  var discovery="ANCIENT GATE: "+String(MISSIONS[active_mission]["name"])
  if not codex.has(discovery): codex.append(discovery)
  announce("GATE TELEMETRY RECORDED IN DISCOVERY CODEX")
 elif kind=="scan" or kind=="explore":
  var discovery="MISSION SURVEY: "+String(MISSIONS[active_mission]["name"])
  if not codex.has(discovery): codex.append(discovery)
  announce("MISSION TELEMETRY CAPTURED")
 else: announce("OBJECTIVE INTERACTION COMPLETE")
 advance_mission_phase()

func update_mission(dt: float) -> void:
 if mission_stage>=6 or docked or jump_timer>0.0 or landing_timer>0.0: return
 if mission_scan_active:
  var kind_now=mission_objective_kind()
  if (mission_stage!=1 and mission_stage!=3) or (kind_now!="scan" and kind_now!="gate"):
   mission_scan_active=false
   mission_scan_charge=0.0
  elif current_system==mission_current_sector():
   if flight_pos.distance_to(mission_objective_position())<=450.0:
    mission_scan_charge=minf(5.0,mission_scan_charge+dt)
    if mission_scan_charge>=5.0:
     mission_scan_active=false
     var finding=("ANCIENT GATE: " if kind_now=="gate" else "MISSION SURVEY: ")+String(MISSIONS[active_mission]["name"])
     if not codex.has(finding): codex.append(finding)
     mission_log("Full telemetry scan complete — "+finding)
     announce("TELEMETRY SCAN COMPLETE — CODEX UPDATED")
     advance_mission_phase()
     return
   else:
    mission_scan_charge=maxf(0.0,mission_scan_charge-dt*0.8)
 if mission_stage==4 or mission_stage==5:
  if current_system==0 and dock_range()<1600.0 and mission_stage==4: advance_mission_phase()
  return
 if current_system!=mission_current_sector(): return
 var d=flight_pos.distance_to(mission_objective_position())
 if mission_stage==0 or mission_stage==2:
  if d<750.0:
   advance_mission_phase()
   var kind=mission_objective_kind()
   if kind=="combat" or kind=="defense" or kind=="escort": spawn_enemies();mission_event_spawned=true
   mission_log("Arrived at live objective: "+kind.to_upper())
   announce("MISSION ZONE REACHED — "+kind.to_upper()+" / F4 TO INTERACT")
  return
 if d>1400.0: return
 var kind=mission_objective_kind()
 if kind=="combat":
  if mission_phase_kills>=2: advance_mission_phase()
 elif kind=="defense":
  if not mission_event_spawned: spawn_enemies();mission_event_spawned=true
  mission_elapsed+=dt
  if mission_elapsed>=24.0 and mission_phase_kills>=1: advance_mission_phase()
 elif kind=="escort":
  if mission_escort_failed: return
  var convoy_pos=mission_objective_position()+Vector3(0,0,-1100.0*escort_progress)
  var range_to_convoy=flight_pos.distance_to(convoy_pos)
  if range_to_convoy<800.0 and escort_integrity>0.1:
   mission_elapsed+=dt
   escort_progress=minf(1.0,escort_progress+dt/28.0)
  escort_damage_clock+=dt
  if escort_damage_clock>=3.5:
   escort_damage_clock=0.0
   var nearby=0
   for e in enemies:
    if is_instance_valid(e) and e.position.distance_to(convoy_pos)<1500.0: nearby+=1
   if nearby>0: escort_integrity=maxf(0.0,escort_integrity-float(nearby)*6.0)
  if escort_integrity<=0.0:
   mission_escort_failed=true
   mission_fails+=1
   mission_log("Convoy disabled — retry from Mission Director to resume")
   escort_integrity=0.0
   announce("CONVOY DISABLED — OPEN M / ACTIVE OPERATION / RETRY")
  elif escort_progress>=1.0:
   mission_reward_bonus+=int(escort_integrity)*8
   mission_log("Convoy arrived with %d%% integrity" % int(escort_integrity))
   announce("CONVOY ARRIVED — HULL %d%% / SURVIVAL BONUS" % int(escort_integrity))
   advance_mission_phase()
 elif kind=="explore":
  if d<350.0: mission_elapsed+=dt
  if mission_elapsed>=6.0: announce("UNMAPPED TERRAIN CHARTED");advance_mission_phase()
 # scan, rescue, salvage, delivery and gate require deliberate F4 interaction.

func accept_mission(i: int) -> void:
 if is_instance_valid(living_galaxy) and not living_galaxy.state.arc.is_empty() and not ["complete","abandoned"].has(str(living_galaxy.state.arc.stage)):
  announce("Finish or abandon the active expedition before starting a fleet operation.")
  return
 if is_instance_valid(living_galaxy) and not living_galaxy.state.hunt.is_empty() and not ["claimed","abandoned"].has(str(living_galaxy.state.hunt.stage)):
  announce("Finish or abandon the active warrant before accepting a fleet operation.")
  return
 if mission_stage<6:
  announce("FINISH OR ABANDON THE ACTIVE OPERATION FIRST")
  return
 active_mission=clampi(i,0,MISSIONS.size()-1)
 bounty_active=false
 mission_stage=0
 mission_kills=0
 mission_phase_kills=0
 mission_elapsed=0.0
 mission_event_spawned=false
 mission_reward_bonus=0
 mission_extra_active=false
 mission_extra_done=false
 encounter_scan_active=false
 encounter_scan_progress=0.0
 cargo_units=3 if String(MISSIONS[active_mission]["type"])=="delivery" else 0
 mission_bonus_value=0
 for bonus_i in range(mission_bonus_done.size()-1,-1,-1):
  if mission_bonus_done[bonus_i].begins_with(str(active_mission)+":"): mission_bonus_done.remove_at(bonus_i)
 mission_scan_charge=0.0
 mission_scan_active=false
 mission_escort_failed=false
 mission_current_damage=0.0
 mission_current_start_hull=hull_hp
 mission_current_retries=0
 escort_progress=0.0
 escort_integrity=100.0
 mission_log("Accepted operation: "+String(MISSIONS[active_mission]["name"]))
 if not docked: announce("REMOTE OPERATIONS UPLINK ACCEPTED")
 spawn_enemies()
 create_mission_beacons()
 close_menu()
 announce("OPERATION ACCEPTED: "+String(MISSIONS[active_mission]["name"]))
 nav_target=0
 var ms: int=int(MISSIONS[active_mission]["sector"])
 if current_system!=ms: plot_route(ms,false)
 save_game()

func abandon_mission() -> void:
 if mission_stage>=6: return
 mission_scan_active=false
 mission_escort_failed=false
 mission_stage=6
 mission_extra_active=false
 mission_extra_done=false
 encounter_scan_active=false
 encounter_scan_progress=0.0
 mission_kills=0
 mission_phase_kills=0
 mission_elapsed=0.0
 cargo_units=0
 clear_mission_beacons()
 clear_mission_props()
 mission_log("Operation abandoned")
 spawn_enemies()
 announce("OPERATION ABANDONED — SELECT ANOTHER CONTRACT")
 save_game()
 show_menu("missions")

func upgrade_ship(kind: String) -> void:
 if not docked: announce("SHIPWORKS REQUIRES A STATION BERTH");return
 if not upgrades.has(kind): return
 var level = int(upgrades[kind])
 if level>=5: announce("MODULE ALREADY AT MK V");return
 var cost = 900*level*level
 if credits<cost: announce("INSUFFICIENT CREDITS — NEED %d"%cost);return
 credits-=cost
 upgrades[kind]=level+1
 hull_hp=minf(hull_hp,max_hull())
 shield_hp=minf(shield_hp,max_shield())
 announce(kind.to_upper()+" UPGRADED TO MK "+str(level+1))
 save_game()
 show_menu("shipyard_legacy")

# PASS 9 - Exploration codex, anomaly contacts and ancient gate transition.
func update_exploration(dt: float) -> void:
 event_timer+=dt
 if event_timer>110.0:
  event_timer=0.0
  var possibilities = ["UNCLASSIFIED SIGNAL","ION TEMPEST","GRAVITY SCAR","CRYSTAL FIELD","ANCIENT TRANSMISSION"]
  var name = possibilities[rng.randi_range(0,possibilities.size()-1)]
  var offset = Vector3(rng.randf_range(-8000,8000),rng.randf_range(-1600,1600),rng.randf_range(-11000,-4500))
  contacts.append({"name":name,"position":flight_pos+offset,"found":false})
  if contacts.size()>10: contacts.pop_front()
  announce("DEEP SCAN: UNCLASSIFIED CONTACT DETECTED")
 for c in contacts:
  if not bool(c["found"]) and flight_pos.distance_to(c["position"])<280.0:
   c["found"]=true
   var name = String(c["name"])
   if not codex.has(name): codex.append(name)
   credits+=750
   announce("DISCOVERY LOGGED: "+name+" / +750 CR")
   save_game()
 if gate_active and current_system==6 and flight_pos.distance_to(gate.position)<200.0:
  gate_active=false
  current_system=3
  jump_target=3
  flight_pos=SECTOR_ORIGINS[3]+Vector3(0,0,700)
  setup_sector(3)
  route_legs.clear()
  route_destination=-1
  bounty_active=false
  spawn_enemies()
  if not codex.has("SPACE GODS GATE"): codex.append("SPACE GODS GATE")
  announce("GATE TRANSIT COMPLETE — THE PALE REACH")
  save_game()

# PASS 13B — Weapon, shield, wingman and bounty controls.
func cycle_weapon() -> void:
 weapon_mode=(weapon_mode+1)%WEAPON_NAMES.size()
 announce("WEAPON BANK: "+WEAPON_NAMES[weapon_mode])

func toggle_tractor() -> void:
 tractor_active=not tractor_active
 announce("TRACTOR BEAM " + ("ONLINE" if tractor_active else "OFFLINE"))
 show_menu("tactics")

func cycle_power() -> void:
 shield_power=(shield_power+1)%3
 announce("POWER DISTRIBUTION: "+["WEAPONS / COOLING","BALANCED","SHIELDS / REGEN"][shield_power])

func toggle_wingman() -> void:
 if docked:
  announce("LAUNCH BEFORE DEPLOYING THE WINGMAN")
  return
 if wingman_hp<=0.0:
  announce("WINGMAN DISABLED — REPAIR AT TACTICAL ARMORY")
  return
 wingman_active=not wingman_active
 if wingman_active and is_instance_valid(wingman): wingman.position=flight_pos+Vector3(50,15,40)
 if wingman_active and not is_instance_valid(wingman):
  wingman=Node3D.new()
  wingman.name="Aegis_Wingman"
  add_child(wingman)
  triangle_mesh(wingman,PackedVector3Array([Vector3(0,0,-12),Vector3(-12,0,7),Vector3(0,3,4),Vector3(0,0,-12),Vector3(0,3,4),Vector3(12,0,7),Vector3(-12,0,7),Vector3(12,0,7),Vector3(0,-2,4)]),Color(0.15,0.58,0.72))
  ball(wingman,Vector3(0,0,6),3.0,Color(0.15,0.85,1.0),2.0,10)
 if is_instance_valid(wingman): wingman.visible=wingman_active
 announce("AEGIS WINGMAN " + ("DEPLOYED" if wingman_active else "RECALLED"))

func update_wingman(dt: float) -> void:
 if wingman_active and is_instance_valid(wingman) and wingman.position.distance_to(flight_pos)>3500.0:
  wingman.position=formation_anchor(1.0)
 if not wingman_active or docked or jump_timer>0.0 or not is_instance_valid(wingman): return
 var anchor=formation_anchor(1.0)
 if fleet_order==3: anchor=fleet_anchor+Vector3(55,0,0)
 wingman.position=wingman.position.lerp(anchor,minf(1.0,dt*2.6))
 wingman.rotation=player.rotation
 if fleet_order==3 or enemies.is_empty() or wingman_cooldown>0.0: return
 var closest: Node3D=null
 var best=2200.0 if fleet_order==1 else 1700.0
 if fleet_order==1 and target_index>=0 and target_index<enemies.size(): closest=enemies[target_index]
 for e in enemies:
  if not is_instance_valid(e): continue
  var distance=e.position.distance_to(wingman.position)
  if closest==null and distance<best: best=distance;closest=e
 if fleet_focus_time>0.0 and is_instance_valid(fleet_focus_target): closest=fleet_focus_target
 if closest==null or not fleet_can_fire(closest): return
 wingman_cooldown=1.3
 spawn_impact(closest.position,Color(0.15,0.95,1.0),10.0)
 hit_enemy(closest,16.0,0)

func launch_bounty_round() -> void:
 if is_instance_valid(living_galaxy) and not living_galaxy.state.arc.is_empty() and not ["complete","abandoned"].has(str(living_galaxy.state.arc.stage)):
  announce("Finish or abandon the active expedition before starting an arena wave.")
  return
 if is_instance_valid(living_galaxy) and not living_galaxy.state.hunt.is_empty() and not ["claimed","abandoned"].has(str(living_galaxy.state.hunt.stage)):
  announce("Finish the named warrant before starting an arena wave.")
  return
 if docked: announce("LAUNCH BEFORE STARTING A BOUNTY WAVE");return
 if bounty_active and not enemies.is_empty(): announce("CLEAR CURRENT BOUNTY WAVE FIRST");return
 bounty_round+=1
 bounty_active=true
 bounty_timer=0.0
 spawn_enemies()
 var anchor=flight_pos-player.global_transform.basis.z*1250.0
 for i in range(enemies.size()):
  var e=enemies[i]
  e.position=anchor+Vector3((float(i%3)-1.0)*260.0,float(i/3)*145.0,-float(i/3)*320.0)
  e.set_meta("hp",float(e.get_meta("hp"))*(1.0+float(bounty_round-1)*0.12))
  e.set_meta("max_hp",float(e.get_meta("hp")))
 announce("BOUNTY WAVE "+str(bounty_round)+" — HOSTILES INBOUND")
 close_menu()

func update_bounty(_dt: float) -> void:
 if not bounty_active or not enemies.is_empty() or docked or jump_timer>0.0: return
 bounty_active=false
 combat_bounties_completed+=1
 var prize=1400+bounty_round*850
 credits+=prize
 announce("BOUNTY WAVE CLEARED — +"+str(prize)+" CR / OPEN TACTICAL MENU FOR NEXT WAVE")
 save_game()

func repair_wingman() -> void:
 if not docked: announce("WINGMAN REPAIR REQUIRES DOCKING");return
 var cost=int(ceilf(100.0-wingman_hp))*12
 if credits<cost: announce("INSUFFICIENT CREDITS FOR WINGMAN REPAIR");return
 credits-=cost
 wingman_hp=100.0
 announce("AEGIS WINGMAN REFITTED")
 save_game()
 show_menu("armory")

# PASS 10 - Compact menu/HUD, autosave, state restoration and diagnostics.

# THREE HUD PASSES — flight instruments, tactical radar, mission/command console.
var cockpit_hud
func install_cockpit_hud() -> void:
 if is_instance_valid(ui_left_panel): ui_left_panel.hide()
 if is_instance_valid(ui_nav_panel): ui_nav_panel.hide()
 if is_instance_valid(ui_docking_panel): ui_docking_panel.hide()
 if is_instance_valid(ui_help_strip): ui_help_strip.hide()
 if is_instance_valid(reticle): reticle.hide()
 cockpit_hud = preload("res://scripts/hud_command.gd").new()
 add_child(cockpit_hud)
 cockpit_hud.initialize(self)

func create_ui() -> void:
 ui_layer=CanvasLayer.new()
 add_child(ui_layer)
 var left=PanelContainer.new()
 left.position=Vector2(14,14)
 left.custom_minimum_size=Vector2(340,0)
 ui_layer.add_child(left)
 ui_left_panel=left
 var left_col=VBoxContainer.new()
 left.add_child(left_col)
 var title=Label.new()
 title.text="SPACE GODS  //  FLEET COMMAND"
 left_col.add_child(title)
 hud=Label.new()
 left_col.add_child(hud)
 mission_hud=Label.new()
 left_col.add_child(mission_hud)
 p34_lead_label=Label.new()
 p34_lead_label.text="◇ LEAD"
 p34_lead_label.add_theme_color_override("font_color",Color(1.0,0.82,0.30))
 p34_lead_label.add_theme_font_size_override("font_size",19)
 p34_lead_label.mouse_filter=Control.MOUSE_FILTER_IGNORE
 ui_layer.add_child(p34_lead_label)
 p34_lead_label.hide()
 p34_speed_label=Label.new()
 p34_speed_label.add_theme_color_override("font_color",Color(0.28,0.94,1.0))
 left_col.add_child(p34_speed_label)
 target_readout=Label.new()
 target_readout.add_theme_color_override("font_color",Color(1.0,0.68,0.48))
 left_col.add_child(target_readout)
 combat_readout=Label.new()
 combat_readout.add_theme_color_override("font_color",Color(0.47,0.95,0.78))
 left_col.add_child(combat_readout)
 tactical_panel=Label.new()
 tactical_panel.add_theme_color_override("font_color",Color(0.80,0.89,1.0))
 tactical_panel.add_theme_font_size_override("font_size",12)
 left_col.add_child(tactical_panel)
 nav_label=Label.new()
 nav_label.position=Vector2(15,425)
 nav_label.add_theme_font_size_override("font_size",13)
 nav_label.add_theme_color_override("font_color",Color(0.55,0.94,1.0))
 ui_layer.add_child(nav_label)
 ui_nav_panel=nav_label
 jump_label=Label.new()
 jump_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
 jump_label.position+=Vector2(-175,-100)
 jump_label.add_theme_font_size_override("font_size",26)
 jump_label.add_theme_color_override("font_color",Color(0.54,0.87,1.0))
 ui_layer.add_child(jump_label)
 reticle=Label.new()
 reticle.text="+"
 reticle.add_theme_font_size_override("font_size",27)
 reticle.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
 ui_layer.add_child(reticle)
 docking_label=Label.new()
 docking_label.position=Vector2(14,392)
 docking_label.add_theme_color_override("font_color",Color(0.72,0.95,1.0))
 ui_layer.add_child(docking_label)
 ui_docking_panel=docking_label
 alert_label=Label.new()
 alert_label.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
 alert_label.offset_left=18.0
 alert_label.offset_top=-88.0
 alert_label.offset_right=760.0
 alert_label.offset_bottom=-58.0
 alert_label.add_theme_color_override("font_color",Color(1,.79,.48))
 ui_layer.add_child(alert_label)
 var controls=Label.new()
 controls.text="SUPPORT: SHIFT+F4  |  MISSIONS: M BOARD · F4 INTERACT · F6 BONUS · G ROUTE  |  FLIGHT: LEFT STEER · RIGHT ROLL · SHIFT/CTRL SPEED · F FIRE · Z WEAPON · K MISSILE · L FLARES · TAB TARGET · I TACTICS · F1 HELP · SHIFT+F1 DIAG · SHIFT+F2 HUD · SHIFT+F3 FPS"
 controls.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
 controls.offset_left=18.0
 controls.offset_top=-34.0
 controls.offset_right=1200.0
 controls.offset_bottom=-9.0
 controls.add_theme_font_size_override("font_size",11)
 ui_layer.add_child(controls)
 ui_help_strip=controls
 diagnostics_label=Label.new()
 diagnostics_label.position=Vector2(16,535)
 diagnostics_label.add_theme_color_override("font_color",Color(0.60,1.0,0.68))
 diagnostics_label.add_theme_font_size_override("font_size",12)
 diagnostics_label.visible=false
 ui_layer.add_child(diagnostics_label)
 menu=PanelContainer.new()
 menu.set_anchors_preset(Control.PRESET_TOP_RIGHT)
 menu.offset_left=-550.0
 menu.offset_top=60.0
 menu.offset_right=-16.0
 menu.offset_bottom=470.0
 menu.custom_minimum_size=Vector2(0,0)
 ui_layer.add_child(menu)
 var column=VBoxContainer.new()
 menu.add_child(column)
 menu_title=Label.new()
 menu_title.add_theme_font_size_override("font_size",22)
 column.add_child(menu_title)
 menu_text=RichTextLabel.new()
 menu_text.custom_minimum_size=Vector2(0,135)
 menu_text.bbcode_enabled=true
 column.add_child(menu_text)
 var sc=ScrollContainer.new()
 sc.custom_minimum_size=Vector2(0,150)
 column.add_child(sc)
 menu_actions=VBoxContainer.new()
 sc.add_child(menu_actions)
 menu.visible=false
func add_action(label: String, action: Callable) -> void:
 var b=Button.new()
 b.text=label
 b.pressed.connect(action)
 menu_actions.add_child(b)
func show_menu(which: String) -> void:
 if which.begins_with("starport_") and is_instance_valid(pass50_starport):
  pass50_starport.show(which.trim_prefix("starport_"))
  return
 if which.begins_with("nexus_") and is_instance_valid(command_nexus):
  command_nexus.show(which.trim_prefix("nexus_"))
  return
 if which=="living":
  living_galaxy.show("hub")
  return
 menu_open=true
 menu.visible=true
 for child in menu_actions.get_children():
  menu_actions.remove_child(child)
  child.queue_free()
 menu_title.text=which.to_upper()
 menu_text.text=""
 match which:
  "missions":
   add_action("STARPORT / CONTRACT DISPATCH",show_menu.bind("starport_dispatch"))
   add_action("SHIP COMPUTER / CONNECTED COMMAND NEXUS",show_menu.bind("nexus_home"))
   add_action("LIVING GALAXY / WARRANTS & EXPEDITIONS",living_galaxy.show.bind("hub"))
   menu_text.text="[b]MISSION DIRECTOR / 40 OPERATIONS[/b]\nCleared %d/40  |  Completed contracts %d\n%s\n\nChoose local sorties, cross-sector contracts, or THREE-SITE expeditions. Each site has its own location and task. Plot NEXT LEG after each objective; return to Gods Command for payment." % [mission_completed.size(),mission_successes,mission_phase_label()]
   if mission_stage<6:
    add_action("ACTIVE: "+String(MISSIONS[active_mission]["name"]),show_menu.bind("mission_active"))
    add_action("ABANDON CURRENT OPERATION",abandon_mission)
   add_action("CAPTAIN'S MISSION JOURNAL",show_menu.bind("mission_journal"))
   for i in range(SYSTEM_NAMES.size()):
    add_action(SYSTEM_NAMES[i]+" / "+str(count_sector_missions(i))+" OPERATIONS",show_menu.bind("mission_sector_"+str(i)))
   add_action("RETURN TO STATION",show_menu.bind("station") if docked else close_menu)
  "mission_active":
   var active=MISSIONS[active_mission]
   menu_text.text="[b]%s[/b]\nNEXT: %s\n%s\nReward: %d CR + bonuses\nFirst: %s\nSecond: %s\n\nMission sites have physical wrecks, relays, gates or convoys. F4 interacts; F6 collects an optional cache at each live objective. Escorts must be flown alongside; damage reduces survival rewards." % [active["name"],mission_next_leg_label(),mission_phase_label(),int(active["reward"]),String(active["first"]).to_upper(),String(active["final"]).to_upper()]
   if mission_stage<6:
    add_action("RETRY CURRENT LIVE OBJECTIVE",retry_mission_objective)
    add_action("CAPTAIN'S MISSION JOURNAL",show_menu.bind("mission_journal"))
    add_action("PLOT ROUTE TO CURRENT OBJECTIVE",mission_plot_next_leg)
    add_action("ABANDON OPERATION",abandon_mission)
   add_action("BACK TO MISSION BOARD",show_menu.bind("missions"))
  "mission_journal":
   menu_text.text="[b]CAPTAIN'S OPERATION LOG[/b]\nUnique operations: %d/40 | Completed: %d | Retries: %d\nConvoy incidents: %d | Optional caches: %d CR\nLast result: %s\nGrades: %s\n\n%s" % [mission_completed.size(),mission_successes,mission_retries,mission_fails,mission_bonus_value,mission_last_result,str(mission_best_grades),"\n".join(PackedStringArray(mission_journal.slice(0,14)))]
   if mission_stage<6: add_action("ACTIVE OPERATION DETAILS",show_menu.bind("mission_active"))
   add_action("BACK TO MISSION DIRECTOR",show_menu.bind("missions"))
  "shipyard":
   menu_text.text="[b]GODS SHIPWORKS / HULL EXCHANGE[/b]\nCURRENT: %s  |  CREDITS: %d\nOwned hulls: %d/5\nHULL %d  SHIELD %d  SPEED %.0f%%  CARGO %d\n\nPurchase hulls and transfer into them while docked. Each hull has different flight handling, armor, shields and geometry." % [SHIP_NAMES[ship_class],credits,owned_ships.size(),int(max_hull()),int(max_shield()),SHIP_SPEEDS[ship_class]*100.0,SHIP_CARGO[ship_class]+(ship_outfit[4]-1)*12]
   for i in range(SHIP_NAMES.size()):
    var label="[ACTIVE]" if i==ship_class else ("[TRANSFER]" if owned_ships.has(i) else ("[BUY %d CR]" % SHIP_PRICES[i]))
    add_action(SHIP_NAMES[i]+"  "+label,buy_ship.bind(i))
   add_action("OUTFITTING / SIX SYSTEM BANKS",show_menu.bind("outfitting"))
   add_action("INSPECT CURRENT HULL / FULL SPECS",ship_inspection.bind(ship_class))
   add_action("HULL INSPECTION CATALOG",show_menu.bind("ship_catalog"))
   add_action("STORED HULLS / FLEET SERVICE",show_menu.bind("ship_service"))
   add_action("FLEET COMMAND / ESCORTS",show_menu.bind("fleet"))
   add_action("LEGACY MK I–V UPGRADES",show_menu.bind("shipyard_legacy"))
   add_action("REPAINT CURRENT HULL / 180 CR",repaint_ship)
   add_action("RETURN TO STATION",show_menu.bind("station") if docked else close_menu)
  "ship_catalog":
   menu_text.text="[b]FLEET HULL CATALOG[/b]\nInspect specifications, installed modules and cargo capacities before purchasing or transferring. Hull condition is preserved separately for each ship."
   for i in range(SHIP_NAMES.size()):
    add_action("INSPECT "+SHIP_NAMES[i],ship_inspection.bind(i))
    if i!=ship_class: add_action("COMPARE "+SHIP_NAMES[i]+" WITH ACTIVE",ship_compare.bind(i))
   add_action("BACK TO SHIPWORKS",show_menu.bind("shipyard"))
  "ship_service":
   menu_text.text="[b]GODS FLEET SERVICE DECK[/b]\n%s\nCredits: %d\nRepair expenditure: %d CR\n\nRepair an individual stored hull or service all owned hulls. Stored ships keep their damage until repaired." % [fleet_readiness(),credits,fleet_repair_spending]
   if docked:
    for i in owned_ships: add_action("REPAIR / RECHARGE "+SHIP_NAMES[i],repair_stored_hull.bind(i))
    add_action("SERVICE ALL OWNED HULLS",repair_all_owned_hulls)
   add_action("BACK TO SHIPWORKS",show_menu.bind("shipyard"))
  "shipyard_legacy":
   menu_text.text="[b]PERMANENT SHIP SYSTEMS[/b]\nExisting engine, shield, weapon, scanner and armor upgrades remain available."
   for kind in ["engine","shield","weapon","scanner","armor"]:
    var level=int(upgrades[kind])
    add_action(kind.to_upper()+"  MK "+str(level)+" → "+("MAX" if level>=5 else str(900*level*level)+" CR"),upgrade_ship.bind(kind))
   add_action("BACK TO SHIPWORKS",show_menu.bind("shipyard"))
  "outfitting":
   menu_text.text="[b]MODULAR OUTFITTING[/b]\nCREDITS %d | HULL %s\n\nInstall modules MK I–V. Thrusters change speed and turning; shields add capacity; weapon racks add hardpoints and damage; cargo increases storage; reactor and sensors prepare expanded fleet systems." % [credits,SHIP_NAMES[ship_class]]
   for i in range(OUTFIT_NAMES.size()):
    var level=ship_outfit[i]
    var cost=int(OUTFIT_PRICES[i])*level*level
    add_action(OUTFIT_NAMES[i]+"  MK "+str(level)+(" MAX" if level>=5 else " → %d CR"%cost),upgrade_outfit.bind(i))
   add_action("SAVE CURRENT TACTICAL PRESET",save_power_preset)
   add_action("RECALL CURRENT HULL PRESET",recall_power_preset)
   add_action("BACK TO SHIPWORKS",show_menu.bind("shipyard"))
  "fleet":
   menu_text.text="[b]FLEET COMMAND[/b]\nAEGIS: %s / %d%% HULL\nSENTINEL: %s / %d%% HULL\nORDER: %s\nFORMATION: %s  /  RULES: %s\nFLEET KILLS: %d\n\nF8 orders · F9 Sentinel · F10 formation · F11 engagement rules. Defensive fire only engages enemies within 950 m of your ship." % ["DEPLOYED" if wingman_active else "STANDBY",int(wingman_hp),"DEPLOYED" if fleet_drone_active else ("READY" if fleet_drone_owned else "NOT OWNED"),int(fleet_drone_hp),FLEET_ORDERS[fleet_order],FLEET_FORMATIONS[formation_index],FLEET_RULES[fleet_rules],fleet_kills]
   add_action("CYCLE FLEET ORDER / F8",fleet_order_next)
   add_action("CHANGE FORMATION / F10",cycle_formation)
   add_action("ENGAGEMENT RULES / F11",cycle_fleet_rules)
   add_action("DESIGNATE TARGET / F12",mark_fleet_target)
   add_action("EMERGENCY REGROUP / BACKSPACE",emergency_fleet_regroup)
   add_action("FLEET READINESS REPORT",show_menu.bind("fleet_report"))
   add_action("RECALL HULL TACTICAL PRESET",recall_power_preset)
   add_action("AEGIS / DEPLOY OR RECALL",toggle_wingman)
   add_action("SENTINEL / DEPLOY OR RECALL / F9",toggle_fleet_drone)
   if not fleet_drone_owned: add_action("PURCHASE SENTINEL ESCORT / 8,800 CR",buy_fleet_drone)
   else: add_action("REPAIR SENTINEL / %d CR" % (int(ceilf(100.0-fleet_drone_hp))*15),repair_fleet_drone)
   add_action("REPAIR AEGIS",repair_wingman)
   add_action("BACK TO SHIPWORKS",show_menu.bind("shipyard") if docked else close_menu)
  "fleet_report":
   menu_text.text="[b]FLEET OPERATIONS REPORT[/b]\n%s\nFleet sorties: %d\nFleet kills: %d\nTarget designations: %d\nEmergency regroups: %d\nRepair expenditure: %d CR\n\nCurrent order: %s\nFormation: %s\nRules: %s\nFocus timer: %.1f sec" % [fleet_readiness(),fleet_sorties,fleet_kills,fleet_marked_targets,fleet_regroups,fleet_repair_spending,FLEET_ORDERS[fleet_order],FLEET_FORMATIONS[formation_index],FLEET_RULES[fleet_rules],fleet_focus_time]
   add_action("MARK SELECTED TARGET",mark_fleet_target)
   add_action("REGROUP ESCORTS",emergency_fleet_regroup)
   add_action("BACK TO FLEET COMMAND",show_menu.bind("fleet"))
  "galaxy":
   add_action("SHIP COMPUTER / CONNECTED COMMAND NEXUS",show_menu.bind("nexus_home"))
   var route_text="NONE" if route_legs.is_empty() else " → ".join(route_names())
   var route_fuel=0
   var leg_start=current_system
   for leg in route_legs:
    route_fuel+=jump_fuel_cost(leg_start,leg)
    leg_start=leg
   var fuel_warning="[color=orange]REFUEL NEEDED BEFORE FINISHING ROUTE[/color]" if route_fuel>int(fuel) else "Fuel sufficient for route"
   menu_text.text="[b]GALACTIC ROUTE NETWORK[/b]\nCURRENT: %s | FUEL: %d%%\n%s\nROUTE: %s\nRoute fuel: %d / %s\n\nOnly linked systems can be jumped in one leg. Plot a destination to calculate the shortest fuel route; press J for each leg. F3 scans a sector. F2 cycles navigation target." % [SYSTEM_NAMES[current_system],int(fuel),SECTOR_DESCRIPTIONS[current_system],route_text,route_fuel,fuel_warning]
   for i in range(SYSTEM_NAMES.size()):
    var known="CHARTED" if charted_sectors.has(i) else "UNSURVEYED"
    add_action("%s  /  %s  /  %s" % [SYSTEM_NAMES[i],known,SECTOR_DESCRIPTIONS[i]],set_jump_target.bind(i))
   add_action("PLOT RETURN TO GODS COMMAND",set_jump_target.bind(0))
   add_action("SCAN CURRENT SECTOR (F3)",scan_sector)
   add_action("CANCEL PLOTTED ROUTE",clear_route)
   add_action("CLOSE GALAXY MAP",close_menu)
  "unknown":
   var complete_here=0
   for record in unknown_sites:
    if unknown_records.has(str(record["key"])): complete_here+=1
   menu_text.text="[b]THE UNKNOWN / DEEP SIGNALS[/b]\nSECTOR: %s\nSIGNALS RESOLVED HERE: %d/2\nTOTAL DISCOVERIES: %d\nFIELD REWARDS: %d CR\nRARE ECHOES: %d\nANCIENT GATE USES: %d\n\n%s\n\nPlot a signal, approach within 550 meters, then hold the investigation beam for five seconds (6). A hidden sanctuary becomes accessible after five discoveries." % [SYSTEM_NAMES[current_system],complete_here,unknown_discoveries,unknown_credits,unknown_rare_serial,unknown_gate_uses,"\n".join(PackedStringArray(unknown_messages.slice(0,8)))]
   for i in range(unknown_sites.size()):
    var record=unknown_sites[i]
    add_action(("[RESOLVED] " if unknown_records.has(str(record["key"])) else "[SIGNAL] ")+str(record["name"])+" / "+str(int(flight_pos.distance_to(record["position"])))+" M",select_unknown_site.bind(i))
   add_action("NEXT UNKNOWN SIGNAL / 7",cycle_unknown_site)
   add_action("INVESTIGATE NEARBY SIGNAL / 6",investigate_unknown)
   add_action("ANCIENT SANCTUARY GATE / 8",activate_unknown_gate)
   add_action("RECOVER ARTIFACT / 9",recover_unknown_artifact)
   add_action("SANCTUARY RESONATORS / 0 CYCLE / 9 ACTIVATE",cycle_sanctuary_pylon)
   add_action("DISCOVERY ARCHIVE",show_menu.bind("unknown_archive"))
   add_action("RETURN TO FLIGHT",close_menu)
  "unknown_archive":
   var lines: Array[String] = []
   for sector_idx in range(SYSTEM_NAMES.size()):
    for site_idx in range(2):
     var key="%d:%d" % [sector_idx,site_idx]
     lines.append(("[COMPLETE] " if unknown_records.has(key) else "[UNRESOLVED] ")+SYSTEM_NAMES[sector_idx]+" / "+UNKNOWN_NAMES[(sector_idx+site_idx*3)%UNKNOWN_NAMES.size()])
   menu_text.text="[b]ARCHIVE OF THE UNKNOWN[/b]\nARTIFACTS RECOVERED: %d / 14\nSANCTUARY VAULTS OPENED: %d / 7\n\n%s\n\n%s" % [unknown_artifact_count,unknown_vaults_opened.size(),"\n".join(PackedStringArray(lines)),"\n".join(PackedStringArray(unknown_messages.slice(0,10)))]
   add_action("RETURN TO SIGNALS",show_menu.bind("unknown"))
  "codex":
   menu_text.text="[b]DISCOVERY CODEX[/b]\n"+("No discoveries logged." if codex.is_empty() else "\n".join(PackedStringArray(codex)))+"\n\nUnknown contacts appear during free flight. Approach to scan."
  "station":
   add_action("STARPORT OPERATIONS / TERMINAL DIRECTORY",show_menu.bind("starport_home"))
   add_action("SHIP COMPUTER / CONNECTED COMMAND NEXUS",show_menu.bind("nexus_home"))
   add_action("LIVING GALAXY / BAZAAR & CAREERS",living_galaxy.show.bind("hub"))
   menu_text.text="[b]%s[/b] / BERTH SECURED\nCredits: %d    Fuel: %d%%    Cargo: %d\nRepairs: %d CR    Refuel: %d CR\nDock visits: %d    Services: %d" % [station_names[current_system],credits,int(fuel),cargo_units,int(ceilf(max_hull()-hull_hp)*9.0+ceilf(max_shield()-shield_hp)*3.0),int(ceilf(100.0-fuel)*6.0),dock_count,ship_service_count]
   add_action("MISSION DIRECTOR / 40 OPERATIONS",show_menu.bind("missions"))
   add_action("SHIPWORKS / HULLS & OUTFITTING",show_menu.bind("shipyard"))
   add_action("FLEET COMMAND / ESCORTS",show_menu.bind("fleet"))
   add_action("CARGO & LOGISTICS",show_menu.bind("cargo"))
   add_action("TACTICAL ARMORY / SALVAGE",show_menu.bind("armory"))
   add_action("COMBAT COMMAND / BOUNTIES",show_menu.bind("tactics"))
   add_action("SECURITY / PATROL",show_menu.bind("security"))
   add_action("ENGINEERING / REPAIR & REFUEL",show_menu.bind("engineering"))
   add_action("LONG-RANGE COMMS",show_menu.bind("comms"))
   add_action("UNKNOWN SIGNALS / ANCIENT GATE",show_menu.bind("unknown"))
   add_action("STATION ADMINISTRATION",show_menu.bind("administration"))
   add_action("LAUNCH SHIP",launch_from_station)
  "armory":
   menu_text.text="[b]TACTICAL ARMORY[/b]\nMISSILES %d / 12\nRecovered alloys: %d\nCircuits: %d\nAncient cores: %d\nSell salvage for credits, or keep it for later fleet systems." % [missile_ammo,int(salvage_inventory["alloys"]),int(salvage_inventory["circuits"]),int(salvage_inventory["cores"])]
   add_action("REARM GUIDED MISSILES / 140 CR EACH",station_service.bind("rearm"))
   add_action("SELL RECOVERED SALVAGE",sell_salvage)
   add_action("REPAIR AEGIS WINGMAN",repair_wingman)
   add_action("FLEET COMMAND",show_menu.bind("fleet"))
   add_action("COMBAT COMMAND",show_menu.bind("tactics"))
   add_action("RETURN TO STATION",show_menu.bind("station"))
  "tactics":
   menu_text.text="[b]TACTICAL COMMAND[/b]\nWeapon: %s | Heat: %d%% | Power: %s\nWingman: %s | Bounty wave: %d | Tractor: %s\nKills: %d | Bounties: %d | Damage dealt: %d\n\nDeploy Aegis, manage weapons, or start a local combat challenge. Rewards increase each wave." % [WEAPON_NAMES[weapon_mode],int(weapon_heat),["WEAPONS","BALANCED","SHIELDS"][shield_power],("ACTIVE" if wingman_active else "STANDBY")+" "+str(int(wingman_hp))+"%",bounty_round,"ON" if tractor_active else "OFF",combat_kills,combat_bounties_completed,int(combat_damage_dealt)]
   add_action("CYCLE PRIMARY WEAPON / Z",cycle_weapon)
   add_action("REDISTRIBUTE REACTOR POWER / P",cycle_power)
   add_action("DEPLOY / RECALL AEGIS WINGMAN / Y",toggle_wingman)
   add_action("TOGGLE SALVAGE TRACTOR / O",toggle_tractor)
   add_action("START NEXT BOUNTY WAVE",launch_bounty_round)
   add_action("CLOSE TACTICAL COMMAND",close_menu)
  "cargo":
   add_action("REGIONAL MARKETS & FREIGHT",living_galaxy.show.bind("freight"))
   menu_text.text="[b]CARGO & LOGISTICS[/b]\nLoading manifest: %d / %d units\n%s\nVisit the remote objective and return to this station for payment." % [cargo_units,SHIP_CARGO[ship_class]+(ship_outfit[4]-1)*12,("CURRENT: "+String(station_job.get("name",""))) if not station_job.is_empty() else "NO ACTIVE STATION CONTRACT"]
   add_action("MEDICAL FREIGHT / 2,600 CR",start_station_job.bind("cargo"))
   add_action("RELAY RECOVERY / 3,100 CR",start_station_job.bind("salvage"))
   add_action("RETURN TO STATION",show_menu.bind("station"))
  "security":
   menu_text.text="[b]GODS SECURITY WING[/b]\nPatrol authorization active.\nCurrent system: "+SYSTEM_NAMES[current_system]
   add_action("PERIMETER INSPECTION / 2,900 CR",start_station_job.bind("security"))
   add_action("COMBAT OPERATIONS",show_menu.bind("missions"))
   add_action("TACTICAL ARMORY",show_menu.bind("armory"))
   add_action("RETURN TO STATION",show_menu.bind("station"))
  "engineering":
   menu_text.text="[b]ENGINEERING BAY[/b]\nRestore integrity, replenish jump fuel, and recharge the reactor. Repairs and fuel cost credits."
   add_action("REPAIR HULL & SHIELDS",station_service.bind("repair"))
   add_action("REFUEL FRAME DRIVE",station_service.bind("refuel"))
   add_action("RECHARGE REACTOR",station_service.bind("recharge"))
   add_action("REARM GUIDED MISSILES / 140 CR EACH",station_service.bind("rearm"))
   add_action("SHIPWORKS MODULES",show_menu.bind("shipyard"))
   add_action("RETURN TO STATION",show_menu.bind("station"))
  "comms":
   menu_text.text="[b]LONG-RANGE COMMS[/b]\nRecent control transmissions:\n"+("No transmissions yet." if radio_log.is_empty() else "\n".join(PackedStringArray(radio_log)))
   add_action("GALAXY MAP / PLOT ROUTE",show_menu.bind("galaxy"))
   add_action("DISCOVERY CODEX",show_menu.bind("codex"))
   add_action("PLANETARY EXPEDITIONS",show_menu.bind("worlds"))
   add_action("THE UNKNOWN / DEEP SIGNALS",show_menu.bind("unknown"))
   add_action("RETURN TO STATION",show_menu.bind("station"))
  "administration":
   menu_text.text="[b]STATION ADMINISTRATION[/b]\nVisits: %d   Services: %d\nStatus: BERTH SECURED\nOperation: %s\nUse SAVE GAME to preserve current progress." % [dock_count,ship_service_count,"CLOSED" if mission_stage>=6 else "ACTIVE"]
   add_action("SAVE GAME",save_game)
   add_action("RETURN TO STATION",show_menu.bind("station"))
  "worlds":
   var orbit_distance=flight_pos.distance_to(world_orbit_position)
   var done_here=0
   for site_idx in range(3):
    if surface_records.has(surface_record_key(current_system,site_idx)): done_here+=1
   menu_text.text="[b]PLANETARY EXPEDITIONS / PASS 17B[/b]\nWORLD: %s\nSYSTEM: %s\nSTATUS: %s\nORBITAL DISTANCE: %d M\nSITES CHARTED HERE: %d/3\nWORLDS COMPLETE: %d/7\nTOTAL SITE SCANS: %d\nSURFACE SORTIES: %d\nSURVEY EARNINGS: %d CR\n\nACTIVE SITE: %s\n\n1 descend/ascend; 4 select next site; 2 start a 4-second scan within 180 m. Remain close and steady until the scan completes. Survey three sites to finish a world." % [WORLD_NAMES[current_system],SYSTEM_NAMES[current_system],"SURFACE FLIGHT" if on_surface else "ORBIT",int(orbit_distance),done_here,surveyed_worlds.size(),surface_scan_completed,surface_flights,world_discovery_total,SURVEY_SITE_NAMES[selected_surface_site]]
   add_action("ASCEND TO ORBIT" if on_surface else "INITIATE PLANETARY DESCENT",toggle_planet_approach)
   add_action("PLOT PLANETARY APPROACH / F2 NAV",set_planetary_waypoint)
   add_action("SELECT NEXT SURVEY SITE / 4",cycle_surface_site)
   add_action("START SURVEY SCAN / 2",survey_planet)
   add_action("DISCOVERY CODEX",show_menu.bind("codex"))
   add_action("RETURN TO FLIGHT",close_menu)
  "graphics":
   menu_text.text="[b]PASS 22 / CINEMATIC GRAPHICS STUDIO[/b]\nSelect a quality preset. Cinematic uses glow, high-detail hull fittings, atmospheric halos and nebulae. Balanced retains textures and key details. Performance disables expensive effects.\n\nThese settings do not affect missions or save progression."
   add_action("CINEMATIC / HIGH DETAIL",set_pass21_quality.bind(2))
   add_action("BALANCED / MEDIUM DETAIL",set_pass21_quality.bind(1))
   add_action("PERFORMANCE / LOW DETAIL",set_pass21_quality.bind(0))
   add_action("RETURN TO FLIGHT SUPPORT",show_menu.bind("flight_support"))
  "flight_support":
   add_action("SHIP COMPUTER / CONNECTED COMMAND NEXUS",show_menu.bind("nexus_home"))
   menu_text.text="[b]PASS 20 / FLIGHT SUPPORT[/b]\n%s\n\nSector: %s | Ship: %s\nLocation: %s\nLast save: %s\n\nEmergency recovery returns your ship to a safe approach near the local station; it does not complete any objectives. Use only if your ship becomes trapped." % [pass20_last_check,SYSTEM_NAMES[current_system],SHIP_NAMES[ship_class],str(flight_pos.round()),last_save_status]
   add_action("PASS 22 GRAPHICS / QUALITY PRESETS",show_menu.bind("graphics"))
   add_action("NAV PILOT / ACTIVE WAYPOINT / CTRL+7",p38_set_nav_mode.bind(1))
   add_action("NAV PILOT / STATION APPROACH / CTRL+8",p38_set_nav_mode.bind(2))
   add_action("NAV PILOT / AUTO DOCK / CTRL+9",p38_set_nav_mode.bind(3))
   add_action("NAV PILOT / MANUAL CONTROL / CTRL+6",p37_set_flight_mode.bind(0))
   add_action("RUN STARTUP / GAMEPLAY CHECKS",pass20_check_and_show)
   add_action("PLOT ACTIVE MISSION ROUTE",pass20_plot_mission)
   add_action("RESET FLIGHT / CAMERA CONTROLS",pass20_reset_flight)
   add_action("RECOVER TO LOCAL STATION APPROACH",pass20_recover_ship)
   add_action("TOGGLE LOW DETAIL / ASTEROIDS + STAR COUNT",pass20_toggle_detail)
   add_action("SAVE GAME NOW",pass20_save_and_show)
   add_action("EXPORT DIAGNOSTIC REPORT",pass20_export_report)
   add_action("RETURN TO FLIGHT",close_menu)
  "help":
   menu_text.text="[b]THE UNKNOWN[/b] ALT+5 opens signal operations; ALT+7 cycles a target; ALT+6 investigates within 550m for five seconds. After five discoveries, ALT+8 opens the hidden sanctuary gate. Rare echoes appear during free flight.\n[b]WORLDS[/b] ALT+3 opens planetary expeditions. Plot the planet with its menu or F2. Fly within 2700m of the planet and press ALT+1 to descend; ALT+1 again ascends. On the surface, ALT+4 selects one of three survey sites and ALT+2 begins a four-second scan within 180m. Stay within range. Planetary flight is a local terrain zone.\n[b]MISSION DIRECTOR[/b] M opens 40 operations across 7 sectors. Two objective sites per contract; F4 interacts within 500m for scans, salvage, rescues, deliveries and gates. Combat needs kills; escorts require formation hold. Return to Gods Command to collect payment.\n[b]FLIGHT[/b] WASD or left-drag steer. Right-drag / Q,R rolls. 1–9 sets 10–90% throttle, 0 sets 100%; ~ toggles full engine shutdown/restart, - and = adjust by 5%, BACKSLASH sets 75%; SHIFT increases throttle, CTRL reduces, X all stop. ALT+1–0 uses exploration shortcuts. SPACE boosts (rechargeable). H toggles flight assist; N toggles arrival braking.\n[b]CAMERA[/b] V toggles cockpit/chase; mouse wheel zooms chase.\n[b]TRAVEL[/b] G opens 7-system map; plot linked multi-hop routes. J charges next jump (4.8 seconds), C supercruise, F2 changes waypoint, F3 scans local sector. Return to Gods Command to hand in mission rewards.\n[b]TACTICAL[/b] F fires twin cannons, TAB cycles target, T selects subsystem, K launches guided missiles, L deploys countermeasures, Z changes primary guns (pulse / rail / flak), P redistributes power, Y deploys Aegis wingman, O enables tractor salvage, I opens Tactical Command. Guns accumulate heat; stop firing to cool. Collect glowing salvage by flying close. Rearm at Engineering.\n[b]OPERATIONS[/b] M missions, B shipyard, G galaxy, U codex, E request docking, E begin auto-land, E launch from hangar.\n[b]SHIPWORKS[/b] B opens ship exchange; dock to buy/switch hulls, repaint and upgrade six module banks. F7 opens Fleet Command, F8 orders, F9 Sentinel, F10 formations, F11 rules, F12 focus target, BACKSPACE regroup. Dock to repair stored hulls.\n[b]SAVE[/b] F5 saves and autosave every 60 sec. ESC closes menus. SHIFT+F4 opens Flight Support. Autosave every 60 sec."
  _:
   if which.begins_with("mission_sector_"):
    var sector=clampi(int(which.trim_prefix("mission_sector_")),0,SYSTEM_NAMES.size()-1)
    mission_ui_sector=sector
    menu_text.text="[b]%s OPERATIONS[/b]\nSelect a contract to inspect objectives and rewards." % SYSTEM_NAMES[sector]
    for i in range(MISSIONS.size()):
     var m=MISSIONS[i]
     if int(m["sector"])==sector:
      var done=" [CLEARED]" if mission_completed.has(i) else ""
      add_action("%02d · %s / %d CR%s" % [i+1,m["name"],int(m["reward"]),done],show_menu.bind("mission_details_"+str(i)))
    add_action("BACK TO SECTOR LIST",show_menu.bind("missions"))
   elif which.begins_with("mission_details_"):
    var index=clampi(int(which.trim_prefix("mission_details_")),0,MISSIONS.size()-1)
    var m=MISSIONS[index]
    var route_description=SYSTEM_NAMES[int(m["sector"])] + "  →  " + SYSTEM_NAMES[mission_sector_for(index,2)]
    if mission_has_third_leg(index): route_description+="  →  "+SYSTEM_NAMES[mission_third_sector(index)]
    menu_text.text="[b]%s[/b]\nROUTE: %s\nOBJECTIVES: %d SITES  /  %s\nReward: %d CR + field bonuses\nStatus: %s  /  Best grade: %s\n\n%s\n\nNavigation: plot each new leg when the previous site is secured. F4 handles scans, rescues and salvage. Escort and defense stages require active flight and combat. F6 recovers optional caches." % [m["name"],route_description,mission_total_sites(index),("DEEP-SPACE EXPEDITION" if mission_has_third_leg(index) else "STANDARD CONTRACT"),int(m["reward"]),"PREVIOUSLY CLEARED" if mission_completed.has(index) else "NEW CONTRACT",str(mission_best_grades.get(str(index),"—")),mission_briefing(index)]
    add_action("ACCEPT THIS OPERATION",accept_mission.bind(index))
    add_action("BACK TO SECTOR",show_menu.bind("mission_sector_"+str(int(m["sector"]))))
   else:
    menu_text.text="NO SUCH TERMINAL: "+which
 if docked:
  add_action("▶ LAUNCH / UNDOCK NOW  [E / SHIFT+L]",launch_from_station)
 add_action("CLOSE / RETURN TO FLIGHT",close_menu)
func close_menu() -> void:
 menu_open=false
 menu.visible=false
func set_jump_target(i: int) -> void:
 plot_route(i,true)

func clear_route() -> void:
 route_destination=-1
 route_legs.clear()
 announce("GALACTIC ROUTE CLEARED")
 show_menu("galaxy")
func update_hud() -> void:
 if hud==null: return
 var mode = "FRAME SHIFT" if jump_timer > 0.0 else ("SUPERCRUISE %d%%" % int(cruise_spool * 100.0) if cruise else ("BOOST" if boost_active else "NORMAL"))
 hud.text = SHIP_NAMES[ship_class]+"  /  F7 FLEET\nHULL %d/%d   SHIELD %d/%d   CREDITS %d\nSPEED %d M/S   THROTTLE %d%%   %s\nSYSTEM %s\nASSIST %s   NAV BRAKE %s   BOOST %d%%" % [int(hull_hp),int(max_hull()),int(shield_hp),int(max_shield()),credits,int(velocity),int(throttle*100),mode,SYSTEM_NAMES[current_system],"ON" if flight_assist else "OFF","ON" if nav_assist else "OFF",int(boost_reserve)]
 if p34_speed_label != null:
  p34_speed_label.text = "FLIGHT BAND: %s  /  SHIFT+TAB NEAREST  /  TAB CYCLE" % ("OPTIMAL TURN" if throttle>=p34_optimal_min and throttle<=p34_optimal_max else ("HIGH-SPEED" if throttle>p34_optimal_max else "PRECISION"))
 var m=MISSIONS[active_mission]
 hud.text += "\nPIPS E%d W%d S%d | ENERGY %d%% | CTRL+1/2/3 ALLOCATE | CTRL+Q/E/R ABILITIES" % [p36_power_engines,p36_power_weapons,p36_power_shields,int(energy)]
 hud.text += "\nFLIGHT COMPUTER: %s  | CTRL+4 PURSUE / CTRL+5 HOLD / CTRL+6 MANUAL" % p37_status
 hud.text += "\nNAV PILOT: %s | CTRL+7 WAYPOINT / CTRL+8 APPROACH / CTRL+9 DOCK" % p38_nav_status
 hud.text += "\nSAFETY SCANNER: %s" % ("CRITICAL HOLD / CTRL+6 ACKNOWLEDGE" if p41_emergency_hold else p41_hazard_status)
 hud.text += "\nTACTICAL ESCAPE: %s | CTRL+SHIFT+7 EVADE / CTRL+SHIFT+8 RESUME" % p42_status
 hud.text += "\nGUARDIAN: %s [%s] | CTRL+SHIFT+9 TOGGLE / CTRL+SHIFT+4 PROFILE" % [p43_status,p44_profile_name()]
 if p44_fuel_hold:
  hud.text += "\nFUEL RESERVE HOLD: %d%% REMAINING / CTRL+6 MANUAL" % int(fuel)
 if not p44_incidents.is_empty():
  hud.text += "\nFLIGHT LOG: %s" % p44_incidents.back()
 if mission_stage>=6:
  mission_hud.text="MISSION DIRECTOR  /  %d OF 40 CLEARED\nDOCK AT A STATION · M FOR CONTRACT BOARD" % mission_completed.size()
 else:
  var goal: Vector3=mission_objective_position()
  var distance=flight_pos.distance_to(goal)
  var sector_name=SYSTEM_NAMES[mission_current_sector()]
  var progress=" / KILLS %d/2" % mission_phase_kills if mission_objective_kind()=="combat" else (" / HOLD %ds" % int(mission_elapsed) if mission_objective_kind()=="escort" or mission_objective_kind()=="defense" else "")
  var current_step: int=mission_stage+1+(2 if mission_extra_active or mission_extra_done else 0)
  mission_hud.text="OPERATION: %s\nSTEP %d/%d · %s%s\n%s · %s  /  %s" % [m["name"],mini(current_step,mission_total_steps()),mission_total_steps(),mission_phase_label(),progress,sector_name,(str(int(distance))+" M" if current_system==mission_current_sector() else "FRAME SHIFT REQUIRED"),("F4 INTERACT" if current_system==mission_current_sector() else "J NEXT HOP")]
 if mission_stage==1 or mission_stage==3:
  var key=mission_bonus_key()
  if not mission_bonus_done.has(key) and current_system==mission_current_sector():
   mission_hud.text+="\nOPTIONAL CACHE: %d M / F6 RECOVER" % int(flight_pos.distance_to(mission_bonus_position()))
  if current_system==mission_current_sector() and not encounter_done.has(encounter_key()):
   var signal_dist=int(flight_pos.distance_to(encounter_position()))
   mission_hud.text+="\n%s: %d M / SHIFT+F6 INVESTIGATE" % [encounter_kind(),signal_dist]
   if encounter_scan_active: mission_hud.text+="\nRIFT STABILIZATION %d%% / HOLD 350 M" % int(encounter_scan_progress*12.5)
  if mission_objective_kind()=="escort": mission_hud.text+="\nCONVOY %d%% ROUTE / %d%% INTEGRITY%s" % [int(escort_progress*100.0),int(escort_integrity)," / DISABLED — RETRY IN M" if mission_escort_failed else ""]
  if mission_scan_active: mission_hud.text+="\nSCANNING %d%% — HOLD WITHIN 450 M" % int(mission_scan_charge*20.0)
 if tactical_panel!=null:
  var near=0
  var closest=999999.0
  for e in enemies:
   if is_instance_valid(e):
    var d=e.position.distance_to(flight_pos)
    if d<2400.0: near+=1
    closest=minf(closest,d)
  tactical_panel.text="FLEET %s / %s / %s  SENTINEL %s\nGUN %s  HEAT %d%% %s\nPWR %s  AEGIS %s  TRACTOR %s\nRADAR %d HOSTILES / CLOSEST %s" % [FLEET_ORDERS[fleet_order],FLEET_FORMATIONS[formation_index],FLEET_RULES[fleet_rules],"ON" if fleet_drone_active else "OFF",WEAPON_NAMES[weapon_mode],int(weapon_heat),"[OVERHEAT]" if weapon_overheat else "",["WEAPONS","BALANCED","SHIELDS"][shield_power],"ACTIVE" if wingman_active else "STBY","ON" if tractor_active else "OFF",near,(str(int(closest))+"m") if near>0 else "CLEAR"]
 if combat_readout!=null:
  combat_readout.text="TACTICAL   MISSILES %d   FLARES %s   SALVAGE A:%d C:%d CORE:%d" % [missile_ammo,("READY" if countermeasure_cooldown<=0.0 else str(int(ceilf(countermeasure_cooldown)))+"s"),int(salvage_inventory["alloys"]),int(salvage_inventory["circuits"]),int(salvage_inventory["cores"])]
 if target_readout!=null:
  if enemies.is_empty(): target_readout.text="TARGET  NO HOSTILES"
  else:
   target_index=clampi(target_index,0,enemies.size()-1)
   var enemy: Node3D=enemies[target_index]
   target_readout.text="LOCK %s  /  %d M  /  HULL %d%%  SHIELD %d%%  /  AIM: %s" % [enemy.name,int(enemy.position.distance_to(flight_pos)),int(100.0*float(enemy.get_meta("hp"))/float(enemy.get_meta("max_hp"))),int(100.0*float(enemy.get_meta("shield"))/float(enemy.get_meta("max_shield"))),subsystem_names[target_subsystem]+(" / ENGINES OFF" if float(enemy.get_meta("engine_damage"))>=0.92 else "")+(" / GUNS OFF" if float(enemy.get_meta("weapon_damage"))>=0.95 else "")]
 if docking_label!=null:
  var status = "DOCKED — E OR SHIFT+L TO LAUNCH / M FOR MISSIONS" if docked else ("LANDING AUTO-PILOT %d%%" % int((1.0-landing_timer/4.2)*100.0) if landing_timer>0.0 else ("LAUNCHING %d%%" % int((1.0-launch_timer/2.4)*100.0) if launch_timer>0.0 else ("CLEARED — CLOSE TO 900 M, PRESS E TO LAND" if clearance_granted else "E REQUEST DOCKING CLEARANCE")))
  docking_label.text = ("%s: %d M  ·  %s" % [station_names[current_system],int(dock_range()),status]) if dock_range()<2400.0 or docked else ""
 if not station_job.is_empty():
  mission_hud.text+="\nSTATION JOB: "+String(station_job.get("name",""))+ (" / RETURN TO DOCK" if bool(station_job.get("complete",false)) else " / RANGE "+str(int(flight_pos.distance_to(station_job["goal"])))+" M")
 if on_surface:
  var site_dist=int(flight_pos.distance_to(surface_site_position(selected_surface_site)))
  mission_hud.text+="\nSURFACE: %s / %s %d M / 4 NEXT / 2 SCAN" % [WORLD_NAMES[current_system],SURVEY_SITE_NAMES[selected_surface_site],site_dist]
  if surface_scan_site>=0: mission_hud.text+="\nSURVEY SCAN %d%% — HOLD POSITION" % int(surface_scan_time/4.0*100.0)
 elif world_transition>0.0: mission_hud.text+="\nATMOSPHERIC TRANSITION %d%%" % int((1.0-world_transition/3.2)*100.0)
 elif flight_pos.distance_to(world_orbit_position)<2700.0: mission_hud.text+="\nPLANETARY APPROACH / 1 DESCEND / 3 WORLD INFO"
 if unknown_scanning:
  mission_hud.text+="\nDEEP SIGNAL %d%% / STABILITY %d%% — HOLD 550 M" % [int(unknown_scan_progress*20.0),int(unknown_stability)]
 elif unknown_pocket:
  var opened=unknown_vaults_opened.has(str(current_system))
  mission_hud.text+="\nANCIENT SANCTUARY / 9 ACTIVATE PYLON / 8 RETURN / VAULT %s" % ("OPEN" if opened else "SEALED")
 elif not unknown_sites.is_empty():
  var target_record=unknown_sites[clampi(unknown_selected,0,unknown_sites.size()-1)]
  mission_hud.text+="\nUNKNOWN %s / %d M / 5 MENU / 6 SCAN" % [str(target_record["name"]),int(flight_pos.distance_to(target_record["position"]))]
 if jump_timer>0.0: mission_hud.text+="\nFRAME SHIFT CHARGING "+str(int((1.0-jump_timer/jump_charge_total)*100.0))+"%"
 if nav_label!=null:
  var destination=nav_waypoint()
  var dist=flight_pos.distance_to(destination)
  var direction=(destination-flight_pos).normalized()
  var forward=-Basis.from_euler(Vector3(pitch,yaw,roll)).z
  var bearing="AHEAD" if forward.dot(direction)>0.75 else ("BEHIND" if forward.dot(direction)<-0.2 else "OFF AXIS")
  var desired_sector: int=mission_current_sector()
  var sector_hint=" / PLOT ROUTE TO "+SYSTEM_NAMES[desired_sector] if nav_target==0 and desired_sector!=current_system else ""
  nav_label.text="NAV %s%s\n%s / %d M / %s\nROUTE %s  ·  FUEL %d%%\nSCAN %s" % [nav_target_name(),sector_hint,SYSTEM_NAMES[current_system],int(dist),bearing,(" → ".join(route_names()) if not route_legs.is_empty() else "NO ROUTE"),int(fuel),scan_results]
 if jump_label!=null:
  jump_label.text="FRAME SHIFT  %d%%\n%s → %s" % [int((1.0-jump_timer/jump_charge_total)*100.0),SYSTEM_NAMES[jump_from],SYSTEM_NAMES[jump_to]] if jump_timer>0.0 else ""
func announce(s: String) -> void:
 status_message=s
 alert_timer=5.0
 if alert_label!=null: alert_label.text=s
func save_game() -> void:
 if save_write_busy: return
 save_write_busy=true
 store_current_hull()
 var data={"position":[flight_pos.x,flight_pos.y,flight_pos.z],"yaw":yaw,"pitch":pitch,"roll":roll,"throttle":throttle,"engine_cutoff":engine_cutoff,"p36_pips":[p36_power_engines,p36_power_weapons,p36_power_shields],"linear_velocity":[linear_velocity.x,linear_velocity.y,linear_velocity.z],"assist":flight_assist,"nav_assist":nav_assist,"chase":chase,"camera_distance":chase_distance_target,"credits":credits,"mission":active_mission,"stage":mission_stage,"kills":mission_kills,"hull":hull_hp,"shield":shield_hp,"system":current_system,"target":jump_target,"docked":docked,"upgrades":upgrades,"codex":codex,"contacts":[],"dock_count":dock_count,"service_count":ship_service_count,"fuel":fuel,"cargo_units":cargo_units,"clearance":clearance_granted and landing_timer<=0.0 and not docked,"station_job":{},"missile_ammo":missile_ammo,"salvage_inventory":salvage_inventory,"target_subsystem":target_subsystem,"weapon_mode":weapon_mode,"weapon_heat":weapon_heat,"shield_power":shield_power,"wingman_active":wingman_active,"wingman_hp":wingman_hp,"tractor_active":tractor_active,"bounty_round":bounty_round,"bounty_active":bounty_active,"combat_kills":combat_kills,"combat_damage_dealt":combat_damage_dealt,"combat_damage_taken":combat_damage_taken,"combat_missiles_fired":combat_missiles_fired,"combat_bounties_completed":combat_bounties_completed,"route_destination":route_destination,"route_legs":route_legs,"visited_sectors":visited_sectors,"charted_sectors":charted_sectors,"nav_target":nav_target}
 if not station_job.is_empty():
  var g: Vector3 = station_job["goal"]
  data["station_job"]={"name":station_job["name"],"reward":station_job["reward"],"complete":station_job["complete"],"kind":station_job["kind"],"goal":[g.x,g.y,g.z]}
 data["hull_module_banks"]=hull_module_banks
 data["hull_conditions"]=hull_conditions
 data["loadout_presets"]=loadout_presets
 data["formation_index"]=formation_index
 data["fleet_rules"]=fleet_rules
 data["ship_transfers"]=ship_transfers
 data["fleet_sorties"]=fleet_sorties
 data["fleet_regroups"]=fleet_regroups
 data["fleet_marked_targets"]=fleet_marked_targets
 data["fleet_repair_spending"]=fleet_repair_spending
 data["ship_class"]=ship_class
 data["owned_ships"]=owned_ships
 data["ship_outfit"]=ship_outfit
 data["ship_custom_colors"]=ship_custom_colors
 data["fleet_order"]=fleet_order
 data["fleet_drone_owned"]=fleet_drone_owned
 data["fleet_drone_hp"]=fleet_drone_hp
 data["fleet_kills"]=fleet_kills
 data["fleet_service_spent"]=fleet_service_spent
 data["p44_profile"]=p44_profile
 data["p44_incidents"]=p44_incidents.slice(-12)
 data["mission_version"]=26
 data["encounter_done"]=encounter_done.slice(-200)
 data["mission_extra_active"]=mission_extra_active
 data["mission_extra_done"]=mission_extra_done
 data["mission_extra_total"]=mission_extra_total
 data["unknown_records"]=unknown_records
 data["unknown_selected"]=unknown_selected
 data["unknown_discoveries"]=unknown_discoveries
 data["unknown_credits"]=unknown_credits
 data["unknown_messages"]=unknown_messages.slice(0,30)
 data["unknown_rare_serial"]=unknown_rare_serial
 data["unknown_gate_uses"]=unknown_gate_uses
 data["unknown_artifacts"]=unknown_artifacts
 data["unknown_sanctuary_keys"]=unknown_sanctuary_keys
 data["unknown_vaults_opened"]=unknown_vaults_opened
 data["unknown_pylon_index"]=unknown_pylon_index
 data["unknown_pocket"]=unknown_pocket
 data["unknown_pocket_return"]=[unknown_pocket_return.x,unknown_pocket_return.y,unknown_pocket_return.z]
 data["surface_records"]=surface_records
 data["selected_surface_site"]=selected_surface_site
 data["surface_samples"]=surface_samples
 data["surface_scan_completed"]=surface_scan_completed
 data["on_surface"]=on_surface or (world_transition>0.0 and world_transition_to_surface)
 data["surveyed_worlds"]=surveyed_worlds
 data["surface_flights"]=surface_flights
 data["world_discovery_total"]=world_discovery_total
 data["mission_scan_active"]=mission_scan_active
 data["mission_scan_charge"]=mission_scan_charge
 data["mission_escort_failed"]=mission_escort_failed
 data["mission_best_grades"]=mission_best_grades
 data["mission_last_grade"]=mission_last_grade
 data["mission_current_damage"]=mission_current_damage
 data["mission_current_retries"]=mission_current_retries
 data["mission_bonus_done"]=mission_bonus_done
 data["mission_bonus_value"]=mission_bonus_value
 data["mission_journal"]=mission_journal
 data["mission_fails"]=mission_fails
 data["mission_retries"]=mission_retries
 data["mission_last_result"]=mission_last_result
 data["escort_progress"]=escort_progress
 data["escort_integrity"]=escort_integrity
 data["mission_elapsed"]=mission_elapsed
 data["mission_phase_kills"]=mission_phase_kills
 data["mission_event_spawned"]=mission_event_spawned
 data["mission_completed"]=mission_completed
 data["mission_successes"]=mission_successes
 data["mission_chain_count"]=mission_chain_count
 data["mission_reward_bonus"]=mission_reward_bonus
 data["enemy_state"]=[]
 for e in enemies:
  if is_instance_valid(e):
   data["enemy_state"].append({"name":e.name,"hp":e.get_meta("hp"),"shield":e.get_meta("shield"),"engine_damage":e.get_meta("engine_damage"),"weapon_damage":e.get_meta("weapon_damage"),"shield_damage":e.get_meta("shield_damage")})
 for c in contacts: data["contacts"].append({"name":c["name"],"position":[c["position"].x,c["position"].y,c["position"].z],"found":c["found"]})
 data["pass20_low_detail"]=pass20_low_detail
 if is_instance_valid(living_galaxy): data["living_galaxy"]=living_galaxy.export_state()
 if is_instance_valid(command_nexus): data["command_nexus"]=command_nexus.export_state()
 data["pass21_quality"]=pass21_quality
 data["pass20_recoveries"]=pass20_recoveries
 data["save_schema"]=SAVE_SCHEMA_VERSION
 var encoded=JSON.stringify(data)
 if encoded.length()>SAVE_MAX_BYTES:
  last_save_ok=false
  last_save_status="SAVE TOO LARGE / DATA RETAINED"
  autosave_failures+=1
  save_write_busy=false
  return
 var f=FileAccess.open(SAVE_TEMP_PATH,FileAccess.WRITE)
 if f==null:
  last_save_ok=false
  last_save_status="WRITE FAILED: "+str(FileAccess.get_open_error())
  autosave_failures+=1
  save_write_busy=false
  return
 f.store_string(encoded)
 f.flush()
 f.close()
 var written=FileAccess.get_file_as_string(SAVE_TEMP_PATH)
 if written!=encoded:
  last_save_ok=false
  last_save_status="TEMP SAVE VERIFICATION FAILED"
  autosave_failures+=1
  save_write_busy=false
  return
 var save_abs=ProjectSettings.globalize_path(SAVE_PATH)
 var temp_abs=ProjectSettings.globalize_path(SAVE_TEMP_PATH)
 var backup_abs=ProjectSettings.globalize_path(SAVE_BACKUP_PATH)
 if FileAccess.file_exists(SAVE_PATH) and not recovered_pending_save:
  var existing=FileAccess.get_file_as_string(SAVE_PATH)
  if JSON.parse_string(existing) is Dictionary:
   DirAccess.copy_absolute(save_abs,backup_abs)
 var result=DirAccess.rename_absolute(temp_abs,save_abs)
 if result!=OK:
  # A Windows antivirus or file lock may prevent replacing the destination.
  result=DirAccess.copy_absolute(temp_abs,save_abs)
 last_save_ok=result==OK
 last_save_status="SAVED" if last_save_ok else "RENAME/COPY ERROR: "+str(result)
 if not last_save_ok: autosave_failures+=1
 save_write_busy=false
 if last_save_ok: recovered_pending_save=false
func load_game() -> void:
 if not FileAccess.file_exists(SAVE_PATH) and not FileAccess.file_exists(SAVE_BACKUP_PATH) and not FileAccess.file_exists(SAVE_TEMP_PATH): return
 var data=JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH)) if FileAccess.file_exists(SAVE_PATH) else null
 if not data is Dictionary and FileAccess.file_exists(SAVE_BACKUP_PATH):
  data=JSON.parse_string(FileAccess.get_file_as_string(SAVE_BACKUP_PATH))
  if data is Dictionary:
   last_save_status="BACKUP RECOVERED"
   push_warning("Space Gods recovered its previous valid save backup")
 if not data is Dictionary and FileAccess.file_exists(SAVE_TEMP_PATH):
  data=JSON.parse_string(FileAccess.get_file_as_string(SAVE_TEMP_PATH))
  if data is Dictionary:
   recovered_pending_save=true
   last_save_status="PENDING SAVE RECOVERED"
   push_warning("Space Gods recovered a valid interrupted save")
 if not data is Dictionary:
  push_warning("Space Gods save data is damaged. Starting with default state.")
  last_save_status="SAVE DAMAGED"
  return
 var galaxy_data=data.get("living_galaxy",{})
 if is_instance_valid(command_nexus): command_nexus.import_state(data.get("command_nexus",{}))
 if galaxy_data is Dictionary: living_saved_state=galaxy_data
 p44_profile=clampi(int(data.get("p44_profile",1)),0,2)
 p44_incidents.clear()
 var saved_incidents = data.get("p44_incidents",[])
 if saved_incidents is Array:
  for incident in saved_incidents.slice(-12):
   p44_incidents.append(str(incident).substr(0,110))
 pass20_low_detail=bool(data.get("pass20_low_detail",false))
 pass21_quality=clampi(int(data.get("pass21_quality",2)),0,2)
 pass20_recoveries=maxi(0,int(data.get("pass20_recoveries",0)))
 var saved_unknown=data.get("unknown_records",{})
 if saved_unknown is Dictionary:
  for key in saved_unknown.keys():
   if bool(saved_unknown[key]): unknown_records[str(key)]=true
 unknown_selected=clampi(int(data.get("unknown_selected",0)),0,1)
 unknown_discoveries=maxi(unknown_records.size(),int(data.get("unknown_discoveries",0)))
 unknown_credits=maxi(0,int(data.get("unknown_credits",0)))
 unknown_rare_serial=maxi(0,int(data.get("unknown_rare_serial",0)))
 unknown_gate_uses=maxi(0,int(data.get("unknown_gate_uses",0)))
 for record_key in data.get("unknown_artifacts",{}):
  unknown_artifacts[str(record_key)]=true
 unknown_artifact_count=unknown_artifacts.size()
 for key in data.get("unknown_sanctuary_keys",{}):
  unknown_sanctuary_keys[str(key)]=true
 for key in data.get("unknown_vaults_opened",{}):
  unknown_vaults_opened[str(key)]=true
 unknown_pylon_index=clampi(int(data.get("unknown_pylon_index",0)),0,2)
 var log=data.get("unknown_messages",[])
 if log is Array:
  for entry in log.slice(0,30): unknown_messages.append(str(entry))
 unknown_pocket=bool(data.get("unknown_pocket",false))
 var ret=data.get("unknown_pocket_return",[0,0,0])
 if ret is Array and ret.size()>=3: unknown_pocket_return=Vector3(float(ret[0]),float(ret[1]),float(ret[2]))
 var p=data.get("position",[0,0,0])
 if p is Array and p.size()>=3: flight_pos=Vector3(float(p[0]),float(p[1]),float(p[2]))
 yaw=float(data.get("yaw",0));pitch=float(data.get("pitch",0));roll=float(data.get("roll",0))
 throttle=clampf(float(data.get("throttle",0)),0,1)
 engine_cutoff=bool(data.get("engine_cutoff",false))
 if engine_cutoff:
  throttle=0.0
  cruise=false
  velocity=0.0
  linear_velocity=Vector3.ZERO
 flight_assist=bool(data.get("assist",true))
 nav_assist=bool(data.get("nav_assist",false))
 chase=bool(data.get("chase",true))
 chase_distance_target=clampf(float(data.get("camera_distance",65.0)),36.0,125.0)
 camera_distance=chase_distance_target
 var saved_velocity=data.get("linear_velocity",[0,0,0])
 if saved_velocity is Array and saved_velocity.size()>=3:
  linear_velocity=Vector3(float(saved_velocity[0]),float(saved_velocity[1]),float(saved_velocity[2]))
 velocity=linear_velocity.length()
 credits=maxi(0,int(data.get("credits",5000)))
 active_mission=clampi(int(data.get("mission",0)),0,MISSIONS.size()-1)
 mission_stage=clampi(int(data.get("stage",6)),0,6)
 mission_extra_active=bool(data.get("mission_extra_active",false)) and mission_stage>=2 and mission_stage<=3 and mission_has_third_leg(active_mission)
 mission_extra_done=bool(data.get("mission_extra_done",false)) and mission_has_third_leg(active_mission)
 mission_extra_total=maxi(0,int(data.get("mission_extra_total",0)))
 encounter_done.clear()
 var loaded_encounters=data.get("encounter_done",[])
 if loaded_encounters is Array:
  for item in loaded_encounters:
   if str(item).length()<90 and not encounter_done.has(str(item)): encounter_done.append(str(item))
 encounter_scan_active=false
 encounter_scan_progress=0.0
 if int(data.get("mission_version",14))<15:
  if mission_stage==2: mission_stage=4
  elif mission_stage==3: mission_stage=6
 mission_bonus_done.clear()
 var saved_bonus=data.get("mission_bonus_done",[])
 if saved_bonus is Array:
  for key in saved_bonus:
   if not mission_bonus_done.has(str(key)): mission_bonus_done.append(str(key))
 mission_bonus_value=maxi(0,int(data.get("mission_bonus_value",0)))
 mission_journal.clear()
 var saved_journal=data.get("mission_journal",[])
 if saved_journal is Array:
  for entry in saved_journal:
   if mission_journal.size()>=32: break
   mission_journal.append(str(entry))
 mission_fails=maxi(0,int(data.get("mission_fails",0)))
 mission_retries=maxi(0,int(data.get("mission_retries",0)))
 mission_last_result=str(data.get("mission_last_result","NO COMPLETED OPERATION"))
 mission_scan_active=bool(data.get("mission_scan_active",false))
 mission_scan_charge=clampf(float(data.get("mission_scan_charge",0.0)),0.0,5.0)
 mission_escort_failed=bool(data.get("mission_escort_failed",false))
 mission_current_damage=maxf(0.0,float(data.get("mission_current_damage",0.0)))
 mission_current_retries=maxi(0,int(data.get("mission_current_retries",0)))
 mission_last_grade=str(data.get("mission_last_grade","UNRATED"))
 var grades=data.get("mission_best_grades",{})
 if grades is Dictionary:
  for k in grades.keys():
   if str(grades[k]) in ["S","A","B","C"]: mission_best_grades[str(k)]=str(grades[k])
 escort_progress=clampf(float(data.get("escort_progress",0.0)),0.0,1.0)
 escort_integrity=clampf(float(data.get("escort_integrity",100.0)),0.0,100.0)
 mission_elapsed=maxf(0.0,float(data.get("mission_elapsed",0.0)))
 mission_phase_kills=maxi(0,int(data.get("mission_phase_kills",0)))
 mission_event_spawned=bool(data.get("mission_event_spawned",false))
 mission_successes=maxi(0,int(data.get("mission_successes",0)))
 mission_chain_count=maxi(0,int(data.get("mission_chain_count",0)))
 mission_reward_bonus=maxi(0,int(data.get("mission_reward_bonus",0)))
 mission_completed.clear()
 var saved_completed=data.get("mission_completed",[])
 if saved_completed is Array:
  for index in saved_completed:
   var value=int(index)
   if value>=0 and value<MISSIONS.size() and not mission_completed.has(value): mission_completed.append(value)
 mission_kills=maxi(0,int(data.get("kills",0)))
 ship_class=clampi(int(data.get("ship_class",0)),0,SHIP_NAMES.size()-1)
 owned_ships.clear()
 var saved_hulls=data.get("owned_ships",[0])
 if saved_hulls is Array:
  for entry in saved_hulls:
   var index=clampi(int(entry),0,SHIP_NAMES.size()-1)
   if not owned_ships.has(index): owned_ships.append(index)
 if not owned_ships.has(0):owned_ships.append(0)
 if not owned_ships.has(ship_class):owned_ships.append(ship_class)
 var saved_outfit=data.get("ship_outfit",[])
 if saved_outfit is Array and saved_outfit.size()==6:
  for i in range(6): ship_outfit[i]=clampi(int(saved_outfit[i]),1,5)
 hull_module_banks.clear()
 var saved_banks=data.get("hull_module_banks",{})
 if saved_banks is Dictionary:
  for key in saved_banks.keys():
   var index=int(key)
   if index>=0 and index<SHIP_NAMES.size():
    var values=saved_banks[key]
    if values is Array and values.size()==6:
     var clean: Array[int]=[]
     for v in values: clean.append(clampi(int(v),1,5))
     hull_module_banks[str(index)]=clean
 if not hull_module_banks.has(str(ship_class)):
  hull_module_banks[str(ship_class)]=ship_outfit.duplicate()
 ship_outfit=ship_module_bank(ship_class)
 hull_conditions.clear()
 var saved_conditions=data.get("hull_conditions",{})
 if saved_conditions is Dictionary:
  for key in saved_conditions.keys():
   var values=saved_conditions[key]
   if values is Array and values.size()==2: hull_conditions[str(key)]=[maxf(0.0,float(values[0])),maxf(0.0,float(values[1]))]
 loadout_presets.clear()
 var saved_presets=data.get("loadout_presets",{})
 if saved_presets is Dictionary:
  for key in saved_presets.keys():
   var values=saved_presets[key]
   if values is Array and values.size()==5: loadout_presets[str(key)]=values.duplicate()
 formation_index=clampi(int(data.get("formation_index",0)),0,FLEET_FORMATIONS.size()-1)
 fleet_rules=clampi(int(data.get("fleet_rules",0)),0,FLEET_RULES.size()-1)
 ship_transfers=maxi(0,int(data.get("ship_transfers",0)))
 fleet_sorties=maxi(0,int(data.get("fleet_sorties",0)))
 fleet_regroups=maxi(0,int(data.get("fleet_regroups",0)))
 fleet_marked_targets=maxi(0,int(data.get("fleet_marked_targets",0)))
 fleet_repair_spending=maxi(0,int(data.get("fleet_repair_spending",0)))
 var saved_paints=data.get("ship_custom_colors",[])
 if saved_paints is Array and saved_paints.size()==5:
  for i in range(5): ship_custom_colors[i]=clampi(int(saved_paints[i]),0,4)
 fleet_order=clampi(int(data.get("fleet_order",0)),0,FLEET_ORDERS.size()-1)
 fleet_drone_owned=bool(data.get("fleet_drone_owned",false))
 fleet_drone_hp=clampf(float(data.get("fleet_drone_hp",100.0)),0.0,100.0)
 fleet_drone_active=false
 fleet_kills=maxi(0,int(data.get("fleet_kills",0)))
 fleet_service_spent=maxi(0,int(data.get("fleet_service_spent",0)))
 hull_hp=clampf(float(data.get("hull",max_hull())),0.0,max_hull());shield_hp=clampf(float(data.get("shield",max_shield())),0.0,max_shield())
 current_system=clampi(int(data.get("system",0)),0,SYSTEM_NAMES.size()-1)
 on_surface=bool(data.get("on_surface",false)) and not bool(data.get("docked",false))
 surveyed_worlds.clear()
 var saved_worlds=data.get("surveyed_worlds",[])
 if saved_worlds is Array:
  for world_index in saved_worlds:
   var index=clampi(int(world_index),0,WORLD_NAMES.size()-1)
   if not surveyed_worlds.has(index): surveyed_worlds.append(index)
 surface_flights=maxi(0,int(data.get("surface_flights",0)))
 surface_records.clear()
 var saved_surface_records=data.get("surface_records",{})
 if saved_surface_records is Dictionary:
  for record_key in saved_surface_records.keys():
   if bool(saved_surface_records[record_key]): surface_records[str(record_key)]=true
 selected_surface_site=clampi(int(data.get("selected_surface_site",0)),0,2)
 # Prior Pass 17 saves tracked a completed world, not its individual sites.
 if not data.has("surface_records"):
  for old_world in surveyed_worlds:
   for site_idx in range(3): surface_records[surface_record_key(old_world,site_idx)]=true
 surface_samples=maxi(0,int(data.get("surface_samples",0)))
 surface_scan_completed=maxi(0,int(data.get("surface_scan_completed",0)))
 world_discovery_total=maxi(0,int(data.get("world_discovery_total",0)))
 route_destination=clampi(int(data.get("route_destination",-1)),-1,SYSTEM_NAMES.size()-1)
 route_legs.clear()
 var saved_legs=data.get("route_legs",[])
 if saved_legs is Array:
  for leg in saved_legs:
   var index=clampi(int(leg),0,SYSTEM_NAMES.size()-1)
   if index!=current_system: route_legs.append(index)
 visited_sectors.clear()
 var saved_visited=data.get("visited_sectors",[0])
 if saved_visited is Array:
  for v in saved_visited:
   var index=clampi(int(v),0,SYSTEM_NAMES.size()-1)
   if not visited_sectors.has(index): visited_sectors.append(index)
 if not visited_sectors.has(current_system): visited_sectors.append(current_system)
 charted_sectors.clear()
 var saved_charted=data.get("charted_sectors",[0])
 if saved_charted is Array:
  for v in saved_charted:
   var index=clampi(int(v),0,SYSTEM_NAMES.size()-1)
   if not charted_sectors.has(index): charted_sectors.append(index)
 nav_target=9 if int(data.get("nav_target",0))==9 else clampi(int(data.get("nav_target",0)),0,3)
 if not data.has("visited_sectors") and current_system>0:
  # Earlier saves shared one world coordinate space; move safely to new sector.
  flight_pos=SECTOR_ORIGINS[current_system]+Vector3(0,0,950)
  linear_velocity=Vector3.ZERO
  throttle=0.0
 jump_target=clampi(int(data.get("target",1)),0,SYSTEM_NAMES.size()-1)
 docked=bool(data.get("docked",false))
 if docked: on_surface=false
 clearance_granted=bool(data.get("clearance",false))
 dock_count=maxi(0,int(data.get("dock_count",0)))
 ship_service_count=maxi(0,int(data.get("service_count",0)))
 fuel=clampf(float(data.get("fuel",100.0)),0.0,100.0)
 cargo_units=maxi(0,int(data.get("cargo_units",0)))
 missile_ammo=clampi(int(data.get("missile_ammo",12)),0,12)
 target_subsystem=clampi(int(data.get("target_subsystem",0)),0,subsystem_names.size()-1)
 weapon_mode=clampi(int(data.get("weapon_mode",0)),0,WEAPON_NAMES.size()-1)
 weapon_heat=clampf(float(data.get("weapon_heat",0.0)),0.0,100.0)
 shield_power=clampi(int(data.get("shield_power",1)),0,2)
 var p36_saved: Array = data.get("p36_pips",[2,2,2])
 if p36_saved.size()==3 and int(p36_saved[0])+int(p36_saved[1])+int(p36_saved[2])==6:
  p36_power_engines=clampi(int(p36_saved[0]),0,4)
  p36_power_weapons=clampi(int(p36_saved[1]),0,4)
  p36_power_shields=clampi(int(p36_saved[2]),0,4)
 wingman_hp=clampf(float(data.get("wingman_hp",100.0)),0.0,100.0)
 wingman_active=false # Deploy after loading; do not spawn an invisible stale drone.
 tractor_active=bool(data.get("tractor_active",false))
 bounty_round=maxi(0,int(data.get("bounty_round",0)))
 bounty_active=bool(data.get("bounty_active",false))
 combat_kills=maxi(0,int(data.get("combat_kills",0)))
 combat_damage_dealt=maxf(0.0,float(data.get("combat_damage_dealt",0.0)))
 combat_damage_taken=maxf(0.0,float(data.get("combat_damage_taken",0.0)))
 combat_missiles_fired=maxi(0,int(data.get("combat_missiles_fired",0)))
 combat_bounties_completed=maxi(0,int(data.get("combat_bounties_completed",0)))
 var saved_salvage=data.get("salvage_inventory",{})
 if saved_salvage is Dictionary:
  for resource in salvage_inventory.keys(): salvage_inventory[resource]=maxi(0,int(saved_salvage.get(resource,0)))
 var j=data.get("station_job",{})
 if j is Dictionary and not j.is_empty():
  var g=j.get("goal",[])
  if g is Array and g.size()>=3:
   station_job={"name":str(j.get("name","Contract")),"reward":int(j.get("reward",0)),"complete":bool(j.get("complete",false)),"kind":str(j.get("kind","cargo")),"goal":Vector3(float(g[0]),float(g[1]),float(g[2]))}
 var saved_enemy_data=data.get("enemy_state",[])
 if saved_enemy_data is Array: restored_enemy_state=saved_enemy_data
 var saved_upgrades=data.get("upgrades",{})
 if saved_upgrades is Dictionary:
  for k in upgrades.keys(): upgrades[k]=clampi(int(saved_upgrades.get(k,1)),1,5)
 var saved_codex=data.get("codex",[])
 if saved_codex is Array:
  for c in saved_codex:
   if not codex.has(str(c)): codex.append(str(c))
 var saved_contacts=data.get("contacts",[])
 if saved_contacts is Array:
  for c in saved_contacts:
   if not c is Dictionary: continue
   var cp=c.get("position",[])
   if cp is Array and cp.size()>=3: contacts.append({"name":str(c.get("name","UNKNOWN")),"position":Vector3(float(cp[0]),float(cp[1]),float(cp[2])),"found":bool(c.get("found",false))})
 hull_hp=clampf(hull_hp,0.0,max_hull())
 shield_hp=clampf(shield_hp,0.0,max_shield())
 store_current_hull()
 player.rotation=Vector3(pitch,yaw,roll)
 player.position=flight_pos
# PASS 14 — true separated sectors, charting and connected-route navigation.
func create_jump_streaks() -> void:
 for i in range(32):
  var streak=tube(camera,Vector3.ZERO,0.22,24.0,COLORS.glow,2.4)
  streak.rotation.x=PI/2.0
  streak.visible=false
  jump_streaks.append(streak)

func update_jump_streaks(dt: float) -> void:
 var active=jump_timer>0.0 or world_transition>0.0
 for i in range(jump_streaks.size()):
  var streak=jump_streaks[i]
  streak.visible=active
  if not active: continue
  var angle=TAU*float(i)/float(jump_streaks.size())
  var radius=7.0+float(i%6)*3.4
  var progress=fposmod(world_time*150.0+float(i)*41.0,400.0)
  streak.position=Vector3(cos(angle)*radius,sin(angle)*radius,-55.0-progress)
  streak.scale=Vector3(1.0,1.0,1.0+sin(world_time*5.0)*0.1)

func jump_fuel_cost(a: int, b: int) -> int:
 return 8+int(SECTOR_ORIGINS[a].distance_to(SECTOR_ORIGINS[b])/28000.0)

func plot_route(destination: int, close_after: bool=true) -> void:
 destination=clampi(destination,0,SYSTEM_NAMES.size()-1)
 if destination==current_system:
  route_destination=-1
  route_legs.clear()
  announce("ALREADY IN "+SYSTEM_NAMES[current_system])
  if close_after: close_menu()
  return
 # Dijkstra using fuel as weight, guaranteeing connected hops.
 var costs=[]
 var previous=[]
 var checked=[]
 for i in range(SYSTEM_NAMES.size()):
  costs.append(999999)
  previous.append(-1)
  checked.append(false)
 costs[current_system]=0
 for step in range(SYSTEM_NAMES.size()):
  var u=-1
  for i in range(SYSTEM_NAMES.size()):
   if not checked[i] and (u<0 or costs[i]<costs[u]): u=i
  if u<0 or costs[u]>=999999: break
  checked[u]=true
  for raw_neighbor in SECTOR_LINKS[u]:
   var v: int=int(raw_neighbor)
   var proposed=int(costs[u])+jump_fuel_cost(u,v)
   if proposed<int(costs[v]):
    costs[v]=proposed
    previous[v]=u
 var reversed_path: Array[int]=[]
 var node=destination
 while node!=current_system and node>=0:
  reversed_path.append(node)
  node=int(previous[node])
 if node!=current_system:
  announce("NO CONNECTED ROUTE TO "+SYSTEM_NAMES[destination])
  return
 route_legs.clear()
 for i in range(reversed_path.size()-1,-1,-1): route_legs.append(reversed_path[i])
 route_destination=destination
 jump_target=route_legs[0]
 announce("ROUTE PLOTTED: %d HOPS / %d FUEL — %s" % [route_legs.size(),int(costs[destination]),SYSTEM_NAMES[destination]])
 if close_after: close_menu()
 save_game()

func route_names() -> PackedStringArray:
 var result=PackedStringArray()
 for i in route_legs: result.append(SYSTEM_NAMES[i])
 return result

func nav_target_name() -> String:
 if nav_target==9 and is_instance_valid(living_galaxy): return living_galaxy.goal_name()
 match nav_target:
  0: return "MISSION / HOME" if mission_stage>=4 else ("MISSION OBJECTIVE 3" if mission_extra_active else ("MISSION OBJECTIVE 2" if mission_stage>=2 else "MISSION OBJECTIVE 1"))
  1: return "LOCAL STATION"
  2: return "NEXT JUMP / STATION"
  3: return "PLANET / "+WORLD_NAMES[current_system]
  _: return "UNKNOWN"

func nav_waypoint() -> Vector3:
 if nav_target==9 and is_instance_valid(living_galaxy): return living_galaxy.waypoint()
 if nav_target==1: return station_position
 if nav_target==2: return station_position+Vector3(0,0,1100)
 if nav_target==3: return world_orbit_position+Vector3(0,0,1900.0 if current_system!=4 else 2250.0)
 if mission_stage>=6: return station_position
 return mission_objective_position()

func scan_sector() -> void:
 if jump_timer>0.0 or docked: announce("SCANNER UNAVAILABLE DURING DOCKING OR JUMP");return
 if scan_cooldown>0.0: announce("SCANNER RECHARGING: %d SEC" % int(ceilf(scan_cooldown)));return
 scan_cooldown=maxf(5.0,15.0-float(ship_outfit[5]-1)*2.0)
 scan_results="%s / %s" % [SYSTEM_NAMES[current_system],SECTOR_DESCRIPTIONS[current_system]]
 if not charted_sectors.has(current_system): charted_sectors.append(current_system)
 var discovery="SURVEY: "+SYSTEM_NAMES[current_system]
 if not codex.has(discovery):
  codex.append(discovery)
  credits+=450
  announce("SYSTEM CHARTED — "+SYSTEM_NAMES[current_system]+" / +450 CR")
 else: announce("SECTOR SCAN COMPLETE — "+SECTOR_DESCRIPTIONS[current_system])
 save_game()

func setup_sector(which: int) -> void:
 # The large, decorative bodies are regenerated only on jumps, not every frame.
 if sector_scenery!=null:
  sector_scenery.queue_free()
 sector_scenery=Node3D.new()
 sector_scenery.name="SectorLandmarks"
 add_child(sector_scenery)
 var origin: Vector3=SECTOR_ORIGINS[which]
 station_position=origin+Vector3(-700,80,-1700)
 station_pad=station_position+Vector3(0,-125,145)
 station.position=station_position
 if gate!=null: gate.position=origin+Vector3(5200,300,-11700)
 station.name=station_names[which].replace(" ","_")
 # Distinct environmental silhouettes and colors for each sector.
 var hue: Color=SYSTEM_TINTS[which]
 var planet=ball(sector_scenery,origin+Vector3(5600,-2500,-8700),1100.0 if which!=4 else 1450.0,hue.lightened(0.15),0.16,32)
 world_planet=planet
 world_orbit_position=planet.global_position
 world_surface_center=world_orbit_position+Vector3(0,1850.0 if which==4 else 1450.0,0)
 planet.scale=Vector3(1.0,0.92,1.0)
 if which==1 or which==4:
  var ring=torus(sector_scenery,origin+Vector3(5600,-2500,-8700),1400,1660,hue.lightened(0.28),0.1)
  ring.rotation=Vector3(0.4,0.1,0.6)
 for i in range(14):
  var angle=float(i)*TAU/14.0
  var distance=3200.0+float(i%4)*580.0
  var pos=origin+Vector3(cos(angle)*distance,sin(angle*2.0)*420.0,-5800.0+sin(angle)*distance)
  var asteroid=ball(sector_scenery,pos,55.0+float(i%5)*26.0,hue.darkened(0.42),0.0,8)
  asteroid.scale=Vector3(1.5,0.6,1.0)
 if which==2 or which==5:
  for i in range(5):
   var p=origin+Vector3(-2200+i*530,-200,-5900+i*250)
   var crystal=tube(sector_scenery,p,50,700,hue.lightened(0.3),0.65)
   crystal.rotation.z=0.5+float(i)*0.25
 if which==3 or which==6:
  var arch=torus(sector_scenery,origin+Vector3(4000,200,-7800),700,790,hue.lightened(0.35),0.8)
  arch.rotation.x=PI/2.0
  ball(sector_scenery,origin+Vector3(4000,200,-7800),140,hue.lightened(0.4),1.5,16)
 if which==6:
  for i in range(3):
   var p=origin+Vector3(-1800+i*1600,400,-7200)
   tube(sector_scenery,p,145,1300,Color(0.22,0.28,0.39))
   ball(sector_scenery,p+Vector3(0,800,0),180,hue,0.45)
 build_world_surface(which)
 build_unknown_sites(which)
 if is_instance_valid(pass21_visuals): pass21_visuals.refresh_sector(which)
 if is_instance_valid(pass22_visuals): pass22_visuals.refresh_sector(which)
 # The original Gods Command model remains available, now representing the local port.
 # No heavy procedural generation runs during flight.


# PASS 17: one terrain tile per visited sector, rebuilt only on sector changes.
func set_planetary_waypoint() -> void:
 nav_target=3
 announce("PLANETARY APPROACH PLOTTED — "+WORLD_NAMES[current_system])
 close_menu()

func world_ground_sky() -> Color:
 return WORLD_GROUND[current_system].darkened(0.64)

func terrain_height(x: float, z: float, world_index: int) -> float:
 var radial=clampf(Vector2(x,z).length()/200.0,0.0,1.0)
 var base=sin(x*0.008+float(world_index)*1.4)*cos(z*0.009)*24.0
 base+=sin(x*0.022-z*0.012)*11.0+cos(z*0.027+x*0.014)*7.0
 if world_index==1: base+=sin(x*0.003)*26.0
 if world_index==4: base+=absf(sin(x*0.017)*cos(z*0.017))*40.0
 return base*radial

func build_world_surface(world_index: int) -> void:
 if is_instance_valid(world_surface): world_surface.queue_free()
 surface_site_nodes.clear()
 world_surface=Node3D.new()
 world_surface.name="WorldSurface_"+WORLD_NAMES[world_index].replace(" ","_")
 world_surface.position=world_surface_center
 add_child(world_surface)
 var verts=PackedVector3Array()
 var divisions=38
 var extent=1250.0
 var step=extent*2.0/float(divisions)
 for z in range(divisions):
  for x in range(divisions):
   var x0=-extent+float(x)*step
   var x1=x0+step
   var z0=-extent+float(z)*step
   var z1=z0+step
   var a=Vector3(x0,terrain_height(x0,z0,world_index),z0)
   var b=Vector3(x1,terrain_height(x1,z0,world_index),z0)
   var c=Vector3(x1,terrain_height(x1,z1,world_index),z1)
   var d=Vector3(x0,terrain_height(x0,z1,world_index),z1)
   verts.append_array(PackedVector3Array([a,c,b,a,d,c]))
 triangle_mesh(world_surface,verts,WORLD_GROUND[world_index])
 var accent=WORLD_ACCENTS[world_index]
 # Landmark silhouettes vary by world; only ~30 lightweight objects per landing zone.
 for i in range(28):
  var theta=float(i)*2.39996+float(world_index)
  var distance=260.0+float((i*97)%760)
  var px=cos(theta)*distance
  var pz=sin(theta)*distance
  var ground=terrain_height(px,pz,world_index)
  if world_index==1:
   var ice=tube(world_surface,Vector3(px,ground+50.0,pz),8.0+float(i%5)*5.0,100.0+float(i%4)*34.0,accent,0.24)
   ice.rotation.z=0.14*float(i%3)
  elif world_index==2 or world_index==5:
   var crystal=tube(world_surface,Vector3(px,ground+60.0,pz),15.0,120.0+float(i%5)*26.0,accent,0.95)
   crystal.rotation.z=0.18*float(i%5)
   ball(world_surface,Vector3(px,ground+150.0,pz),12.0,accent,1.4,8)
  elif world_index==3:
   tube(world_surface,Vector3(px,ground+42.0,pz),12.0,85.0,WORLD_GROUND[world_index].lightened(0.2))
   ball(world_surface,Vector3(px,ground+90.0,pz),32.0,accent,0.8,8)
  elif world_index==4:
   var vent=tube(world_surface,Vector3(px,ground+25.0,pz),19.0,50.0,Color(0.17,0.13,0.14))
   ball(world_surface,Vector3(px,ground+60.0,pz),13.0,accent,1.8,8)
  elif world_index==6:
   tube(world_surface,Vector3(px,ground+95.0,pz),24.0,190.0,WORLD_GROUND[world_index].lightened(0.23))
   ball(world_surface,Vector3(px,ground+200.0,pz),16.0,accent,1.2,8)
  else:
   var reef=ball(world_surface,Vector3(px,ground+25.0,pz),23.0+float(i%4)*8.0,accent.darkened(0.28),0.2,8)
   reef.scale=Vector3(0.65,1.9,0.75)
 # Three actual survey installations, spaced across the terrain.
 for site_idx in range(3):
  var site_pos=SURVEY_SITE_OFFSETS[site_idx]
  var ground_y=terrain_height(site_pos.x,site_pos.z,world_index)
  var site=Node3D.new()
  site.name="SurveySite_"+str(site_idx)
  site.position=Vector3(site_pos.x,ground_y,site_pos.z)
  world_surface.add_child(site)
  surface_site_nodes.append(site)
  var site_color=accent if not surface_records.has(surface_record_key(world_index,site_idx)) else Color(0.20,0.85,0.35)
  torus(site,Vector3(0,8,0),60.0,68.0,site_color,1.2)
  tube(site,Vector3(0,34,0),7.0,65.0,site_color.darkened(0.4),0.4)
  ball(site,Vector3(0,75,0),13.0,site_color,1.8,12)
  for beacon_idx in range(4):
   var angle=TAU*float(beacon_idx)/4.0
   ball(site,Vector3(cos(angle)*78.0,13.0,sin(angle)*78.0),5.0,site_color,1.2,8)
 world_surface.visible=on_surface
 if is_instance_valid(sector_scenery): sector_scenery.visible=not on_surface

func toggle_planet_approach() -> void:
 if unknown_pocket:
  announce("LEAVE THE ANCIENT SANCTUARY BEFORE PLANETARY APPROACH")
  return
 if docked or landing_timer>0.0 or launch_timer>0.0 or jump_timer>0.0 or world_transition>0.0:
  announce("PLANETARY CONTROL UNAVAILABLE DURING DOCKING OR FRAME SHIFT")
  return
 if not on_surface and flight_pos.distance_to(world_orbit_position)>2700.0:
  announce("APPROACH %s TO WITHIN 2700 M / CURRENT %d M" % [WORLD_NAMES[current_system],int(flight_pos.distance_to(world_orbit_position))])
  return
 world_transition_to_surface=not on_surface
 surface_scan_site=-1
 surface_scan_time=0.0
 world_transition=3.2
 throttle=0.0
 cruise=false
 linear_velocity=Vector3.ZERO
 close_menu()
 announce("ATMOSPHERIC DESCENT" if world_transition_to_surface else "ASCENT TO ORBIT")

func complete_world_transition() -> void:
 on_surface=world_transition_to_surface
 throttle=0.0
 velocity=0.0
 linear_velocity=Vector3.ZERO
 cruise=false
 yaw=0.0
 pitch=-0.10 if on_surface else 0.0
 roll=0.0
 if on_surface:
  flight_pos=world_surface_center+Vector3(0,90,230)
  surface_flights+=1
  selected_surface_site=0
  announce("SURFACE ENTRY — %s / 4 CHOOSE SITE / 2 SCAN" % WORLD_NAMES[current_system])
 else:
  flight_pos=world_orbit_position+Vector3(0,0,1900.0 if current_system!=4 else 2250.0)
  announce("ORBIT RESTORED — %s" % WORLD_NAMES[current_system])
 if is_instance_valid(world_surface): world_surface.visible=on_surface
 if is_instance_valid(sector_scenery): sector_scenery.visible=not on_surface
 save_game()

func restore_surface_position() -> void:
 if not is_instance_valid(world_surface): return
 world_surface.visible=true
 if is_instance_valid(sector_scenery): sector_scenery.visible=false
 var relative=flight_pos-world_surface_center
 if absf(relative.x)>1180.0 or absf(relative.z)>1180.0 or relative.y<15.0 or relative.y>1200.0:
  flight_pos=world_surface_center+Vector3(0,90,230)
 linear_velocity=Vector3.ZERO
 throttle=0.0

func constrain_surface_flight() -> void:
 var offset=flight_pos-world_surface_center
 offset.x=clampf(offset.x,-1190.0,1190.0)
 offset.z=clampf(offset.z,-1190.0,1190.0)
 var ground=terrain_height(offset.x,offset.z,current_system)
 offset.y=clampf(offset.y,ground+24.0,420.0)
 flight_pos=world_surface_center+offset
 linear_velocity=linear_velocity.limit_length(190.0)
 velocity=minf(velocity,190.0)

# PASS 17B — persistent multi-site expeditions.
func surface_record_key(sector: int, site: int) -> String:
 return str(sector)+":"+str(site)

func surface_site_position(site: int) -> Vector3:
 var local=SURVEY_SITE_OFFSETS[clampi(site,0,2)]
 return world_surface_center+Vector3(local.x,terrain_height(local.x,local.z,current_system)+70.0,local.z)

func cycle_surface_site() -> void:
 if not on_surface:
  announce("DESCEND BEFORE SELECTING A SURVEY SITE")
  return
 selected_surface_site=(selected_surface_site+1)%3
 surface_scan_site=-1
 surface_scan_time=0.0
 var distance=int(flight_pos.distance_to(surface_site_position(selected_surface_site)))
 announce("SITE %d / %s / %d M" % [selected_surface_site+1,SURVEY_SITE_NAMES[selected_surface_site],distance])
 close_menu()

func survey_planet() -> void:
 if not on_surface or world_transition>0.0 or docked:
  announce("SURVEY REQUIRES PLANETARY SURFACE FLIGHT")
  return
 if surface_scan_site>=0:
  announce("SCAN IN PROGRESS — HOLD NEAR SITE")
  return
 var key=surface_record_key(current_system,selected_surface_site)
 if surface_records.has(key):
  announce("SITE ALREADY CHARTED — PRESS 4 TO SELECT ANOTHER")
  return
 var distance=flight_pos.distance_to(surface_site_position(selected_surface_site))
 if distance>180.0:
  announce("APPROACH %s / %d M / SCAN RANGE 180 M" % [SURVEY_SITE_NAMES[selected_surface_site],int(distance)])
  return
 surface_scan_site=selected_surface_site
 surface_scan_time=0.0
 announce("GEOLOGICAL SCAN STARTED — MAINTAIN POSITION FOR 4 SECONDS")
 close_menu()

func update_surface_expedition(dt: float) -> void:
 if surface_scan_site>=0:
  if flight_pos.distance_to(surface_site_position(surface_scan_site))>205.0:
   surface_scan_site=-1
   surface_scan_time=0.0
   announce("SCAN INTERRUPTED — SITE OUT OF RANGE")
  else:
   surface_scan_time+=dt
   if surface_scan_time>=4.0:
    complete_surface_scan(surface_scan_site)
    surface_scan_site=-1
    surface_scan_time=0.0
 surface_hazard_time+=dt
 surface_hazard_alert=maxf(0.0,surface_hazard_alert-dt)
 # Environment-specific turbulence: slight, visible and bounded, no repeated heavy meshes.
 if current_system==4 or current_system==5 or current_system==2:
  if surface_hazard_time>=7.0:
   surface_hazard_time=0.0
   if flight_pos.distance_to(surface_site_position(selected_surface_site))>210.0:
    shield_hp=maxf(0.0,shield_hp-2.0)
    if surface_hazard_alert<=0.0:
     announce("ATMOSPHERIC INTERFERENCE — -2 SHIELDS / SURVEY BEACONS OFFER SHELTER")
     surface_hazard_alert=10.0

func complete_surface_scan(site: int) -> void:
 var key=surface_record_key(current_system,site)
 if surface_records.has(key): return
 surface_records[key]=true
 surface_scan_completed+=1
 surface_samples+=1
 var reward=450+current_system*110+site*175
 credits+=reward
 world_discovery_total+=reward
 var discovery="%s: %s" % [WORLD_NAMES[current_system],SURVEY_SITE_NAMES[site]]
 if not codex.has(discovery): codex.append(discovery)
 var count=0
 for i in range(3):
  if surface_records.has(surface_record_key(current_system,i)): count+=1
 if count==3 and not surveyed_worlds.has(current_system):
  surveyed_worlds.append(current_system)
  var completion_bonus=1200+current_system*300
  credits+=completion_bonus
  world_discovery_total+=completion_bonus
  var full_discovery="PLANETARY SURVEY: "+WORLD_NAMES[current_system]
  if not codex.has(full_discovery): codex.append(full_discovery)
  announce("WORLD FULLY CHARTED — %s / +%d CR" % [WORLD_NAMES[current_system],reward+completion_bonus])
 else:
  announce("SITE %d/3 CHARTED — +%d CR / PRESS 4 FOR NEXT" % [count,reward])
 # Mark the scanned beacon green without regenerating the terrain.
 if site<surface_site_nodes.size() and is_instance_valid(surface_site_nodes[site]):
  var marker=ball(surface_site_nodes[site],Vector3(0,95,0),9.0,Color(0.2,1.0,0.35),1.8,8)
  marker.name="SurveyCompleteMarker"
 save_game()


# PASS 18: Each sector has two distinct handcrafted-style procedural mystery sites.
# Everything is created on sector entry and removed on departure; no giant city meshes.
func unknown_site_position(sector_id: int, index: int) -> Vector3:
 var a=float(sector_id)*0.61+float(index)*2.45
 return SECTOR_ORIGINS[sector_id]+Vector3(-7900.0+cos(a)*3100.0,420.0+float(index)*260.0,-11800.0+sin(a)*3500.0-float(index)*2100.0)

func build_unknown_sites(sector_id: int) -> void:
 if is_instance_valid(unknown_root): unknown_root.queue_free()
 unknown_rare_node=null
 unknown_scanning=false
 unknown_scan_progress=0.0
 unknown_root=Node3D.new()
 unknown_root.name="TheUnknown_SectorMysteries"
 add_child(unknown_root)
 unknown_sites.clear()
 unknown_nodes.clear()
 unknown_pylon_nodes.clear()
 unknown_selected=clampi(unknown_selected,0,1)
 for i in range(2):
  var kind_index=(sector_id+i*3)%UNKNOWN_NAMES.size()
  var position=unknown_site_position(sector_id,i)
  var record_key="%d:%d" % [sector_id,i]
  var record={"key":record_key,"name":UNKNOWN_NAMES[kind_index],"kind":UNKNOWN_TYPES[kind_index],"position":position,"description":UNKNOWN_DESCRIPTIONS[kind_index]}
  unknown_sites.append(record)
  var visual=Node3D.new()
  visual.name="Mystery_"+str(kind_index)
  visual.position=position
  unknown_root.add_child(visual)
  build_unknown_art(visual,kind_index,unknown_records.has(record_key))
  if unknown_records.has(record_key) and not unknown_artifacts.has(record_key):
   ball(visual,Vector3(0,120,0),28.0,Color(1.0,0.74,0.20),2.4,12)
  unknown_nodes.append(visual)
 if is_instance_valid(unknown_pocket_root): unknown_pocket_root.queue_free()
 unknown_pocket_root=Node3D.new()
 unknown_pocket_root.name="Sanctuary_Pocket"
 unknown_pocket_root.position=SECTOR_ORIGINS[sector_id]+Vector3(-18000,3200,-26000)
 unknown_root.add_child(unknown_pocket_root)
 var outer_ring=torus(unknown_pocket_root,Vector3.ZERO,650,715,Color(0.30,0.76,1.0),1.6)
 outer_ring.rotation.x=PI/2.0
 var inner_ring=torus(unknown_pocket_root,Vector3.ZERO,410,430,Color(0.85,0.35,1.0),1.4)
 inner_ring.rotation.y=PI/3.0
 for i in range(12):
  var angle=TAU*float(i)/12.0
  var p=Vector3(cos(angle)*1080,0,sin(angle)*1080)
  tube(unknown_pocket_root,p,50,740,Color(0.16,0.22,0.38))
  ball(unknown_pocket_root,p+Vector3(0,410,0),105,Color(0.34,0.84,1.0),1.5,12)
 ball(unknown_pocket_root,Vector3.ZERO,230,Color(0.72,0.24,0.95),2.8,20)
 # Three resonant pylons form an actual fly-to-and-activate vault sequence.
 for i in range(3):
  var angle=TAU*float(i)/3.0
  var pylon=Node3D.new()
  pylon.name="VaultResonator_"+str(i+1)
  pylon.position=Vector3(cos(angle)*750.0,0,sin(angle)*750.0)
  unknown_pocket_root.add_child(pylon)
  tube(pylon,Vector3.ZERO,38,300,Color(0.14,0.22,0.35))
  var glow=Color(0.18,0.92,0.44) if unknown_sanctuary_keys.has(str(i)) else Color(1.0,0.60,0.15)
  ball(pylon,Vector3(0,180,0),65,glow,2.0,12)
  unknown_pylon_nodes.append(pylon)
 unknown_pocket_root.visible=unknown_pocket

func build_unknown_art(root_node: Node3D, kind_index: int, completed: bool) -> void:
 var dark=Color(0.12,0.19,0.29)
 var light=Color(0.24,0.82,0.94) if not completed else Color(0.35,0.95,0.50)
 match kind_index:
  0: # colossal derelict ship with fractured ribs and broken engines
   var hull=cube(root_node,Vector3.ZERO,Vector3(260,100,760),dark)
   hull.rotation.y=0.22
   for side in [-1.0,1.0]:
    var wing=cube(root_node,Vector3(side*220,-12,50),Vector3(370,25,280),Color(0.19,0.26,0.35))
    wing.rotation.y=side*0.30
    var engine=tube(root_node,Vector3(side*95,-20,350),55,190,light,0.5)
    engine.rotation.x=PI/2.0
   ball(root_node,Vector3(0,75,-250),75,light,0.9,16)
  1: # giant signal mast, crossed transmitters
   tube(root_node,Vector3.ZERO,65,840,dark)
   for h in range(4):
    var dish=torus(root_node,Vector3(0,-320+h*210,0),160+h*20,170+h*20,light,1.1)
    dish.rotation.x=PI/2.0
   ball(root_node,Vector3(0,440,0),90,light,2.1,16)
  2: # monolith choir
   for i in range(7):
    var angle=TAU*float(i)/7.0
    var monolith=cube(root_node,Vector3(cos(angle)*270,0,sin(angle)*270),Vector3(75,440+float(i%3)*125,85),dark)
    monolith.rotation.y=angle
    ball(root_node,monolith.position+Vector3(0,240+float(i%3)*62,0),25,light,1.4,10)
  3: # fractured concentric halos
   for i in range(3):
    var ring=torus(root_node,Vector3.ZERO,380+float(i)*135,405+float(i)*135,light,1.2)
    ring.rotation=Vector3(0.5+float(i)*0.4,0.3,float(i)*0.7)
   ball(root_node,Vector3.ZERO,100,Color(0.45,0.12,0.8),2.0,16)
  4: # stylized leviathan with arched spine and fins
   for i in range(11):
    var z=-500+float(i)*100
    var height=sin(float(i)*PI/10.0)*190
    ball(root_node,Vector3(0,height,z),95+sin(float(i)*PI/10.0)*50,dark,0.0,10)
    for side in [-1.0,1.0]:
     var fin=cube(root_node,Vector3(side*(130+height*.2),height,z),Vector3(210,20,45),light.darkened(.35))
     fin.rotation.z=side*0.4
   ball(root_node,Vector3(0,40,-500),60,light,2.0,12)
  5: # vault with luminous archive pylons
   cube(root_node,Vector3.ZERO,Vector3(560,320,480),dark)
   for x in [-240.0,240.0]:
    for z in [-200.0,200.0]:
     tube(root_node,Vector3(x,250,z),38,340,light,0.8)
   var archive_ring=torus(root_node,Vector3(0,190,0),195,215,light,1.4)
   archive_ring.rotation.x=PI/2.0
  6: # light-bending rift
   for i in range(5):
    var ring=torus(root_node,Vector3.ZERO,240+float(i)*120,255+float(i)*120,light,1.5)
    ring.rotation=Vector3(PI/2.0+float(i)*0.08,float(i)*0.25,0)
   ball(root_node,Vector3.ZERO,140,Color(0.76,0.18,0.93),2.5,16)
 ball(root_node,Vector3(0,600,0),30,light,2.2,12)

func select_unknown_site(index: int) -> void:
 unknown_selected=clampi(index,0,maxi(0,unknown_sites.size()-1))
 unknown_scanning=false
 unknown_scan_key=""
 unknown_scan_progress=0.0
 if not unknown_sites.is_empty():
  var record=unknown_sites[unknown_selected]
  announce("SIGNAL LOCK: "+str(record["name"])+" / "+str(int(flight_pos.distance_to(record["position"])))+" M")
 close_menu()

func cycle_unknown_site() -> void:
 if unknown_sites.is_empty(): return
 select_unknown_site((unknown_selected+1)%unknown_sites.size())

func investigate_unknown() -> void:
 if docked or on_surface or jump_timer>0.0 or unknown_pocket or world_transition>0.0:
  announce("DEEP SIGNAL SCAN REQUIRES OPEN SPACE")
  return
 if unknown_sites.is_empty(): return
 var best_index=-1
 var best_distance=550.0
 for i in range(unknown_sites.size()):
  var distance=flight_pos.distance_to(unknown_sites[i]["position"])
  if distance<best_distance and not unknown_records.has(str(unknown_sites[i]["key"])):
   best_index=i
   best_distance=distance
 if is_instance_valid(unknown_rare_node) and flight_pos.distance_to(unknown_rare_pos)<550.0 and not unknown_records.has(unknown_rare_record):
  best_index=-2
 if best_index==-1:
  announce("NO UNRESOLVED SIGNAL WITHIN 550 M / PRESS 5 TO PLOT")
  return
 unknown_selected=best_index if best_index>=0 else unknown_selected
 unknown_scan_key=unknown_rare_record if best_index==-2 else str(unknown_sites[best_index]["key"])
 unknown_scan_position=unknown_rare_pos if best_index==-2 else unknown_sites[best_index]["position"]
 unknown_scanning=true
 unknown_scan_progress=0.0
 unknown_stability=100.0
 announce("DEEP SIGNAL ANALYSIS STARTED — HOLD POSITION FIVE SECONDS")
 close_menu()

func update_unknown(dt: float) -> void:
 if unknown_pocket_root!=null:
  unknown_pocket_root.visible=unknown_pocket
  unknown_pocket_root.rotation.y+=dt*0.04
 for i in range(unknown_nodes.size()):
  if is_instance_valid(unknown_nodes[i]):
   unknown_nodes[i].rotation.y+=dt*(0.006+float(i)*0.004)
 if unknown_scanning:
  # The lock cannot switch from a normal site to a wandering echo mid-scan.
  var scan_distance=flight_pos.distance_to(unknown_scan_position)
  if docked or on_surface or jump_timer>0.0 or scan_distance>550.0 or unknown_records.has(unknown_scan_key):
   unknown_scanning=false
   unknown_scan_progress=0.0
   unknown_scan_key=""
   announce("SIGNAL LOCK LOST — RETURN WITHIN 550 M")
  else:
   # Deep-space interference slows progress near the most unstable signals.
   var hazard=0.35 if (current_system==3 or current_system==5) else 0.0
   unknown_interference=hazard
   unknown_stability=clampf(unknown_stability-dt*hazard*5.0,25.0,100.0)
   unknown_scan_progress+=dt*(1.0-hazard*0.45)
   if unknown_scan_progress>=5.0:
    unknown_scanning=false
    unknown_scan_progress=0.0
    var completed_key=unknown_scan_key
    unknown_scan_key=""
    if completed_key.begins_with("rare:"):
     finish_unknown_discovery(completed_key,"WANDERING ECHO",true)
     if is_instance_valid(unknown_rare_node): unknown_rare_node.queue_free()
     unknown_rare_time=0.0
    else:
     var record=unknown_sites[unknown_selected]
     finish_unknown_discovery(completed_key,str(record["name"]),false)
     # Recovered artifacts remain at the resolved site until collected.
     if is_instance_valid(unknown_nodes[unknown_selected]):
      ball(unknown_nodes[unknown_selected],Vector3(0,120,0),28.0,Color(1.0,0.74,0.20),2.4,12)
 if is_instance_valid(unknown_rare_node):
  unknown_rare_time-=dt
  unknown_rare_node.rotation.y+=dt*.16
  if unknown_rare_time<=0.0:
   unknown_rare_node.queue_free()
   unknown_rare_time=0.0
 elif not docked and not on_surface and jump_timer<=0.0 and not unknown_pocket and not menu_open:
  unknown_rare_timer-=dt
  if unknown_rare_timer<=0.0:
   unknown_rare_timer=105.0+float((current_system*17+unknown_rare_serial*13)%55)
   spawn_rare_unknown()

func spawn_rare_unknown() -> void:
 if unknown_root==null: return
 unknown_rare_serial+=1
 unknown_rare_record="rare:%d:%d" % [current_system,unknown_rare_serial]
 unknown_rare_pos=flight_pos+Basis.from_euler(Vector3(pitch,yaw,roll))*Vector3(800.0,-80.0,-1600.0)
 unknown_rare_node=Node3D.new()
 unknown_rare_node.name="Wandering_Unknown_Echo"
 unknown_rare_node.position=unknown_rare_pos
 unknown_root.add_child(unknown_rare_node)
 for i in range(3):
  var ring=torus(unknown_rare_node,Vector3.ZERO,130+float(i)*75,140+float(i)*75,Color(.45,.76,1.0),1.8)
  ring.rotation=Vector3(float(i)*.7,PI/2.0,float(i)*.8)
 ball(unknown_rare_node,Vector3.ZERO,70,Color(.72,.32,1.0),2.5,16)
 unknown_rare_time=105.0
 announce("UNCLASSIFIED WANDERING ECHO DETECTED / PRESS 6 WITHIN 550 M")

func finish_unknown_discovery(record_key: String, name: String, rare: bool) -> void:
 if unknown_records.has(record_key): return
 unknown_records[record_key]=true
 unknown_discoveries+=1
 var reward=1800+current_system*400+(1400 if rare else 0)
 credits+=reward
 unknown_credits+=reward
 var entry="%s / %s / +%d CR" % [SYSTEM_NAMES[current_system],name,reward]
 unknown_messages.push_front(entry)
 if unknown_messages.size()>30: unknown_messages.resize(30)
 if not codex.has("UNKNOWN: "+name): codex.append("UNKNOWN: "+name)
 if unknown_discoveries==5:
  announce("FIVE SIGNALS RESOLVED — ANCIENT SANCTUARY GATE UNLOCKED / 8")
 else:
  announce("MYSTERY RESOLVED — "+name+" / +"+str(reward)+" CR")
 save_game()

func recover_unknown_artifact() -> void:
 if unknown_pocket:
  activate_sanctuary_resonator()
  return
 if docked or on_surface or jump_timer>0.0:
  announce("ARTIFACT RECOVERY REQUIRES OPEN SPACE")
  return
 for site in unknown_sites:
  var key=str(site["key"])
  if unknown_records.has(key) and not unknown_artifacts.has(key) and flight_pos.distance_to(site["position"])<360.0:
   unknown_artifacts[key]=true
   unknown_artifact_count=unknown_artifacts.size()
   var reward=650+current_system*90
   credits+=reward
   unknown_messages.push_front("ARTIFACT RECOVERED / "+str(site["name"])+" / +"+str(reward)+" CR")
   announce("ANCIENT ARTIFACT SECURED — +%d CR / %d COLLECTED" % [reward,unknown_artifact_count])
   save_game()
   return
 announce("NO RECOVERABLE ARTIFACT WITHIN 360 M — RESOLVE A SIGNAL FIRST")

func cycle_sanctuary_pylon() -> void:
 if not unknown_pocket:
  announce("RESONATOR SELECTION AVAILABLE INSIDE THE ANCIENT SANCTUARY")
  return
 unknown_pylon_index=(unknown_pylon_index+1)%3
 announce("SANCTUARY RESONATOR %d SELECTED / 9 ACTIVATE" % (unknown_pylon_index+1))

func activate_sanctuary_resonator() -> void:
 if not unknown_pocket or unknown_pocket_root==null: return
 var sector_key=str(current_system)
 if unknown_vaults_opened.has(sector_key):
  announce("THIS SECTOR'S SANCTUARY VAULT IS ALREADY OPEN")
  return
 if unknown_artifact_count<3:
  announce("VAULT SEALED — RECOVER THREE ANCIENT ARTIFACTS / %d OF 3" % unknown_artifact_count)
  return
 var local_pos=unknown_pocket_root.to_local(flight_pos)
 var nearest=-1
 var distance=260.0
 for i in range(unknown_pylon_nodes.size()):
  var pylon=unknown_pylon_nodes[i]
  if is_instance_valid(pylon):
   var d=local_pos.distance_to(pylon.position+Vector3(0,180,0))
   if d<distance:
    distance=d
    nearest=i
 if nearest<0:
  announce("FLY WITHIN 260 M OF A RESONATOR TO ACTIVATE / 0 CYCLES TARGET")
  return
 var key=sector_key+":"+str(nearest)
 if unknown_sanctuary_keys.has(key):
  announce("RESONATOR ALREADY STABILIZED")
  return
 unknown_sanctuary_keys[key]=true
 ball(unknown_pylon_nodes[nearest],Vector3(0,300,0),35.0,Color(0.18,1.0,0.35),2.4,10)
 var count=0
 for i in range(3):
  if unknown_sanctuary_keys.has(sector_key+":"+str(i)): count+=1
 announce("RESONATOR %d STABILIZED / %d OF 3" % [nearest+1,count])
 if count==3:
  unknown_vaults_opened[sector_key]=true
  var reward=6500+current_system*500
  credits+=reward
  var title="SANCTUARY VAULT / "+SYSTEM_NAMES[current_system]
  if not codex.has(title): codex.append(title)
  unknown_messages.push_front(title+" / +"+str(reward)+" CR")
  announce("ANCIENT VAULT OPENED — +%d CR / ARCHIVE UPDATED" % reward)
 save_game()

func activate_unknown_gate() -> void:
 if docked or on_surface or jump_timer>0.0 or landing_timer>0.0 or world_transition>0.0:
  announce("ANCIENT GATE CANNOT OPEN DURING TRANSIT OR LANDING")
  return
 if unknown_pocket:
  unknown_pocket=false
  flight_pos=unknown_pocket_return
  linear_velocity=Vector3.ZERO
  throttle=0.0
  unknown_gate_uses+=1
  announce("ANCIENT GATE: RETURNED TO KNOWN SPACE")
  save_game()
  close_menu()
  return
 if unknown_discoveries<5:
  announce("GATE LOCKED — RESOLVE %d MORE SIGNALS" % (5-unknown_discoveries))
  return
 if unknown_pocket_root==null: return
 unknown_pocket_return=flight_pos
 unknown_pocket=true
 flight_pos=unknown_pocket_root.position+Vector3(0,0,1650)
 linear_velocity=Vector3.ZERO
 throttle=0.0
 cruise=false
 unknown_gate_uses+=1
 var discovery="ANCIENT SANCTUARY / "+SYSTEM_NAMES[current_system]
 if not codex.has(discovery):
  codex.append(discovery)
  credits+=3200
 announce("SANCTUARY DISCOVERED — RETURN THROUGH GATE WITH 8")
 save_game()
 close_menu()

# PASS 20 — operator recovery, playable diagnostics and performance presets.
func run_pass20_health_check() -> void:
 pass20_checks.clear()
 if not is_instance_valid(player): pass20_checks.append("PLAYER MISSING")
 if not is_instance_valid(camera): pass20_checks.append("CAMERA MISSING")
 if not is_instance_valid(station): pass20_checks.append("STATION MISSING")
 if not is_instance_valid(menu): pass20_checks.append("MENU MISSING")
 if MISSIONS.size()!=40: pass20_checks.append("MISSION CATALOG: %d / 40" % MISSIONS.size())
 if SYSTEM_NAMES.size()!=7: pass20_checks.append("SECTOR CATALOG INVALID")
 if ship_class<0 or ship_class>=SHIP_NAMES.size(): pass20_checks.append("SHIP CLASS OUT OF RANGE")
 if current_system<0 or current_system>=SYSTEM_NAMES.size(): pass20_checks.append("SECTOR OUT OF RANGE")
 if not flight_pos.is_finite(): pass20_checks.append("SHIP POSITION INVALID")
 if not linear_velocity.is_finite(): pass20_checks.append("SHIP VELOCITY INVALID")
 if route_legs.size()>7: pass20_checks.append("ROUTE TOO LONG")
 if not is_instance_valid(fleet_visual): pass20_checks.append("SHIPWORKS MODEL MISSING")
 if pass20_checks.is_empty():
  pass20_last_check="CHECKS OK / 40 MISSIONS / 7 SECTORS / SHIP + HUD READY"
 else:
  pass20_last_check="%d WARNING(S): %s" % [pass20_checks.size(),", ".join(PackedStringArray(pass20_checks))]
  push_warning("Space Gods Pass 20: "+pass20_last_check)

func pass20_check_and_show() -> void:
 run_pass20_health_check()
 announce(pass20_last_check)
 show_menu("flight_support")

func pass20_plot_mission() -> void:
 if mission_stage>=6:
  announce("NO ACTIVE MISSION / OPEN M TO CHOOSE ONE")
  show_menu("flight_support")
  return
 var target_sector: int=mission_current_sector()
 if target_sector==current_system:
  nav_target=0
  announce("OBJECTIVE IN CURRENT SECTOR / WAYPOINT SELECTED")
  close_menu()
  return
 plot_route(target_sector,true)

func pass20_reset_flight() -> void:
 if docked or jump_timer>0.0 or world_transition>0.0:
  announce("CONTROL RESET UNAVAILABLE DURING DOCKING / TRANSIT")
  return
 mouse_delta=Vector2.ZERO
 roll_delta=0.0
 flight_assist=true
 nav_assist=true
 cruise=false
 cruise_spool=0.0
 boost_active=false
 chase=true
 chase_distance_target=72.0
 roll=0.0
 announce("FLIGHT CONTROLS RESET / CAMERA CHASE / ASSISTS ON")
 close_menu()

func pass20_recover_ship() -> void:
 if docked or landing_timer>0.0 or launch_timer>0.0 or jump_timer>0.0 or world_transition>0.0:
  announce("RECOVERY UNAVAILABLE DURING DOCKING / TRANSIT")
  return
 if unknown_pocket:
  announce("LEAVE THE ANCIENT SANCTUARY WITH 8 FIRST")
  return
 on_surface=false
 surface_scan_site=-1
 surface_scan_time=0.0
 mission_scan_active=false
 unknown_scanning=false
 if is_instance_valid(world_surface): world_surface.visible=false
 if is_instance_valid(sector_scenery): sector_scenery.visible=true
 flight_pos=station_position+Vector3(0,150,1450)
 linear_velocity=Vector3.ZERO
 velocity=0.0
 throttle=0.0
 cruise=false
 boost_active=false
 yaw=0.0
 pitch=0.0
 roll=0.0
 clearance_granted=false
 pass20_recoveries+=1
 announce("RECOVERED TO LOCAL STATION APPROACH / MISSION NOT ADVANCED")
 save_game()
 close_menu()

func apply_pass20_detail() -> void:
 if is_instance_valid(starfield) and starfield.multimesh!=null:
  starfield.multimesh.visible_instance_count=450 if pass20_low_detail else -1
 for rock in pass20_asteroids:
  if is_instance_valid(rock): rock.visible=not pass20_low_detail

func pass20_toggle_detail() -> void:
 pass20_low_detail=not pass20_low_detail
 apply_pass20_detail()
 announce("LOW DETAIL ENABLED" if pass20_low_detail else "FULL SCENERY ENABLED")
 show_menu("flight_support")

func pass20_save_and_show() -> void:
 save_game()
 announce("SAVE SUCCESSFUL" if last_save_ok else "SAVE FAILED: "+last_save_status)
 show_menu("flight_support")

func pass20_export_report() -> void:
 run_pass20_health_check()
 var report="SPACE GODS PASS 20 DIAGNOSTIC REPORT\n"
 report+="Health: "+pass20_last_check+"\n"
 report+="Sector: "+SYSTEM_NAMES[current_system]+"\n"
 report+="Ship: "+SHIP_NAMES[ship_class]+"\n"
 report+="Position: "+str(flight_pos)+"\n"
 report+="Mission: "+str(active_mission)+" / stage "+str(mission_stage)+"\n"
 report+="Docked: "+str(docked)+" / Surface: "+str(on_surface)+"\n"
 report+="Frame rate: "+str(measured_fps)+"\n"
 report+="Last save: "+last_save_status+"\n"
 report+="Recovery uses: "+str(pass20_recoveries)+"\n"
 report+="Low detail: "+str(pass20_low_detail)+"\n"
 report+="Warnings: "+str(runtime_warnings)+"\n"
 var file=FileAccess.open("user://SPACE_GODS_PASS20_REPORT.txt",FileAccess.WRITE)
 if file==null:
  announce("DIAGNOSTIC REPORT COULD NOT BE WRITTEN")
  return
 file.store_string(report)
 file.close()
 announce("REPORT SAVED TO GODOT USER DATA / SPACE_GODS_PASS20_REPORT.txt")
 show_menu("flight_support")

func _notification(what: int) -> void:
 if what==NOTIFICATION_WM_CLOSE_REQUEST:
  if startup_checked and not save_write_busy and jump_timer<=0.0 and world_transition<=0.0:
   save_game()

# PASS 19 — Diagnostics and accessibility. Optional shortcuts F13/F14/F15.
func toggle_diagnostics() -> void:
 diagnostics_visible=not diagnostics_visible
 if diagnostics_label!=null:
  diagnostics_label.visible=diagnostics_visible
 if diagnostics_visible: update_diagnostics()
 announce("DIAGNOSTICS ON" if diagnostics_visible else "DIAGNOSTICS OFF")

func toggle_hud_compact() -> void:
 ui_minimized=not ui_minimized
 if cockpit_hud!=null: cockpit_hud.set_compact(ui_minimized)
 if ui_left_panel!=null: ui_left_panel.visible=false
 if ui_nav_panel!=null: ui_nav_panel.visible=false
 if ui_docking_panel!=null: ui_docking_panel.visible=false
 if ui_help_strip!=null: ui_help_strip.visible=false
 announce("MINIMAL FLIGHT HUD" if ui_minimized else "FULL FLIGHT HUD")

func toggle_performance_mode() -> void:
 performance_mode=not performance_mode
 Engine.max_fps=60 if performance_mode else 0
 announce("60 FPS FRAME CAP" if performance_mode else "UNCAPPED FRAME RATE")

func update_diagnostics() -> void:
 if diagnostics_label==null: return
 diagnostics_label.text="PASS 20 / DIAGNOSTICS\nFPS %.0f / RENDERED OBJECTS %d\nSECTOR %d / MISSION %d STEP %d\nSHIP %s / HP %d / SHIELD %d\nSAVE %s / FAILURES %d\nSHIFT+F1 DIAGNOSTICS · SHIFT+F2 HUD · SHIFT+F3 FPS" % [measured_fps,get_tree().get_node_count(),current_system,active_mission+1,mission_stage,SHIP_NAMES[ship_class],int(hull_hp),int(shield_hp),last_save_status,autosave_failures]

# PASS 19B: runtime invariants and recoverable state checks.
func validate_loaded_state() -> void:
 current_system=clampi(current_system,0,SYSTEM_NAMES.size()-1)
 ship_class=clampi(ship_class,0,SHIP_NAMES.size()-1)
 active_mission=clampi(active_mission,0,MISSIONS.size()-1)
 mission_stage=clampi(mission_stage,0,6)
 fuel=clampf(fuel,0.0,100.0)
 credits=maxi(0,credits)
 throttle=clampf(throttle,0.0,1.0)
 if not flight_pos.is_finite():
  flight_pos=SECTOR_ORIGINS[current_system]+Vector3(0,0,950)
  linear_velocity=Vector3.ZERO
  runtime_warnings.append("Invalid ship coordinates were reset")
 if not linear_velocity.is_finite():
  linear_velocity=Vector3.ZERO
  runtime_warnings.append("Invalid velocity was reset")
 if docked:
  on_surface=false
  linear_velocity=Vector3.ZERO
  throttle=0.0
  cruise=false
 if on_surface:
  cruise=false
  jump_timer=0.0
  world_transition=0.0
 if route_destination==current_system:
  route_destination=-1
  route_legs.clear()
 if route_legs.size()>SYSTEM_NAMES.size():
  route_legs.clear()
  runtime_warnings.append("Invalid navigation route was cleared")
 if runtime_warnings.size()>0:
  for warning_text in runtime_warnings: push_warning("Space Gods: "+warning_text)


# PASS 21: Presets can be switched without restarting or rebuilding the mission world.
func set_pass21_quality(level: int) -> void:
 pass21_quality=clampi(level,0,2)
 pass20_low_detail=pass21_quality==0
 apply_pass20_detail()
 if is_instance_valid(pass21_visuals): pass21_visuals.apply_quality(pass21_quality)
 if is_instance_valid(pass22_visuals): pass22_visuals.apply_quality(pass21_quality)
 if is_instance_valid(pass27_dreadnought): pass27_dreadnought.apply_quality(pass21_quality)
 announce("GRAPHICS: "+["PERFORMANCE","BALANCED","CINEMATIC"][pass21_quality])
 save_game()
 show_menu("graphics")

# PASS36 — 6-pip power management. Pips are taken from the highest other bank.
func p36_move_power(bank: int) -> void:
 var pips: Array[int] = [p36_power_engines,p36_power_weapons,p36_power_shields]
 if pips[bank]>=4:
  announce("POWER BANK ALREADY AT MAXIMUM")
  return
 var donor: int = -1
 for i in range(3):
  if i!=bank and pips[i]>0 and (donor<0 or pips[i]>pips[donor]): donor=i
 if donor<0:
  announce("NO POWER AVAILABLE TO TRANSFER")
  return
 pips[bank]+=1
 pips[donor]-=1
 p36_power_engines=pips[0]
 p36_power_weapons=pips[1]
 p36_power_shields=pips[2]
 announce("POWER PIPS   ENG %d / WEP %d / SYS %d" % [pips[0],pips[1],pips[2]])

func p36_activate_ability(key: int) -> void:
 if engine_cutoff:
  announce("ENGINES OFF — RESTART BEFORE USING PILOT ABILITIES")
  return
 if p36_ability_cooldown>0.0:
  announce("PILOT ABILITIES RECHARGING — %d SEC" % int(ceilf(p36_ability_cooldown)))
  return
 var cost: float = 35.0 if key==KEY_Q else (45.0 if key==KEY_E else 50.0)
 if energy<cost:
  announce("INSUFFICIENT ENERGY — %d / %d" % [int(energy),int(cost)])
  return
 energy-=cost
 p36_ability_cooldown=18.0
 if key==KEY_Q:
  p36_shield_boost_timer=9.0
  shield_hp=minf(max_shield(),shield_hp+max_shield()*0.23)
  player_shield_delay=0.0
  announce("AEGIS SHIELD SURGE — 9 SECONDS")
 elif key==KEY_E:
  p36_jammer_timer=7.0
  announce("ELECTRONIC JAMMER — HOSTILE LOCKS DISRUPTED 7 SEC")
 elif key==KEY_R:
  p36_overdrive_timer=10.0
  announce("ENGINE OVERDRIVE — 10 SECONDS")

# PASS37 — pilot assistance is steering/throttle only, never combat automation.
func p37_set_flight_mode(mode: int) -> void:
 p43_auto_evading = false
 p42_evasion_active = false
 p42_status = "MANUAL"
 if mode == 0:
  p38_nav_mode = 0
  p38_nav_status = "STANDBY"
  p37_flight_mode = 0
  p37_status = "MANUAL"
  announce("TACTICAL FLIGHT DISENGAGED — MANUAL CONTROL")
  return
 if engine_cutoff:
  announce("RESTART ENGINES (~) BEFORE TACTICAL FLIGHT")
  return
 if cruise or jump_timer > 0.0 or on_surface:
  announce("TACTICAL FLIGHT REQUIRES NORMAL SPACE FLIGHT")
  return
 if enemies.is_empty():
  announce("NO HOSTILE CONTACT — TAB TO SELECT A TARGET")
  return
 target_index = clampi(target_index, 0, enemies.size()-1)
 if not is_instance_valid(enemies[target_index]):
  announce("TARGET CONTACT LOST")
  return
 p38_nav_mode = 0
 p38_nav_status = "STANDBY"
 p37_flight_mode = mode
 p37_status = "PURSUIT" if mode == 1 else "RANGE HOLD"
 announce("TACTICAL FLIGHT: %s / CTRL+6 TO DISENGAGE" % p37_status)


# PASS38 — navigation assistant is optional and never fires or performs jumps.
func p38_set_nav_mode(mode: int) -> void:
 if not p43_auto_evading:
  p43_recovery_cooldown = maxf(p43_recovery_cooldown, 1.0)
 p42_evasion_active = false
 if mode == 0:
  p38_nav_mode = 0
  p38_nav_status = "STANDBY"
  announce("NAV PILOT OFF — MANUAL FLIGHT")
  return
 if docked or on_surface or jump_timer > 0.0 or landing_timer > 0.0 or world_transition > 0.0:
  announce("NAV PILOT REQUIRES FREE SPACE FLIGHT")
  return
 if engine_cutoff:
  announce("ENGINES OFF — PRESS ~ TO RESTART")
  return
 p37_flight_mode = 0
 p37_status = "MANUAL"
 cruise = false
 p38_nav_mode = mode
 p38_nav_status = "WAYPOINT APPROACH" if mode == 1 else ("STATION APPROACH" if mode == 2 else "AUTO DOCK")
 announce("NAV PILOT ENGAGED: %s / CTRL+6 MANUAL" % p38_nav_status)


# PASS40 — flight computer safeguards and dedicated cancel control.
func p40_control_combo_held() -> bool:
 for key in [KEY_0, KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6, KEY_7, KEY_8, KEY_9, KEY_Q, KEY_E, KEY_R]:
  if Input.is_key_pressed(key):
   return true
 return false

func p40_abort_autopilot() -> void:
 p43_auto_evading = false
 p43_recovery_cooldown = 12.0
 p37_flight_mode = 0
 p38_nav_mode = 0
 p37_status = "MANUAL"
 p38_nav_status = "CANCELLED / MANUAL"
 p41_emergency_hold = false
 p41_hazard_status = "MANUAL OVERRIDE"
 p42_evasion_active = false
 p42_saved_nav_mode = 0
 p42_status = "MANUAL OVERRIDE"
 throttle = 0.0
 cruise = false
 boost_active = false
 announce("FLIGHT COMPUTER DISENGAGED — THROTTLE IDLE / MANUAL CONTROL")



# PASS41: 4 Hz forward corridor scan; avoids per-frame physics queries and allocations.
# PASS43: scans nearby threats at 2 Hz only during active navigation.
# Automatically evades and resumes only a route it explicitly suspended.
func p44_profile_name() -> String:
 return ["CAUTIOUS", "BALANCED", "DARING"][clampi(p44_profile,0,2)]

func p44_log(message: String) -> void:
 var entry: String = message.strip_edges()
 if entry.is_empty():
  return
 if p44_incidents.is_empty() or p44_incidents.back() != entry:
  p44_incidents.append(entry)
  if p44_incidents.size() > 12:
   p44_incidents.pop_front()

# Do not silently burn the last fuel during automated travel. Manual flight remains possible.
func p44_fuel_reserve_tick() -> void:
 if docked or on_surface or engine_cutoff:
  p44_fuel_hold = false
  return
 if p38_nav_mode == 0:
  return
 if fuel > p44_fuel_reserve:
  p44_fuel_hold = false
  return
 if not p44_fuel_hold:
  p44_fuel_hold = true
  p44_log("LOW FUEL: AUTONAV CANCELLED")
  announce("FUEL RESERVE / NAV PILOT STOPPED / SHIFT+F1 DISTRESS")
 p38_nav_mode = 0
 p43_auto_evading = false
 p42_saved_nav_mode = 0
 p38_nav_status = "LOW FUEL / MANUAL OR RESCUE"
 throttle = 0.0
 boost_active = false

func p43_guardian_tick(dt: float) -> void:
 p43_scan_cooldown = maxf(0.0, p43_scan_cooldown - dt)
 p43_recovery_cooldown = maxf(0.0, p43_recovery_cooldown - dt)
 if is_instance_valid(pass46_auto) and pass46_auto.enabled:
  p43_status = "AUTO MISSION DIRECTOR / THREAT CONTROL"
  return
 if not p43_guardian_enabled:
  p43_status = "OFF"
  return
 if engine_cutoff or docked or on_surface or jump_timer > 0.0 or p41_emergency_hold:
  p43_status = "STANDBY / FLIGHT UNAVAILABLE"
  return
 if p43_auto_evading:
  p43_status = "EVADING / ROUTE SUSPENDED" if p42_evasion_active else "RECOVERING"
  return
 if p38_nav_mode == 0:
  p43_status = "ARMED / ENGAGE NAV PILOT"
  return
 if p43_recovery_cooldown > 0.0:
  p43_status = "COOLDOWN / %d S" % int(ceilf(p43_recovery_cooldown))
  return
 if p43_scan_cooldown > 0.0:
  return
 p43_scan_cooldown = 0.5
 var closest: float = 999999.0
 for contact in enemies:
  if is_instance_valid(contact):
   closest = minf(closest, flight_pos.distance_to(contact.global_position))
 var alert_range: float = [1700.0,1150.0,700.0][clampi(p44_profile,0,2)]
 if closest < alert_range:
  p44_log("HOSTILE CONTACT: %d M / %s" % [int(closest),p44_profile_name()])
  p43_auto_evading = true
  p43_status = "HOSTILE %d M / EVADE" % int(closest)
  p42_start_evasion()
  if not p42_evasion_active:
   p43_auto_evading = false
  else:
   announce("GUARDIAN: HOSTILE INTERCEPT / ROUTE SUSPENDED")
 else:
  p43_status = "GUARDING ROUTE / CLEAR"

func p42_start_evasion() -> void:
 if not p43_auto_evading:
  p43_recovery_cooldown = 12.0
 if engine_cutoff or on_surface or jump_timer > 0.0 or p41_emergency_hold:
  announce("EVADE UNAVAILABLE — CHECK ENGINES / EMERGENCY HOLD")
  return
 if p38_nav_mode != 0:
  p42_saved_nav_mode = p38_nav_mode
 p38_nav_mode = 0
 p37_flight_mode = 0
 cruise = false
 p42_evasion_active = true
 p42_evasion_time = 14.0
 p42_status = "EVADE ACTIVE / 14 S"
 announce("TACTICAL EVADE — ESCAPING NEAREST THREAT / CTRL+6 MANUAL")

func p42_resume_route() -> void:
 p43_auto_evading = false
 if p42_evasion_active:
  p42_evasion_active = false
 if p42_saved_nav_mode == 0:
  p42_status = "NO SAVED ROUTE / CTRL+7 TO NAVIGATE"
  announce("NO PREVIOUS NAVIGATION ROUTE")
  return
 if p41_emergency_hold or engine_cutoff or docked or on_surface:
  announce("ROUTE RESUME BLOCKED — CHECK SHIP STATUS")
  return
 var resume_mode: int = p42_saved_nav_mode
 p42_saved_nav_mode = 0
 p42_status = "ROUTE RESUMED"
 p38_set_nav_mode(resume_mode)

# PASS41 scanner retained, used by PASS42 detour controller.
func p41_scan_forward() -> void:
 p41_hazard_distance = 999999.0
 p41_hazard_kind = ""
 if engine_cutoff or docked or on_surface or jump_timer > 0.0:
  p41_hazard_status = "STANDBY"
  return
 var forward: Vector3 = -Basis.from_euler(Vector3(pitch,yaw,roll)).z
 for rock in pass20_asteroids:
  if not is_instance_valid(rock):
   continue
  var offset: Vector3 = rock.global_position - flight_pos
  var ahead: float = offset.dot(forward)
  if ahead < 0.0 or ahead > 1700.0:
   continue
  var cross_track: float = (offset - forward * ahead).length()
  if cross_track < 230.0 and ahead < p41_hazard_distance:
   p41_hazard_distance = ahead
   p41_hazard_point = rock.global_position
   p41_hazard_kind = "ASTEROID"
 # Hostile traffic is also a potential collision/ambush in a narrow corridor.
 for hostile in enemies:
  if not is_instance_valid(hostile):
   continue
  var offset: Vector3 = hostile.global_position - flight_pos
  var ahead: float = offset.dot(forward)
  if ahead < 0.0 or ahead > 1400.0:
   continue
  if (offset - forward * ahead).length() < 170.0 and ahead < p41_hazard_distance:
   p41_hazard_distance = ahead
   p41_hazard_point = hostile.global_position
   p41_hazard_kind = "HOSTILE"
 if p41_hazard_kind == "":
  p41_hazard_status = "CLEAR / AUTO SCAN"
 else:
  p41_hazard_status = "CONTACT %s / %d M" % [p41_hazard_kind,int(p41_hazard_distance)]
