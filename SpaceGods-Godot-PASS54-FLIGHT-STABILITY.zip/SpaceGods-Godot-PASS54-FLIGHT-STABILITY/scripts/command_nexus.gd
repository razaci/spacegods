extends Node
# Pass 33: connected, nested, recoverable ship computer.
var game
var debt: int = 0
var rescue_count: int = 0
var last_report: String = "No incidents recorded."
const CREDIT_FUEL_PRICE = 12
const SYNTH_ALLOYS = 2
const SYNTH_CELLS = 2

func initialize(host) -> void:
 game = host

func export_state() -> Dictionary:
 return {"debt":debt,"rescues":rescue_count,"report":last_report}

func import_state(value) -> void:
 if not value is Dictionary: return
 debt = clampi(int(value.get("debt",0)),0,20000)
 rescue_count = clampi(int(value.get("rescues",0)),0,99999)
 last_report = str(value.get("report","No incidents recorded.")).substr(0,160)

func jump_need() -> int:
 if game.route_legs.is_empty(): return 0
 return game.jump_fuel_cost(game.current_system,int(game.route_legs[0]))

func page(label: String, info: String) -> void:
 game.menu_open = true
 game.menu.visible = true
 for child in game.menu_actions.get_children():
  game.menu_actions.remove_child(child)
  child.queue_free()
 game.menu_title.text = "COMMAND NEXUS / " + label
 game.menu_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 game.menu_text.custom_minimum_size.y = 145
 game.menu_text.text = info

func link(label: String, target: String) -> void:
 game.add_action(label,show.bind(target))

func legacy(label: String, target: String) -> void:
 game.add_action(label,game.show_menu.bind(target))

func finish(parent: String) -> void:
 if parent!="": link("< BACK / " + parent.to_upper(),parent)
 if parent!="home": link("SHIP COMPUTER / HOME", "home")
 game.add_action("CLOSE / RETURN TO FLIGHT",game.close_menu)

func show(section: String = "home") -> void:
 var fuel_status = "FUEL %d%%  |  NEXT JUMP %d%%  |  CREDITS %d  |  RESCUE DEBT %d" % [int(game.fuel),jump_need(),game.credits,debt]
 match section:
  "home":
   page("BRIDGE", "[b]GODS COMMAND NEXUS[/b]\n%s\n\nEvery terminal is linked. If you are stranded, open DISTRESS & RECOVERY. The computer remains available while flying, without a station or jump fuel.\n\nSECTOR: %s  |  SHIP: %s" % [fuel_status,game.SYSTEM_NAMES[game.current_system],game.SHIP_NAMES[game.ship_class]])
   link("01  DISTRESS / STRANDED SHIP", "distress")
   link("02  NAVIGATION / JUMP NETWORK", "navigation")
   link("03  MISSIONS / BOUNTIES / CAREERS", "operations")
   link("AUTO MISSIONS / ONE-BUTTON DIRECTOR", "auto_missions")
   link("04  TRADE / CARGO / BAZAAR", "commerce")
   link("05  ENGINEERING / SHIP SERVICES", "engineering")
   link("06  FLEET / SHIPWORKS / TACTICAL", "fleet")
   link("07  STATION / CONTACTS / SIGNALS", "contacts")
   link("08  DIAGNOSTICS / SAVE / HELP", "diagnostics")
   link("09  FLIGHT ACADEMY / GUIDED HELP", "academy")
   finish("")
  "auto_missions":
   page("AUTO MISSIONS", "[b]ONE-BUTTON MISSION DIRECTOR[/b]\nAutomatically accepts the next incomplete operation, launches, plots jumps, navigates, fights mission targets, scans, docks, and claims rewards.\n\nF8 + SHIFT toggles automation from anywhere. The small flight-screen button does the same.\n\nThe director PAUSES on low fuel, critical damage, failed escort or unexpected conditions. Stop anytime to fly manually.\n\nSTATUS: " + game.pass46_auto.status)
   game.add_action("START / RESUME AUTO MISSIONS",game.pass46_auto.start)
   game.add_action("STOP / MANUAL FLIGHT",game.pass46_auto.stop)
   legacy("VIEW MISSION DIRECTOR", "missions")
   link("EMERGENCY FUEL / RESCUE", "distress")
   finish("home")
  "academy":
   page("FLIGHT ACADEMY", "[b]ONBOARD TRAINING / HELP DESK[/b]\nSelect a topic. Every guide links to the relevant working computer terminal.\n\nF10: Toggle small flight tips.\nShift+F10: Open this academy from anywhere.\nShift+F1: Open the Command Nexus.")
   link("01 / BASIC FLIGHT AND THROTTLE", "learn_flight")
   link("02 / TARGETING AND COMBAT", "learn_combat")
   link("03 / AUTOPILOT AND GUARDIAN", "learn_pilot")
   link("04 / DOCKING AND STATIONS", "learn_dock")
   link("05 / MISSIONS AND EXPEDITIONS", "learn_missions")
   link("06 / BOUNTY HUNTING", "learn_bounty")
   link("07 / TRADING AND BAZAAR", "learn_trade")
   link("08 / STRANDED OR DAMAGED", "learn_rescue")
   finish("home")
  "learn_flight":
   page("ACADEMY / FLIGHT", "[b]FLIGHT BASICS[/b]\n1-9: Throttle 10-90%. 0: 100%. X: All stop. ~: Engine off/on.\nLeft mouse drag: steer. Right mouse drag: roll. F: Fire. V: Change camera.\nShift/Ctrl adjust throttle. Best turning at moderate throttle.\n\nTIP: Use 5 or 6 to maneuver, 0 to travel, X to brake.")
   legacy("OPEN FLIGHT SUPPORT", "flight_support")
   link("NEXT / TARGETING", "learn_combat")
   finish("academy")
  "learn_combat":
   page("ACADEMY / COMBAT", "[b]COMBAT AND CAPTURE[/b]\nTab: Cycle hostiles. Shift+Tab: Nearest hostile. T: Cycle enemy subsystem. F: Fire. K: Missile.\nDisable engines and lower hull to board with Shift+B.\nCtrl+1/2/3: Divert reactor power to engines/weapons/shields.\nCtrl+4: Pursuit; Ctrl+5: Hold combat range; Ctrl+6: Manual.")
   legacy("OPEN TACTICAL COMPUTER", "tactics")
   link("BOUNTY GUIDE", "learn_bounty")
   finish("academy")
  "learn_pilot":
   page("ACADEMY / AUTOPILOT", "[b]FLIGHT COMPUTER[/b]\nCtrl+7: Follow waypoint. Ctrl+8: Station approach. Ctrl+9: Automatic docking.\nCtrl+6: Manual flight. Ctrl+0: Emergency cancel.\nCtrl+Shift+7: Evade threats. Ctrl+Shift+8: Resume route. Ctrl+Shift+9: Guardian on/off.\nCtrl+Shift+4: Change Guardian profile.\nIf engines are off, press ~ to restart before engaging autopilot.")
   legacy("OPEN FLIGHT SUPPORT", "flight_support")
   link("DOCKING GUIDE", "learn_dock")
   finish("academy")
  "learn_dock":
   page("ACADEMY / DOCKING", "[b]STATION OPERATIONS[/b]\nCtrl+8 approaches a station; Ctrl+9 requests clearance and attempts automatic landing.\nCtrl+6 cancels flight assistance. Use the Comms terminal for docking requests.\nAt a station, engineering and shipyard services become available.")
   legacy("OPEN DOCKING COMMS", "comms")
   link("STATION SERVICES", "contacts")
   finish("academy")
  "learn_missions":
   page("ACADEMY / MISSIONS", "[b]EXPEDITIONS[/b]\nM opens the Mission Director. Choose a contract, plot its current leg, jump with J, and follow the objective marker.\nSome contracts cross two or three sectors. Completing one site unlocks the next destination.\nReturn to the issuing station when the mission requires turn-in.")
   legacy("OPEN MISSION DIRECTOR", "missions")
   link("MISSIONS AND FACTIONS", "operations")
   finish("academy")
  "learn_bounty":
   page("ACADEMY / BOUNTIES", "[b]BOUNTY INVESTIGATIONS[/b]\nOpen the named-warrant board. Track evidence, locate the target and choose whether to destroy or capture.\nDisable engines, strip shields and board at close range for a capture when conditions permit.\nLegendary captains can have special encounters and rewards.")
   game.add_action("OPEN BOUNTY WARRANTS",game.living_galaxy.show.bind("hunts"))
   link("COMBAT GUIDE", "learn_combat")
   finish("academy")
  "learn_trade":
   page("ACADEMY / COMMERCE", "[b]TRADE AND BAZAAR[/b]\nCompare commodity prices by system before buying cargo. Freight contracts pay for specific deliveries.\nThe bazaar lists orders; regional supply and faction security can affect your margins.\nRestricted cargo can be inspected by station customs.")
   link("TRADE AND BAZAAR TERMINALS", "commerce")
   game.add_action("OPEN ROUTE ANALYZER",game.living_galaxy.show.bind("route_planner"))
   finish("academy")
  "learn_rescue":
   page("ACADEMY / EMERGENCIES", "[b]STRANDED SHIP CHECKLIST[/b]\n1. Press ~ if engines are powered off.\n2. Open Distress & Recovery, even with zero fuel.\n3. Order emergency fuel, synthesize from materials, or request a rescue advance.\n4. Check route fuel cost and plot a reachable jump.\n5. Use emergency tow if you cannot reach the local station.\n\nThe Command Nexus remains accessible in deep space.")
   link("OPEN DISTRESS AND RECOVERY", "distress")
   link("OPEN NAVIGATION", "navigation")
   finish("academy")
  "distress":
   var needed = jump_need()
   var status = "STRANDED: NOT ENOUGH FUEL FOR NEXT JUMP" if needed>int(game.fuel) else "JUMP FUEL STATUS: SUFFICIENT / NO ROUTE"
   page("DISTRESS", "[b]EMERGENCY OPERATIONS / NO STATION REQUIRED[/b]\n%s\n%s\n\nDispatch is available even at zero fuel. Paid fuel delivery costs credits; salvage synthesis uses stored materials. Rescue advance incurs a repayable debt and is limited to 3,600 CR outstanding. Rescue does NOT teleport you or complete missions.\n\n%s" % [fuel_status,status,last_report])
   game.add_action("REQUEST FUEL DELIVERY / +25% / 300 CR",fuel_delivery)
   game.add_action("SYNTHESIZE JUMP FUEL / +18% / 2 ALLOYS + 2 CELLS",fuel_synthesis)
   game.add_action("ISSUE DISTRESS ADVANCE / +25% / 1200 CR DEBT",fuel_advance)
   game.add_action("PAY RESCUE DEBT / UP TO 600 CR",pay_debt)
   game.add_action("EMERGENCY TOW / LOCAL STATION APPROACH",emergency_tow)
   link("FIND SAFEST JUMP ROUTE", "navigation")
   link("REPAIR / RESTART / ENGINEERING", "engineering")
   finish("home")
  "navigation":
   page("NAVIGATION", "[b]NAVIGATION AND FRAME SHIFT[/b]\n%s\n\nPlot a route below. Jump with J after closing menus. If the next leg needs more fuel, use Distress Services.\nCURRENT: %s" % [fuel_status,game.SYSTEM_NAMES[game.current_system]])
   for i in range(game.SYSTEM_NAMES.size()):
    if i!=game.current_system: game.add_action("PLOT ROUTE / "+game.SYSTEM_NAMES[i],plot_to.bind(i))
   link("DISTRESS / FUEL OPTIONS", "distress")
   legacy("OPEN FULL GALAXY MAP", "galaxy")
   finish("home")
  "operations":
   page("OPERATIONS", "[b]MISSIONS, WARRANTS, FACTIONS[/b]\nUse the same contracts and progress as the mission director and Living Galaxy. This terminal is an index, not a separate copy of your missions.")
   legacy("MISSION DIRECTOR / ACTIVE CONTRACT", "missions")
   link("AUTO MISSIONS / START-STOP", "auto_missions")
   legacy("MISSION JOURNAL", "mission_journal")
   game.add_action("BOUNTY WARRANTS / NAMED CAPTAINS",game.living_galaxy.show.bind("hunts"))
   game.add_action("BRANCHING EXPEDITIONS",game.living_galaxy.show.bind("expeditions"))
   game.add_action("FACTION RELIEF COMMISSIONS",game.living_galaxy.show.bind("relief"))
   game.add_action("LEGENDARY SHIP REGISTRY",game.living_galaxy.show.bind("legendary"))
   finish("home")
  "commerce":
   page("COMMERCE", "[b]INTERSTELLAR TRADE AND LOGISTICS[/b]\nCargo and credit balances are shared across the market, bazaar and ship engineering. Purchases still require normal market conditions.")
   game.add_action("REGIONAL MARKETS",game.living_galaxy.show.bind("markets"))
   game.add_action("TRADE ROUTE ANALYZER",game.living_galaxy.show.bind("route_planner"))
   game.add_action("BAZAAR / ESCROW ORDERS",game.living_galaxy.show.bind("bazaar"))
   game.add_action("FREIGHT CONTRACTS",game.living_galaxy.show.bind("freight"))
   game.add_action("CARGO INVENTORY / CAREERS",game.living_galaxy.show.bind("careers"))
   legacy("SHIP CARGO HOLD", "cargo")
   finish("home")
  "engineering":
   page("ENGINEERING", "[b]SHIP SYSTEMS AND REPAIRS[/b]\n%s\n\nEmergency fuel can be acquired in deep space. Normal refuel, hull repair and rearming still require docking." % fuel_status)
   link("EMERGENCY FUEL / DISTRESS", "distress")
   game.add_action("RESTART ENGINES / IDLE",restart_engines)
   game.add_action("SYNTHESIZE JUMP FUEL",fuel_synthesis)
   game.add_action("WORKSHOP / CRAFTING",game.living_galaxy.show.bind("workshop"))
   legacy("STATION ENGINEERING SERVICES", "engineering")
   legacy("SHIP OUTFITTING", "outfitting")
   finish("home")
  "fleet":
   page("FLEET", "[b]SHIP AND COMBAT COMMAND[/b]\nAll commands open the existing live fleet and ship systems.")
   legacy("FLEET COMMAND", "fleet")
   legacy("SHIPYARD / DREADNOUGHT", "shipyard")
   legacy("TACTICAL COMMAND", "tactics")
   legacy("ARMORY / SALVAGE", "armory")
   finish("home")
  "contacts":
   page("CONTACTS", "[b]STATION AND EXPLORATION NETWORK[/b]\nFind station services, customs, deep-space signals and planetary operations.")
   legacy("STATION OPERATIONS", "station")
   legacy("DOCKING / LONG-RANGE COMMS", "comms")
   game.add_action("CUSTOMS AND SECURITY",game.living_galaxy.show.bind("customs"))
   legacy("UNKNOWN SIGNALS", "unknown")
   legacy("PLANETARY EXPEDITIONS", "worlds")
   finish("home")
  "diagnostics":
   page("DIAGNOSTICS", "[b]SHIP STATUS[/b]\n%s\nEngine cutoff: %s\nDocked: %s\nLast rescue: %s\n\nThe Flight Support menu contains startup checks and recovery tools." % [fuel_status,str(game.engine_cutoff),str(game.docked),last_report])
   game.add_action("SAVE GAME",save_now)
   legacy("FLIGHT SUPPORT / RECOVERY", "flight_support")
   legacy("FULL CONTROLS GUIDE", "help")
   link("GUIDED FLIGHT ACADEMY", "academy")
   link("DISTRESS SERVICES", "distress")
   finish("home")
  _:
   show("home")

func emergency_tow() -> void:
 if game.docked:
  report("Already docked; use the station engineering bay.")
  return
 game.pass20_recover_ship()
 last_report="Emergency tow requested. Ship recovered to local station approach; fuel unchanged."
 game.save_game()
 show("distress")

func plot_to(sector: int) -> void:
 game.plot_route(sector,true)
 show("navigation")

func fuel_delivery() -> void:
 if game.fuel>=99.0:
  report("Fuel tanks are already full.")
  return
 if game.credits<300:
  report("Delivery denied: need 300 credits. Use distress advance if eligible.")
  return
 game.credits-=300
 game.fuel=minf(100.0,game.fuel+25.0)
 rescue_count+=1
 report("Emergency fuel drone delivered 25% fuel for 300 CR.")

func fuel_synthesis() -> void:
 if game.fuel>=99.0:
  report("Fuel tanks are already full.")
  return
 var alloys=int(game.salvage_inventory.get("alloys",0))
 var cells=game.living_galaxy.amount("cells")
 if alloys<SYNTH_ALLOYS or cells<SYNTH_CELLS:
  report("Synthesis requires 2 alloys and 2 energy cells in your cargo.")
  return
 game.salvage_inventory["alloys"]=alloys-2
 game.living_galaxy.change_cargo("cells",-2)
 game.fuel=minf(100.0,game.fuel+18.0)
 report("Reactor synthesis complete: +18% fuel, 2 alloys and 2 cells consumed.")

func fuel_advance() -> void:
 if game.fuel>=99.0:
  report("Fuel tanks are already full.")
  return
 if debt+1200>3600:
  report("Rescue credit limit reached. Repay debt before another advance.")
  return
 debt+=1200
 rescue_count+=1
 game.fuel=minf(100.0,game.fuel+25.0)
 report("Emergency rescue advance approved: +25% fuel; debt +1200 CR.")

func pay_debt() -> void:
 if debt<=0:
  report("No rescue debt outstanding.")
  return
 var payment=mini(600,mini(debt,game.credits))
 if payment<=0:
  report("Insufficient credits to pay rescue debt.")
  return
 game.credits-=payment
 debt-=payment
 report("Rescue debt payment: %d CR; remaining %d CR." % [payment,debt])

func restart_engines() -> void:
 game.engine_cutoff=false
 game.throttle=0.0
 game.linear_velocity=Vector3.ZERO
 report("Engines restarted at idle. Use 1–0 for throttle detents.")
 show("engineering")

func save_now() -> void:
 game.save_game()
 show("diagnostics")

func report(message: String) -> void:
 last_report=message
 game.announce(message)
 game.save_game()
 show("distress")
