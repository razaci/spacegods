extends Node
# PASS 50 - lightweight physical starport and connected mission dispatch panels.
var game: Node3D
var root: Node3D
var last_page: String = "home"
var blue := Color(0.08, 0.64, 0.86)
var amber := Color(0.94, 0.57, 0.18)
var steel := Color(0.20, 0.28, 0.35)

func initialize(host: Node3D) -> void:
 game = host
 build_starport()

func build_starport() -> void:
 if not is_instance_valid(game.station):
  return
 root = Node3D.new()
 root.name = "Pass50_Starport_Orbital_Annex"
 game.station.add_child(root)
 # Six visible service piers and large freighter berths; no skyscraper city.
 for side in [-1.0, 1.0]:
  for i in range(3):
   var z: float = -320.0 + float(i) * 230.0
   var x: float = side * (310.0 + float(i % 2) * 65.0)
   game.cube(root, Vector3(x, -60, z), Vector3(145, 19, 170), steel)
   game.cube(root, Vector3(x, -44, z), Vector3(104, 12, 117), Color(0.12, 0.19, 0.27))
   game.cube(root, Vector3(x, -37, z - 44), Vector3(92, 3, 5), blue, 1.5)
   game.cube(root, Vector3(x, -37, z + 44), Vector3(92, 3, 5), amber, 1.0)
   game.cube(root, Vector3(x - side * 86.0, -59, z), Vector3(115, 12, 23), steel)
   for j in range(3):
    game.cube(root, Vector3(x - 46 + j * 46, -34, z + 61), Vector3(7, 8, 9), blue, 1.2)
 # A broad dispatch spine, navigation beacon array and recognizable central tower.
 game.cube(root, Vector3(0, 125, -245), Vector3(46, 280, 48), steel)
 game.cube(root, Vector3(0, 273, -245), Vector3(106, 21, 96), Color(0.23, 0.38, 0.48))
 for i in range(8):
  game.cube(root, Vector3(-42 + i * 12, 286, -245), Vector3(6, 3, 54), blue, 1.2)
 for side in [-1.0, 1.0]:
  game.cube(root, Vector3(side * 190, 6, -240), Vector3(230, 17, 25), steel)
  game.cube(root, Vector3(side * 180, 18, -240), Vector3(210, 4, 9), blue, 1.3)
 # Cargo stack clusters are distant from the main docking lane.
 for i in range(12):
  var x: float = -550.0 + float(i % 6) * 220.0
  var z: float = -600.0 - float(i / 6) * 120.0
  game.cube(root, Vector3(x, -90, z), Vector3(110, 70, 70), Color(0.22, 0.29, 0.36) if i % 2 else Color(0.33, 0.28, 0.23))
  game.cube(root, Vector3(x, -48, z), Vector3(95, 4, 7), amber, 0.9)

func panel(title: String, body: String) -> void:
 game.menu_open = true
 game.menu.visible = true
 for item in game.menu_actions.get_children():
  game.menu_actions.remove_child(item)
  item.queue_free()
 game.menu_title.text = title
 game.menu_text.text = body

func link(label: String, page: String) -> void:
 game.add_action(label, game.show_menu.bind("starport_" + page))

func legacy(label: String, page: String) -> void:
 game.add_action(label, game.show_menu.bind(page))

func finish(back: String = "home") -> void:
 if back != "":
  link("< BACK / " + back.to_upper(), back)
 # PASS53: departure never disappears inside a nested department.
 if game.docked:
  game.add_action("▶ LAUNCH / UNDOCK NOW  [E / SHIFT+L]", game.launch_from_station)
  game.add_action("STATION MAIN TERMINAL", game.show_menu.bind("station"))
 game.add_action("CLOSE / RETURN TO SHIP", game.close_menu)

# PASS 51 / DEEP TERMINAL NETWORK - each action calls a live system.
func contract_sector(sector: int) -> void:
 show("sector_" + str(sector))

func contract_detail(index: int) -> void:
 show("contract_" + str(index))

func show(which: String) -> void:
 last_page = which
 match which:
  "home":
   panel("GODS COMMAND / STARPORT OPERATIONS", "[b]CENTRAL OPERATIONS / LIVE TERMINAL NETWORK[/b]\nStation: %s\nShip: %s | Credits: %d | Fuel: %d%%\nBerth: %s | Active mission: %s\n\nChoose a department. Each department opens its own sub-panels and existing game actions." % [game.station_names[game.current_system], game.SHIP_NAMES[game.ship_class], game.credits, int(game.fuel), "SECURED" if game.docked else "FLIGHT", game.mission_phase_label()])
   link("01 / MISSION OPERATIONS", "dispatch")
   link("02 / APPROACH & TRAFFIC CONTROL", "flight")
   link("03 / CARGO & COMMERCE", "trade")
   link("04 / SECURITY & BOUNTIES", "bounty")
   link("05 / ENGINEERING & RECOVERY", "services")
   link("06 / FLEET & SHIPYARD", "fleet")
   link("07 / SHIPBOARD HELP TERMINAL", "help")
   legacy("COMMAND NEXUS / SHIP COMPUTER", "nexus_home")
   finish("")
  "dispatch":
   panel("STARPORT / MISSION OPERATIONS", "[b]DISPATCH CENTRAL[/b]\nContracts cleared: %d / %d\nActive: %s\n\nBrowse seven sector boards, read individual contract briefs, or use mission planning. Contract acceptance is linked to the original mission director." % [game.mission_completed.size(), game.MISSIONS.size(), game.mission_phase_label()])
   link("ACTIVE MISSION / CONTROL ROOM", "active")
   link("SECTOR CONTRACT BOARDS", "sectors")
   link("MISSION PLANNING & ROUTE DESK", "planning")
   link("MISSION HISTORY & PERFORMANCE", "journal")
   link("AUTOMATED MISSION COMPUTER", "automation")
   finish("home")
  "sectors":
   panel("MISSION DISPATCH / SECTOR INDEX", "[b]SECTOR CONTRACT DIRECTORIES[/b]\nSelect a sector to inspect its actual missions, rewards and objective routes. Completed contracts are marked.")
   for i in range(game.SYSTEM_NAMES.size()):
    link("%02d / %s — %d CONTRACTS" % [i + 1, game.SYSTEM_NAMES[i], game.count_sector_missions(i)], "sector_" + str(i))
   finish("dispatch")
  "active":
   var live: bool = game.mission_stage < 6
   var detail: String = "[b]NO ACTIVE CONTRACT[/b]\nOpen a sector contract board and accept a mission."
   if live:
    var m: Dictionary = game.MISSIONS[game.active_mission]
    detail = "[b]%s[/b]\n%s\nNext destination: %s\nReward: %d CR + bonuses\nFuel: %d%% | Hull: %d%%\n\nPlot the next leg or engage the mission computer." % [m["name"], game.mission_phase_label(), game.mission_next_leg_label(), int(m["reward"]), int(game.fuel), int(game.hull_hp / maxf(1.0, game.max_hull()) * 100.0)]
   panel("MISSION DISPATCH / ACTIVE OPERATION", detail)
   if live:
    game.add_action("PLOT NEXT OBJECTIVE", game.mission_plot_next_leg)
    legacy("FULL MISSION OBJECTIVES", "mission_active")
   link("AUTOMATION / START OR STOP", "automation")
   link("MISSION PLANNING", "planning")
   finish("dispatch")
  "planning":
   panel("MISSION DISPATCH / FLIGHT PLANNING", "[b]ROUTE & OPERATIONS DESK[/b]\nSector: %s\nFuel reserve: %d%%\nMission: %s\n\nUse the route plotter for each objective. Interstellar travel and docking use the existing flight computer." % [game.SYSTEM_NAMES[game.current_system], int(game.fuel), game.mission_phase_label()])
   if game.mission_stage < 6:
    game.add_action("PLOT CURRENT MISSION LEG", game.mission_plot_next_leg)
   legacy("GALACTIC ROUTE MAP", "galaxy")
   legacy("FLIGHT SUPPORT / APPROACH", "flight_support")
   link("DOCKING CONTROL", "docking")
   link("AUTOMATED MISSION COMPUTER", "automation")
   finish("dispatch")
  "journal":
   panel("MISSION DISPATCH / CAPTAIN'S LOG", "[b]OPERATIONS RECORD[/b]\nCompleted contracts: %d / %d\nSuccessful runs: %d\nRetries: %d\n\nOpen the full game journal for performance, grades and recorded incidents." % [game.mission_completed.size(), game.MISSIONS.size(), game.mission_successes, game.mission_retries])
   legacy("OPEN FULL MISSION JOURNAL", "mission_journal")
   link("SECTOR CONTRACT BOARDS", "sectors")
   finish("dispatch")
  "automation":
   panel("MISSION DISPATCH / AUTO DIRECTOR", "[b]ONE-BUTTON MISSION DIRECTOR[/b]\n%s\n\nThe existing automation performs mission travel and objectives. Guardian and fuel safeguards remain available. Manual flight override is always possible." % ["AUTO MISSIONS: ACTIVE" if game.pass46_auto.enabled else "AUTO MISSIONS: STANDBY"])
   game.add_action("START / STOP AUTO MISSIONS", game.pass46_auto.toggle)
   legacy("FULL AUTOMATION CONTROL", "nexus_auto_missions")
   link("ACTIVE CONTRACT", "active")
   link("FLIGHT PLANNING", "planning")
   finish("dispatch")
  "flight":
   panel("STARPORT / FLIGHT CONTROL", "[b]PORT AUTHORITY[/b]\nCurrent station: %s\nDocking: %s\n\nTraffic, approach, navigation and launch operations are grouped here." % [game.station_names[game.current_system], "BERTH SECURED" if game.docked else "SHIP IN FLIGHT"])
   link("DOCKING & LANDING CLEARANCE", "docking")
   link("TRAFFIC & NAVIGATION", "traffic")
   link("DEPARTURE CONTROL", "departure")
   link("FLIGHT PLANNING", "planning")
   finish("home")
  "docking":
   panel("PORT AUTHORITY / DOCKING CONTROL", "[b]ARRIVAL PROCEDURES[/b]\nBerth: %s\n\nRequest docking via comms or use Flight Support for automated approaches. Landings require the ship to reach the approach corridor." % ["SECURED" if game.docked else "NOT DOCKED"])
   legacy("REQUEST CLEARANCE / COMMS", "comms")
   legacy("AUTOMATED DOCKING / FLIGHT SUPPORT", "flight_support")
   if game.docked:
    game.add_action("LAUNCH FROM SECURED BERTH", game.launch_from_station)
   finish("flight")
  "traffic":
   panel("PORT AUTHORITY / TRAFFIC DESK", "[b]ORBITAL MOVEMENT CONTROL[/b]\nSector: %s\nStarport piers: 6\n\nReview the galaxy, scan contacts and manage approach navigation. Physical starport structures from Pass 50 remain in the scene." % game.SYSTEM_NAMES[game.current_system])
   legacy("GALAXY / DESTINATION MAP", "galaxy")
   game.add_action("SCAN CURRENT SECTOR", game.scan_sector)
   legacy("LONG-RANGE COMMUNICATIONS", "comms")
   finish("flight")
  "departure":
   panel("PORT AUTHORITY / DEPARTURE", "[b]DEPARTURE CHECKLIST[/b]\nHull: %d%% | Shields: %d%% | Fuel: %d%%\nDocked: %s\n\nService the ship before launch or return to active mission planning." % [int(game.hull_hp / maxf(1.0, game.max_hull()) * 100.0), int(game.shield_hp / maxf(1.0, game.max_shield()) * 100.0), int(game.fuel), "YES" if game.docked else "NO"])
   if game.docked:
    game.add_action("AUTHORIZE LAUNCH", game.launch_from_station)
   link("ENGINEERING SERVICE DESK", "maintenance")
   link("MISSION ROUTE DESK", "planning")
   finish("flight")
  "trade":
   panel("STARPORT / COMMERCE EXCHANGE", "[b]COMMERCIAL TERMINALS[/b]\nCredits: %d | Cargo: %d units\n\nRegional pricing, freight and the bazaar are linked to your current cargo and credits." % [game.credits, game.cargo_units])
   link("MARKETS & PRICE ANALYSIS", "markets")
   link("FREIGHT & DELIVERY CONTRACTS", "freight")
   link("BAZAAR & CARGO STORAGE", "bazaar")
   finish("home")
  "markets":
   panel("COMMERCE / MARKET INTELLIGENCE", "[b]REGIONAL MARKET DESK[/b]\nCompare current commodity prices and evaluate trade routes before spending credits.")
   game.add_action("OPEN REGIONAL MARKETS", game.living_galaxy.show.bind("markets"))
   game.add_action("OPEN ROUTE PROFIT ANALYZER", game.living_galaxy.show.bind("route_planner"))
   finish("trade")
  "freight":
   panel("COMMERCE / FREIGHT OFFICE", "[b]FREIGHT DISPATCH[/b]\nCargo on board: %d units\n\nAccept commercial freight or local station jobs. These are the real cargo and contract systems." % game.cargo_units)
   game.add_action("FREIGHT CONTRACTS / LIVING GALAXY", game.living_galaxy.show.bind("freight"))
   legacy("LOCAL CARGO JOBS", "cargo")
   link("MISSION DISPATCH", "dispatch")
   finish("trade")
  "bazaar":
   panel("COMMERCE / BAZAAR & WAREHOUSE", "[b]WAREHOUSE CONTROL[/b]\nCredits: %d\nCargo: %d units\n\nBuy and sell from the live bazaar or inspect the ship's cargo hold." % [game.credits, game.cargo_units])
   game.add_action("BAZAAR / BUY & SELL", game.living_galaxy.show.bind("bazaar"))
   legacy("SHIP CARGO HOLD", "cargo")
   finish("trade")
  "bounty":
   panel("STARPORT / SECURITY COMMAND", "[b]SECURITY OPERATIONS[/b]\nSelect a department for named warrants, tactical readiness and local station patrols.")
   link("BOUNTY WARRANT REGISTRY", "warrants")
   link("TACTICAL READINESS & ARMORY", "combat")
   link("LOCAL PATROL COMMISSIONS", "patrol")
   finish("home")
  "warrants":
   panel("SECURITY / WARRANT OFFICE", "[b]WARRANTS & LEGENDARY TARGETS[/b]\nNamed bounty hunts and legendary ship encounters are tracked in the existing galaxy records.")
   game.add_action("OPEN NAMED BOUNTY WARRANTS", game.living_galaxy.show.bind("hunts"))
   game.add_action("LEGENDARY SHIP REGISTRY", game.living_galaxy.show.bind("legendary"))
   finish("bounty")
  "combat":
   panel("SECURITY / TACTICAL READINESS", "[b]WEAPONS & COMBAT CONTROL[/b]\nMissiles: %d\nKills: %d\nBounties completed: %d\n\nWeapons, ammunition and recovered salvage are handled by the original tactical menus." % [game.missile_ammo, game.combat_kills, game.combat_bounties_completed])
   legacy("TACTICAL COMMAND", "tactics")
   legacy("ARMORY / REARM & SALVAGE", "armory")
   finish("bounty")
  "patrol":
   panel("SECURITY / PATROL DISPATCH", "[b]PERIMETER DEFENSE[/b]\nLocal patrols and security jobs remain tied to the station job system.")
   legacy("STATION SECURITY CONTRACTS", "security")
   link("MISSION DISPATCH", "dispatch")
   finish("bounty")
  "services":
   panel("STARPORT / ENGINEERING COMMAND", "[b]SHIP SUPPORT SERVICES[/b]\nHull: %d%% | Shield: %d%% | Fuel: %d%%\n\nRepair, refuel, rearm, upgrade and emergency support are separate departments." % [int(game.hull_hp / maxf(1.0, game.max_hull()) * 100.0), int(game.shield_hp / maxf(1.0, game.max_shield()) * 100.0), int(game.fuel)])
   link("REPAIR / REFUEL / REARM", "maintenance")
   link("SHIP MODULES & OUTFITTING", "modules")
   link("DISTRESS & EMERGENCY RECOVERY", "rescue")
   finish("home")
  "maintenance":
   panel("ENGINEERING / SERVICE COUNTER", "[b]BERTH SERVICE CONTROL[/b]\nStatus: %s\nCredits: %d\n\nDock for normal repairs, refueling and ammunition services. All costs and inventory changes use the existing engineering menu." % ["DOCKED" if game.docked else "IN FLIGHT", game.credits])
   legacy("REPAIR / REFUEL / REARM TERMINAL", "engineering")
   legacy("SALVAGE & AMMUNITION", "armory")
   finish("services")
  "modules":
   panel("ENGINEERING / OUTFITTING", "[b]SHIP SYSTEM BANKS[/b]\nCurrent hull: %s\n\nOpen outfitting and ship inspection for installed modules and hull statistics." % game.SHIP_NAMES[game.ship_class])
   legacy("SHIP MODULE OUTFITTING", "outfitting")
   legacy("SHIPYARD / HULL INSPECTION", "shipyard")
   finish("services")
  "rescue":
   panel("ENGINEERING / EMERGENCY RESPONSE", "[b]DISTRESS & RECOVERY[/b]\nFuel: %d%% | Hull: %d%%\n\nOpen the real Command Nexus distress console for stranded ship recovery." % [int(game.fuel), int(game.hull_hp / maxf(1.0, game.max_hull()) * 100.0)])
   legacy("DISTRESS BEACON / RECOVERY", "nexus_distress")
   legacy("FLIGHT SUPPORT / EMERGENCY PILOT", "flight_support")
   finish("services")
  "fleet":
   panel("STARPORT / FLEET & SHIPWORKS", "[b]FLEET OPERATIONS[/b]\nOwned hulls: %d\nActive hull: %s\n\nShip purchases, escort commands and fleet servicing use your actual owned vessels." % [game.owned_ships.size(), game.SHIP_NAMES[game.ship_class]])
   link("SHIPYARD & HULL EXCHANGE", "shipyard")
   link("WINGMAN & FLEET ORDERS", "escorts")
   link("STORED SHIP MAINTENANCE", "storage")
   finish("home")
  "shipyard":
   panel("FLEET / SHIPYARD EXCHANGE", "[b]HULL EXCHANGE[/b]\nOwned ships: %d\nCredits: %d\n\nBuy or switch between owned hulls at a secured berth." % [game.owned_ships.size(), game.credits])
   legacy("SHIPWORKS / HULL CATALOG", "shipyard")
   legacy("SHIP OUTFITTING", "outfitting")
   finish("fleet")
  "escorts":
   panel("FLEET / ESCORT OPERATIONS", "[b]WINGMAN CONTROL[/b]\nWingman: %s\n\nUse the fleet command board for escort deployment and tactical orders." % ["DEPLOYED" if game.wingman_active else "STANDBY"])
   legacy("FLEET COMMAND / ORDERS", "fleet")
   legacy("TACTICAL COMMAND", "tactics")
   finish("fleet")
  "storage":
   panel("FLEET / HANGAR INVENTORY", "[b]STORED VESSELS[/b]\nOwned hulls: %d\n\nInspect, repair and transfer between stored ships with the existing ship service system." % game.owned_ships.size())
   legacy("STORED SHIP SERVICE", "ship_service")
   legacy("HULL EXCHANGE", "shipyard")
   finish("fleet")
  "help":
   panel("STARPORT / INFORMATION TERMINAL", "[b]HELP & TRAINING[/b]\nChoose flight instruction, mission assistance or emergency guidance. The complete Academy includes context-sensitive flight tips.")
   legacy("FULL HELP ACADEMY", "nexus_help")
   legacy("SHIP CONTROLS / QUICK REFERENCE", "help")
   link("MISSION DISPATCH / HOW TO START", "dispatch")
   link("AUTOMATED MISSION DIRECTOR", "automation")
   link("DISTRESS / EMERGENCY SUPPORT", "rescue")
   finish("home")
  _:
   if which.begins_with("sector_"):
    var sector: int = clampi(int(which.trim_prefix("sector_")), 0, game.SYSTEM_NAMES.size() - 1)
    var done: int = 0
    for i in range(game.MISSIONS.size()):
     if int(game.MISSIONS[i]["sector"]) == sector and game.mission_completed.has(i):
      done += 1
    panel("CONTRACT BOARD / " + game.SYSTEM_NAMES[sector], "[b]LIVE CONTRACT REGISTER[/b]\nSector: %s\nCleared: %d / %d\n\nSelect a contract to see every objective, route and reward before accepting." % [game.SYSTEM_NAMES[sector], done, game.count_sector_missions(sector)])
    for i in range(game.MISSIONS.size()):
     var m: Dictionary = game.MISSIONS[i]
     if int(m["sector"]) == sector:
      link("%02d / %s / %d CR%s" % [i + 1, str(m["name"]), int(m["reward"]), " [CLEARED]" if game.mission_completed.has(i) else ""], "contract_" + str(i))
    finish("sectors")
   elif which.begins_with("contract_"):
    var index: int = clampi(int(which.trim_prefix("contract_")), 0, game.MISSIONS.size() - 1)
    var m: Dictionary = game.MISSIONS[index]
    var route: String = game.SYSTEM_NAMES[int(m["sector"])] + " -> " + game.SYSTEM_NAMES[game.mission_sector_for(index, 2)]
    if game.mission_has_third_leg(index):
     route += " -> " + game.SYSTEM_NAMES[game.mission_third_sector(index)]
    panel("CONTRACT FILE / %02d" % [index + 1], "[b]%s[/b]\nReward: %d CR + bonuses\nRoute: %s\nObjective sites: %d\nStatus: %s\n\n%s" % [str(m["name"]), int(m["reward"]), route, game.mission_total_sites(index), "CLEARED" if game.mission_completed.has(index) else "AVAILABLE", game.mission_briefing(index)])
    if game.mission_stage >= 6:
     game.add_action("ACCEPT CONTRACT / ACTIVATE MISSION", game.accept_mission.bind(index))
    else:
     link("ACTIVE MISSION IN PROGRESS / VIEW", "active")
    link("MISSION PLANNING & ROUTE DESK", "planning")
    finish("sector_" + str(int(m["sector"])))
   else:
    show("home")
