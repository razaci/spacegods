extends Node3D
# PASS 27: three-stage real glTF dreadnought replacement, visual-only.
# Loads one batched PBR model; preserves all gameplay and collision behavior.
var game: Node3D
var model: Node3D
var effects: Node3D
var glow_discs: Array[MeshInstance3D] = []
var engine_lights: Array[OmniLight3D] = []
var elapsed: float = 0.0
var quality: int = 2

func initialize(root: Node3D) -> void:
 game = root
 refresh_ship()

func refresh_ship() -> void:
 if not is_instance_valid(game.fleet_visual): return
 if is_instance_valid(model): model.queue_free()
 if is_instance_valid(effects): effects.queue_free()
 glow_discs.clear()
 engine_lights.clear()
 if int(game.ship_class) != 4: return
 game.chase_distance_target = maxf(float(game.chase_distance_target),112.0)
 var resource: PackedScene = load("res://art/models/gods_dreadnought.glb") as PackedScene
 if resource == null:
  push_warning("Dreadnought GLB could not be imported; retaining original hull")
  return
 # Hide ONLY the existing visual placeholders, not the actual player or physics.
 for old_part in game.fleet_visual.get_children():
  old_part.visible = false
 model = resource.instantiate() as Node3D
 if model == null: return
 model.name = "P27_GODS_DREADNOUGHT_PBR_MODEL"
 game.fleet_visual.add_child(model)
 effects = Node3D.new()
 effects.name = "P27_Reactor_Lighting_Animated_Exhaust"
 game.fleet_visual.add_child(effects)
 var paint: Color = game.ship_paint()
 var paint_mat = StandardMaterial3D.new()
 paint_mat.albedo_color = paint
 paint_mat.metallic = 0.9
 paint_mat.roughness = 0.24
 # Paint accents follow the existing Shipworks color selection.
 for side in [-1.0,1.0]:
  var accent_mesh = BoxMesh.new()
  accent_mesh.size = Vector3(1.3,0.35,36.0)
  var accent = MeshInstance3D.new()
  accent.mesh = accent_mesh
  accent.material_override = paint_mat
  accent.position = Vector3(side*14.0,11.8,-9.0)
  effects.add_child(accent)
 var flame_mat = StandardMaterial3D.new()
 flame_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
 flame_mat.albedo_color = Color(0.25,0.75,1.0,0.8)
 flame_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
 flame_mat.emission_enabled = true
 flame_mat.emission = Color(0.15,0.68,1.0)
 flame_mat.emission_energy_multiplier = 3.5
 for x in [-34.0,-18.0,0.0,18.0,34.0]:
  var mesh = SphereMesh.new()
  mesh.radius = 2.8 if absf(x) < 1.0 else 2.2
  mesh.height = 5.6 if absf(x) < 1.0 else 4.4
  mesh.radial_segments = 16
  mesh.rings = 8
  var glow = MeshInstance3D.new()
  glow.name = "Animated_Engine_Exhaust"
  glow.mesh = mesh
  glow.material_override = flame_mat
  glow.position = Vector3(x,-1.0 if absf(x)>1.0 else 0.0,61.0)
  glow.scale = Vector3(1.0,1.0,2.0)
  effects.add_child(glow)
  glow_discs.append(glow)
 for side in [-1.0,1.0]:
  var light = OmniLight3D.new()
  light.position = Vector3(side*26.0,-1.0,57.0)
  light.light_color = Color(0.17,0.62,1.0)
  light.light_energy = 0.85
  light.omni_range = 24.0
  light.shadow_enabled = false
  effects.add_child(light)
  engine_lights.append(light)
 apply_quality(quality)

func apply_quality(level: int) -> void:
 quality = clampi(level,0,2)
 for lamp in engine_lights:
  if is_instance_valid(lamp): lamp.visible = quality >= 1
 for glow in glow_discs:
  if is_instance_valid(glow): glow.visible = quality >= 1

func animate(dt: float) -> void:
 if int(game.ship_class) != 4 or not is_instance_valid(effects): return
 elapsed += dt
 var thrust: float = clampf(float(game.throttle),0.0,1.0)
 var pulse: float = 1.0 + 0.09*sin(elapsed*17.0)
 for glow in glow_discs:
  if is_instance_valid(glow): glow.scale = Vector3(1.0,1.0,(1.4+thrust*2.7)*pulse)
 for lamp in engine_lights:
  if is_instance_valid(lamp): lamp.light_energy = 0.45+thrust*1.2
