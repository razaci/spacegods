extends Control
# Cockpit sensor scope. Circular CRT, heading-up, 3.6 km.
var game
var range_m := 3600.0
var sweep := 0.0
const PHOSPHOR := Color(0.55, 0.95, 0.72, 0.9)
const DIM := Color(0.25, 0.55, 0.4, 0.45)

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(dt: float) -> void:
	sweep = fmod(sweep + dt * 1.15, TAU)
	if visible:
		queue_redraw()

func _draw() -> void:
	var c := size * 0.5
	var radius: float = minf(size.x, size.y) * 0.42
	draw_circle(c, radius + 8.0, Color(0.02, 0.04, 0.03, 0.9))
	draw_arc(c, radius + 8.0, 0.0, TAU, 64, Color(0.45, 0.7, 0.55, 0.7), 2.0, true)
	draw_circle(c, radius, Color(0.01, 0.06, 0.04, 0.88))
	for fraction in [0.33, 0.66, 1.0]:
		draw_arc(c, radius * fraction, 0.0, TAU, 64, DIM, 1.0, true)
	draw_line(c + Vector2(-radius, 0), c + Vector2(radius, 0), DIM, 1.0)
	draw_line(c + Vector2(0, -radius), c + Vector2(0, radius), DIM, 1.0)
	var wedge := PackedVector2Array([c])
	for i in range(9):
		var a := sweep - 0.4 + float(i) * 0.05
		wedge.append(c + Vector2(sin(a), -cos(a)) * radius)
	draw_colored_polygon(wedge, Color(0.4, 1.0, 0.65, 0.07))
	draw_line(c, c + Vector2(sin(sweep), -cos(sweep)) * radius, Color(0.6, 1.0, 0.75, 0.35), 1.0)
	draw_colored_polygon(PackedVector2Array([c + Vector2(0, -9), c + Vector2(-5, 7), c + Vector2(0, 3), c + Vector2(5, 7)]), PHOSPHOR)
	if not is_instance_valid(game):
		return
	var heading: float = game.yaw
	var index := 0
	for hostile in game.enemies:
		if not is_instance_valid(hostile):
			continue
		var diff: Vector3 = hostile.global_position - game.flight_pos
		var distance: float = diff.length()
		var selected: bool = index == game.target_index
		var angle: float = atan2(diff.x, -diff.z) - heading
		var reach: float = minf(distance / range_m, 1.0) * (radius - 4.0)
		var point := c + Vector2(sin(angle), -cos(angle)) * reach
		var color := Color(1.0, 0.82, 0.35) if selected else Color(1.0, 0.38, 0.32)
		draw_rect(Rect2(point - Vector2(2.5, 2.5), Vector2(5, 5)), color)
		if selected:
			draw_arc(point, 8.0, 0.0, TAU, 18, color, 1.2, true)
		index += 1
	var delta: Vector3 = game.nav_waypoint() - game.flight_pos
	if delta.length() > 8.0:
		var bearing: float = atan2(delta.x, -delta.z) - heading
		var loc := c + Vector2(sin(bearing), -cos(bearing)) * minf(delta.length() / range_m, 1.0) * (radius - 4.0)
		draw_rect(Rect2(loc - Vector2(3, 3), Vector2(6, 6)), Color(0.45, 1.0, 0.7), false, 1.4)
