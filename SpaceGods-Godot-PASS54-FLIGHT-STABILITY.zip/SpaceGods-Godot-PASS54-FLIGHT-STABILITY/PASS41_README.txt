SPACE GODS PASS 41 — HAZARD AWARE FLIGHT

Ctrl+7 waypoint / Ctrl+8 station approach / Ctrl+9 auto dock / Ctrl+4 pursue / Ctrl+5 hold range.
Ctrl+6 disengages and acknowledges critical emergency hold. Ctrl+0 emergency cancel.
The flight computer scans nearby asteroids and enemies every 0.24 seconds, brakes and steers away when detected ahead.
Critical hull/shield conditions suspend autopilot until acknowledged. Manual flight and weapon controls remain available.
This is a steering aid, not guaranteed collision avoidance; test in Godot before relying on it.
