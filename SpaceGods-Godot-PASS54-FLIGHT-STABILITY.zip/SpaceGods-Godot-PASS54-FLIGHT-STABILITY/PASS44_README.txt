SPACE GODS PASS 44 — GUARDIAN FLIGHT DOCTRINES

Ctrl+Shift+4 cycles Guardian threat-response profiles: CAUTIOUS (1700m), BALANCED (1150m), DARING (700m). Guardian must be enabled with Ctrl+Shift+9. Profiles affect the trigger distance only, not weapon firing.
Ctrl+Shift+5 reads the last three flight computer incidents. The HUD shows the latest incident. Profile and last 12 incidents persist in saves.
Automatic navigation now stops and idles at or below a 12% fuel reserve, displaying an emergency rescue reminder (Shift+F1). Manual flight remains available.
Existing Ctrl+6 manual override, Ctrl+0 emergency cancel, and ~ engine shutdown are unchanged.

Engine runtime verification is still needed.
