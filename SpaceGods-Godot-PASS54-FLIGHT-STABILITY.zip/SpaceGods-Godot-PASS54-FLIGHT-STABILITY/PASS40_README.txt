SPACE GODS — PASS 40 / FLIGHT COMPUTER SAFETY

Ctrl+0: cancel tactical pursuit, range hold, waypoint navigation or auto-docking; return to manual at zero commanded throttle.
Ctrl+6: existing manual mode.
Ctrl+7: waypoint navigation. Ctrl+8: station approach. Ctrl+9: auto dock.
1-0: throttle presets. ~: engines off. X: all stop.

NEW:
- Speed-aware autopilot braking envelope; brake earlier at high speed.
- Automatic docking only hands off to landing when ship speed is sufficiently low.
- Ctrl+number or Ctrl+ability shortcuts no longer lower throttle while held.
- Existing missions, cargo, ship graphics, HUD, saves and menus preserved.

TESTING: Archive and static source checks only. Godot engine was not available here; test on Windows and report errors.
