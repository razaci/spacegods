SPACE GODS PASS 39 - AUTO DOCKING

Ctrl+9 engages automatic station approach and docking. The computer requests clearance at 1600m, enters the docking zone within 900m, then calls the existing landing sequence.
Ctrl+8 still approaches without landing. Ctrl+7 goes to waypoint. Ctrl+6 disengages.
Shift+F4 > Flight Support also includes AUTO DOCK.
No mission, save-file, trade, or bounty data changed.

Godot engine runtime verification not performed; please test in Godot 4 on Windows.
