SPACE GODS PASS 35 / FLIGHT PHASE 2

TAB select enemy; T cycle subsystem; F fire; K missile; SHIFT+B board selected disabled ship.

Boarding requires: within 350 meters, shields down, engine damage >=92%, hull <=50%.
Named bounty captains require hull <=35% and follow existing warrant flow.
Engine damage reduces hostile movement; disabled enemies cease firing. Weapon damage suppresses fire; shield-generator damage prevents recharge.
All original missions, ships and command menus retained.

Godot runtime test is not available in this environment.
