@echo off
setlocal
cd /d "%~dp0"
set "GODOT_EXE="
for %%F in (Godot*.exe godot*.exe) do if not defined GODOT_EXE if exist "%%~fF" set "GODOT_EXE=%%~fF"
if not defined GODOT_EXE for %%C in (godot.exe godot4.exe) do if not defined GODOT_EXE for /f "delims=" %%G in ('where %%C 2^>nul') do if not defined GODOT_EXE set "GODOT_EXE=%%G"
if not defined GODOT_EXE (
 echo Godot 4 was not found in this folder or on your Windows PATH.
 echo Download the standard Godot 4 editor, put Godot*.exe next to this BAT,
 echo then double-click this file again.
 pause
 exit /b 1
)
echo Starting SPACE GODS using "%GODOT_EXE%"
"%GODOT_EXE%" --path "%~dp0"
if errorlevel 1 pause
