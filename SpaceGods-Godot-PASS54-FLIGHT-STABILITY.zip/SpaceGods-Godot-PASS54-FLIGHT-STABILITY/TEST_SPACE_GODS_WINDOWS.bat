@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "GODOT_EXE="
for %%F in (Godot*.exe godot*.exe) do if not defined GODOT_EXE if exist "%%~fF" set "GODOT_EXE=%%~fF"
if not defined GODOT_EXE for %%C in (godot.exe godot4.exe) do if not defined GODOT_EXE for /f "delims=" %%G in ('where %%C 2^>nul') do if not defined GODOT_EXE set "GODOT_EXE=%%G"
if not defined GODOT_EXE (
 echo Godot 4 not found. Place the Godot 4 Windows EXE beside this file.
 pause
 exit /b 1
)
echo SPACE GODS PASS 21 - ENGINE TEST > "TEST_RESULTS.txt"
echo Engine: %GODOT_EXE% >> "TEST_RESULTS.txt"
echo. >> "TEST_RESULTS.txt"
echo [1] Importing and parsing project... >> "TEST_RESULTS.txt"
"%GODOT_EXE%" --headless --editor --path "%~dp0" --quit >> "TEST_RESULTS.txt" 2>&1
set "IMPORT_STATUS=%errorlevel%"
echo Import exit code: %IMPORT_STATUS% >> "TEST_RESULTS.txt"
echo [2] Starting game for 180 frames... >> "TEST_RESULTS.txt"
if "%IMPORT_STATUS%"=="0" (
 "%GODOT_EXE%" --headless --path "%~dp0" --quit-after 180 >> "TEST_RESULTS.txt" 2>&1
 set "GAME_STATUS=!errorlevel!"
) else (
 set "GAME_STATUS=SKIPPED"
)
echo Game exit code: !GAME_STATUS! >> "TEST_RESULTS.txt"
findstr /i /c:"SCRIPT ERROR" /c:"Parse Error" /c:"Invalid call" /c:"ERROR:" "TEST_RESULTS.txt" > "ERRORS_ONLY.txt"
if errorlevel 1 (
 echo No matching engine error lines found. >> "TEST_RESULTS.txt"
) else (
 echo WARNING: Engine errors found. Read ERRORS_ONLY.txt. >> "TEST_RESULTS.txt"
)
if not "%IMPORT_STATUS%"=="0" echo FAIL: GODOT PROJECT IMPORT FAILED. >> "TEST_RESULTS.txt"
if not "!GAME_STATUS!"=="0" echo FAIL: GODOT GAME STARTUP DID NOT COMPLETE CLEANLY. >> "TEST_RESULTS.txt"
if "%IMPORT_STATUS%"=="0" if "!GAME_STATUS!"=="0" echo Engine processes returned zero; inspect ERRORS_ONLY.txt and test flight manually. >> "TEST_RESULTS.txt"
echo. >> "TEST_RESULTS.txt"
echo IMPORTANT: A short headless test cannot verify visual rendering or all missions. >> "TEST_RESULTS.txt"
notepad "TEST_RESULTS.txt"
pause
