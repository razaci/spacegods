SPACE GODS — PASS 38 / NAVIGATION PILOT

Ctrl+7: engage automatic steering and throttle toward the active local waypoint.
Ctrl+8: engage local station approach; stops short of the station.
Ctrl+6: cancel assistance and return to manual flight.
Shift+F4: flight support menu has the same controls as clickable actions.

Approach logic uses the existing flight physics, checks engine shutdown and
docking, slows before the destination, and stops automatically on arrival.
It does not perform interstellar jumps, land without clearance, or fire guns.
Existing combat, missions, trading, save files, and HUD are retained.

NOTE: This build was statically inspected and archive-tested. Godot runtime
verification has not been performed in this environment.
