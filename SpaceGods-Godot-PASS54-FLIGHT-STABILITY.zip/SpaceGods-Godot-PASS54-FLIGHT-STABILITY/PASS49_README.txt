SPACE GODS — PASS 49 COCKPIT

Fixed Godot parse error: menus is now an explicit bool.
Open project.godot in Godot 4 and press F5.
