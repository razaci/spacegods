SPACE GODS PASS 42 — TACTICAL EVASION AND ROUTE RECOVERY

CTRL+SHIFT+7: Tactical evade nearest hostile, 14 seconds maximum; stops when clear.
CTRL+SHIFT+8: Resume the navigation mode saved before evasion (if one existed).
CTRL+6: Manual flight; CTRL+0: emergency cancel and idle throttle.
The autopilot now commits to one side of a hazard for 2.5 seconds rather than oscillating.
Evasion does not auto-fire, consume special resources, or jump to another sector.
Emergency hold, engine shutdown and docking override the escape computer.
This is game flight assistance, not guaranteed collision avoidance.
