from pathlib import Path
import numpy as np
import trimesh as tm
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals

out=Path(__file__).resolve().parents[1] / 'art/models/gods_command_center.glb'
groups={k:[] for k in ['hull','armor','dark','trim','glass','cyan','amber']}
def add(mesh,k): groups[k].append(mesh)
def box(size,at,k,angle=0):
 m=tm.creation.box(size); m.apply_transform(tm.transformations.rotation_matrix(angle,[0,0,1]));m.apply_translation(at);add(m,k)
def cylinder(r,h,at,k,n=16):
 m=tm.creation.cylinder(r,h,sections=n);m.apply_translation(at);add(m,k)
def arc(r0,r1,z0,z1,a,b,k):
 verts=[]
 for t in np.linspace(a,b,5):
  for r,z in [(r0,z0),(r1,z0),(r1,z1),(r0,z1)]: verts.append([r*np.cos(t),r*np.sin(t),z])
 faces=[]
 for i in range(4):
  for j in range(4):
   a0=i*4+j;b0=i*4+(j+1)%4;c0=b0+4;d0=a0+4
   faces += [[a0,b0,c0],[a0,c0,d0]]
 faces += [[0,2,1],[0,3,2],[16,17,18],[16,18,19]]
 m=tm.Trimesh(verts,faces,process=True);m.fix_normals();add(m,k)
for i in range(32):
 a=i*2*np.pi/32;b=a+2*np.pi/32-.012
 arc(239,282,-26,26,a,b,'hull')
 arc(242,278,-30,-26,a+.012,b-.012,'armor')
 arc(242,278,26,30,a+.012,b-.012,'armor')
 arc(265,268,30,30.8,a+.028,b-.028,'cyan')
 arc(251,258,30,31,a+.022,b-.022,'dark')
 for j in range(4):
  t=a+.035+j*.034
  arc(252,256,31,31.4,t,t+.019,'glass')
 t=(a+b)/2
 box([7,20,66],[284*np.cos(t),284*np.sin(t),0],'trim',t)
for i in range(8):
 a=i*np.pi/4
 box([160,11,18],[151*np.cos(a),151*np.sin(a),0],'dark',a)
 for z in [-17,17]:
  box([160,4,5],[151*np.cos(a),151*np.sin(a),z],'trim',a)
 for j in range(5):
  r=90+j*25
  box([6,23,32],[r*np.cos(a),r*np.sin(a),0],'armor',a)
 cylinder(16,36,[285*np.cos(a),285*np.sin(a),-12],'armor',8)
 cylinder(10,38,[285*np.cos(a),285*np.sin(a),-12],'dark',8)
cylinder(66,250,[0,0,0],'hull',12)
cylinder(76,24,[0,0,82],'armor',12)
cylinder(70,15,[0,0,-91],'armor',12)
cylinder(42,16,[0,0,132],'dark',12)
cylinder(29,17,[0,0,133],'glass',12)
for i in range(12):
 a=i*np.pi/6
 box([8,31,154],[68*np.cos(a),68*np.sin(a),-3],'armor',a)
 box([1.2,12,108],[73*np.cos(a),73*np.sin(a),-3],'cyan',a)
for i in range(6):
 a=i*np.pi/3
 p=np.array([325*np.cos(a),325*np.sin(a),52])
 box([66,38,176],p,'hull',a)
 box([70,6,159],p+[0,0,0],'trim',a)
 box([40,22,4],p+[0,0,90],'dark',a)
 box([30,2,4],p+[0,0,93],'cyan',a)
 for j in range(4):
  box([10,2,14],p+[0,0,-52+j*28],'amber',a)
# Keep the existing pad and approach geometry below the new modeled exterior.
box([162,28,265],[0,-116,77],'hull')
colors={'hull':[.25,.29,.34,1],'armor':[.40,.45,.49,1],'dark':[.035,.046,.06,1],'trim':[.18,.22,.26,1],'glass':[.04,.15,.20,1],'cyan':[.06,.55,.7,1],'amber':[.8,.39,.05,1]}
scene=tm.Scene()
for k,parts in groups.items():
 mesh=tm.util.concatenate(parts)
 material=PBRMaterial(name=k,baseColorFactor=colors[k],metallicFactor=.75 if k not in ['cyan','amber','glass'] else .3,roughnessFactor=.39 if k!='dark' else .66,emissiveFactor=([.02,.45,.7] if k=='cyan' else [.65,.23,.02] if k=='amber' else [0,0,0]))
 mesh.visual=TextureVisuals(material=material)
 scene.add_geometry(mesh,node_name='GCC_'+k)
out.write_bytes(scene.export(file_type='glb'))
print(out, sum(len(m.faces) for m in scene.geometry.values()),'triangles')
