SPACE GODS PASS 43 - GUARDIAN PILOT

Ctrl+Shift+9 toggles Guardian mode (off by default).
When waypoint or station navigation is engaged, Guardian checks for nearby hostiles twice a second. Within 1150 m it temporarily suspends the route, activates existing tactical evasion, and resumes the prior route when the threat clears. A 12-second cooldown prevents rapid re-triggering. No automatic firing or jumping.
Ctrl+6 or Ctrl+0 returns control to the pilot. Tilde still cuts engines. The HUD reports Guardian status.

This feature is not a guarantee against collisions or attacks. It requires Godot gameplay testing.
