SPACE GODS — PASS 48 PROFESSIONAL INTERFACE

The flight deck and station menus no longer use the default Godot panel look.
- Thin instrument frames, one cyan accent, muted secondary text.
- Top status line, left vessel meters, large speed figure, heading tape.
- Sensor, contract and lock cards stay off the center of the view.
- Single command row: Missions, Galaxy, Next Leg, Dock, Shipworks, Nexus, Save, Auto.
- Mission, galaxy and station menus open as a centered console with left-aligned actions.
- Coach and auto-mission popups are hidden; Auto still toggles with the button or Shift+F8.

Open project.godot in Godot 4 and press F5.
