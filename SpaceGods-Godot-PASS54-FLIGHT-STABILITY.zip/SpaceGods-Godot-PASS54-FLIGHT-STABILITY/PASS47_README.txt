SPACE GODS — PASS 47 HUD AND INTERFACE

Flight deck replaces the stacked Pass 23 panels.
- Top ribbon: ship, sector, credits, flight state.
- Left instruments: hull, shield, energy, pips, fuel.
- Bottom-left velocity and throttle.
- Heading compass under the reticle.
- Bracket reticle, amber when a hostile is locked.
- Right side: heading-up radar, contract card, target lock.
- Bottom command bar: Missions, Galaxy, Next Leg, Dock, Shipworks, Save, Camera, Nexus, Auto.
- Station and mission menus use the same cyan frame and button style.
- Coach tip moved down so it no longer covers radar. Auto-mission status is on the tactical card; Shift+F8 still toggles it.
- Shift+F2 still switches compact HUD.

Open project.godot in Godot 4 and press F5.
