SPACE GODS — PASS 36 / FLIGHT PHASE 3
Based on the supplied Pass 35 project.

NEW FLIGHT/COMBAT CONTROLS
CTRL+1  Transfer one of six reactor pips to ENGINES (max four)
CTRL+2  Transfer one pip to WEAPONS (max four)
CTRL+3  Transfer one pip to SHIELDS (max four)
CTRL+Q  Aegis Shield Surge: immediate shield boost and 9 seconds faster regeneration; costs 35 energy
CTRL+E  Electronic Jammer: hostile targeting and missiles suppressed for 7 seconds; costs 45 energy
CTRL+R  Engine Overdrive: 27% speed increase for 10 seconds; costs 50 energy
All three abilities share an 18-second cooldown. Energy recharges over time.

Pips affect turn rate and top speed, weapon cooldown, and shield regeneration.
Enemies now maneuver evasively (especially interceptors) and retreat when heavily damaged unless engines are disabled.
Power allocations persist in the existing game save; timed abilities do not.
Original number-row throttle shortcuts remain unchanged. Tilde remains engine shutdown.

TESTING
ZIP structure and basic source consistency checked. Godot runtime execution has NOT been verified in this environment.
If Godot displays a parse error, send the exact line and message.
